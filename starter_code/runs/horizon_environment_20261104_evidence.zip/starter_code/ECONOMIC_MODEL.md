# Economic conventions (Stage 2)

This is a controlled laboratory market. Its parameters are explicit modelling
choices, not estimates fitted to an actual stock exchange. The thesis component
comparison must keep these conventions fixed across A (corrected simple agent),
B (factual summaries), and C (added reflection). These modes are implemented;
see AGENT_EXPERIMENTS.md. Small live diagnostics exist; general comparative
benefits and human realism remain unverified.

## One round

1. Start the period, apply scheduled economic effects, and deliver only events
   with `announce: true`. Agents see previous payouts,
   their portfolios, recent auction prices, and the permitted public information.
2. Collect orders and hold a uniform-price auction. Reserve cash and shares from
   opening portfolios; proceeds from this auction cannot finance its other orders.
3. Settle trades and collect tax from both parties, if configured.
4. Draw the current dividend. Post-auction holders keep their positions through
   the period and receive the per-share payout. Post-settlement cash earns the
   per-round interest rate. Dividend income is not reinvested within the round.
5. Record cash flows, portfolios, and liquidity. Mark stock holdings at the latest
   auction price. No separate post-dividend price auction is simulated.

Thus `prices.csv` contains auction clearing prices before the round's income,
not a separately observed ex-dividend closing price. Account wealth includes
cash income already paid. Price-return diagnostics and portfolio total returns
must be distinguished; do not add recorded income to wealth a second time.

`time.round_unit` labels the period. `time.periods_per_year` describes its scale;
it does not convert rates behind the scenes. `asset.risk_free` is always per
round. A yearly compound return corresponding to r and n periods is (1+r)^n-1.

## New baseline: iid_permanent

For current dividend mean m and relative noise h:

    dividend = m * Uniform(1-h, 1+h),  0 <= h <= 1

Draws are independent across rounds. The distribution is nonnegative and has
exact expectation m, without a truncation-induced upward shift in its mean.
Permanent shocks multiply m starting at the configured event round. Finite `duration`
is rejected in this model instead of applying an inconsistent valuation formula.
Headline-only events are allowed and do not alter m or the random draws.

## News visibility and economic effects

An event's `announce` flag (default `true`) controls its public headline, while
`effect` independently controls dividends. For an unannounced economic change:

```yaml
reveal_fundamental: false
news:
  - round: 301
    announce: false
    effect: {dbar_mult: 1.2}
```

Hidden events may omit `headline`; a supplied hidden label is researcher-only.
Announced events require nonempty text. Omit `effect` for a headline-only event.
An unannounced event without an effect is a valid scheduled no-op control.
Visibility does not consume randomness or change the dividend process.

`reveal_fundamental` is a separate disclosure channel. If true, it exposes the
current regime benchmark even for an unannounced shock. Keep it false when
studying learning from news versus observed payments. With it false, agents
first observe a silent change through the payout after the event auction;
they are not told the changed mean, its benchmark, or the future event schedule.

`event_audit.jsonl` records every scheduled event, including silent changes and
no-ops, with before/after means and benchmarks at round open. It is a research
log, never an agent observation or reflection input. `events.csv` retains its
legacy rows for announced events only; its benchmark column is also
researcher-only. Only the public headline strings reach the observation builder.
Do not feed these files directly to traders. Legacy temporary-effect expiry is
still governed by the saved duration; the audit records event applications,
not separate expiry events.

`python -B -u -m sim.news_controls` runs the frozen three-seed/four-cell
rule-only verification. See AGENT_EXPERIMENTS.md for its interpretation and the
separate proposed live pilot.

## Stationary-regime benchmark

For a stationary regime, a constant risk-neutral benchmark P satisfies:

    P * (1+r) = P + E[dividend]
    P = m/r

This benchmark assumes a positive rate, constant expected future cash flows,
no anticipation of future unannounced regime changes, no risk premium, and no
trading friction. It is a frictionless reference when a transaction tax is used,
not a prediction that every risk-averse trader should agree or transact at P.
It does not anticipate the simulator's future scripted news schedule.

The supplied baseline uses r=0.0002 and m=0.02, giving P=100. Relative dividend
noise is 0.2. A 300-round interest-only account grows by about 1.062, compared
with about 19.788 under the old r=0.01. With 252 sessions per year the new rate
corresponds to about 5.17% compounded annually; this is a scale choice, not a
calibrated estimate. Dividends and interest inject cash from an external issuer
and bank. Aggregate cash is not required to remain constant over long runs.

## Legacy AR(1) demonstration

`legacy_ar1` retains the clipped AR process and temporary mean effects:

    d = max(0, m + rho*(previous_dividend-m) + sigma*Normal(0,1))

Its m/r reference is explicitly labelled `legacy_perpetuity_approximation`.
Clipping, transitory effects, and conditional AR expectations are not priced
exactly. `dev_mock.yaml` retains the old parameters under this explicit label;
it is not the recommended foundation for mispricing research. Old configurations
with rho/sigma and no model are interpreted as legacy with a warning.

## Accounting and liquidity

Every round must satisfy, within floating-point tolerance:

    cash_after = cash_before - tax_paid + dividends_paid + interest_paid
    dividends_paid = total_shares * dividend
    interest_paid = post_settlement_cash * r

Total shares remain constant. `cashflows.csv` records the inputs and error,
`initial_state.csv` records the starting endowments, and `agents_state.csv`
records each account's dividend and interest income. Initial share cost defaults
to the initial reference price unless explicitly supplied; buyer tax is included
in subsequent acquisition cost.

The market maker posts one buy and one sell quote around an inventory-adjusted
center. It cannot borrow cash, short stock, or buy beyond its inventory cap.
Quotes may remain unfilled; liquidity is not guaranteed. Other trader types
continue to return a single Order. `validate_orders` supports both interfaces,
prevents self-crossing, and allows at most one quote per side per trader.

`liquidity.csv` records submitted limit quotes, fill rate, market-maker volume
participation, and price-band hits. A pre-clearing batch can have a negative
`quoted_spread` because bids and asks cross. This is not a continuous-market
effective spread or transaction cost. Missing quote sides remain blank.

## Checked configuration

`sim/config.py` loads typed configuration and rejects unknown options, duplicate
YAML keys, invalid values, unsupported agent parameters, and unimplemented
mechanisms. Validation happens before a run directory is created. Saved
`config.yaml` includes normalized defaults and can be loaded again.

Supported rule parameters are activity_prob (random), delta/aggressiveness/dividend_window
(fundamentalist), window/aggressiveness (momentum), and spread/inventory_limit/
inventory_target/inventory_skew/quote_size (market maker). Spread is a half-spread.
Currently unimplemented risk_aversion/horizon numerical parameters are rejected.
LLM persona traits still come from the library. Use environment variables for
provider credentials; configuration does not accept API keys.

`fundamentalist.params.dividend_window` defaults to 1, preserving the original
last-dividend/rate decision rule when the benchmark is hidden. A larger positive
integer averages that many previously observed paid dividends (available-history
warm-up); round 1's initialization reference is not a paid observation. Repeated
decisions in one round do not duplicate the observation. A disclosed benchmark
still overrides the proxy. Window 5 is a sensitivity option, not a selected
improvement: R020 found increased return persistence and liquidity trade-offs.

## Conditional passive-account comparison

`sim.evaluation.evaluate_run(path)` reads saved outputs without changing them.
For each account, hold its initial shares fixed and update passive cash as
`cash_next = cash * (1 + risk_free) + initial_shares * realized_dividend`.
This respects the same payout timing as active accounts. Compare active and
passive wealth using both the last auction price and the regime benchmark;
normalize returns/differences by the same initial market-valued wealth. Returns
are undefined (`null`) for zero initial wealth. Income is already in final cash
and must not be added again.

This is a conditional realized-price-path accounting benchmark. It assumes the
observed prices for marking and does not simulate prices if traders actually
stopped trading; it is not a risk-adjusted alpha estimate. In the closed-share,
zero-tax screen, aggregate active-minus-passive wealth cancels numerically even
though individual accounts can differ. With transaction tax this cancellation
need not hold. Screen evaluations are saved beside, never inside, old run files.

Agent groups may use either fixed cash or `cash_dist: lognormal(mu, sigma)`.
The sampler uses the population stream, so it cannot alter the dividend path.
Heterogeneous cash is optional; controlled comparisons should match resources.

## Diagnostic recipes

- `baseline_rules.yaml`: 1,000 rounds, 20 rule traders, disclosed benchmark,
  no news. Disclosure makes this a value-trading engineering diagnostic.
- `diagnostic_shock.yaml`: identical setup, with a permanent +20% dividend-mean
  shock at round 500. Pre-shock exogenous paths match the no-news recipe.
- `baseline_mock.yaml`: 100-round pipeline demo including eight mock agents,
  with the benchmark hidden. Its population and disclosure differ from the
  rule diagnostic, so these files are not a controlled LLM-versus-rule experiment.
- `dev_mock.yaml`: explicitly labelled legacy demonstration.

These diagnostics do not validate human behaviour. Keep pilot calibration,
held-out evaluation, and the A/B/C live-model component study distinct.
