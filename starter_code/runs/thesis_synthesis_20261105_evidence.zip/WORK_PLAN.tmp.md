# Temporary implementation plan

## R042 verified - Thesis evidence synthesis (2026-11-05)

User authorizes the next beneficial stage. This stage uses saved evidence only:
zero API requests and zero new market paths. No simulator, prompt, persona,
economic default, source study or failure-policy changes.

- [x] Verify the existing evidence archives and source reports before deriving
  a compact claim ledger. Recompute all headline aggregates from saved arrays;
  retain every sign, incomplete component arm and unknown-usage limitation.
- [x] Write `THESIS_RESULTS.md` in simple language: research question, two
  stronger within-model findings, explicitly exploratory A/B/C evidence,
  limitations, existing exportable figures and original evidence links.
- [x] Create a reproducible numerical synthesis pack under
  `starter_code/runs/thesis_synthesis_20261105/`, with source hashes and a
  standalone comparison figure. Keep scenario counts, price/total returns,
  reported/reserved tokens and auction/benchmark marks distinct.
- [x] Verify calculations, links and figure; record provenance and confirm
  source studies, simulator files and all nine older archives are unchanged.
  Update the diary/checkpoint and state the next justified evidence gap without
  launching another study or treating a proposed comparison as completed.

Verified: all sixteen raw news trade logs; eight rule price/inventory paths;
41 input hashes (40 original inputs byte-identical to sealed ZIP members);
all nine older archive SHA256/CRC checks; 103 unchanged source files; twelve
valid local links; numerical brief tables/component differences; inspected
PNG/PDF comparison figure. No API usage or new simulation. This is synthesis,
not additional independent confirmation or a new realism claim.

## R040/R041 completed - Reading gate and repeated confirmation (2026-11-04)

User "proceed to whatever next stage ... good for thesis" authorizes this new
explicit protocol; R038 remains stopped, not resumed or retrospectively fixed.
No production/sim default edits, provider switch or A/B/C removal.

- [x] R040: NEW candidate-only comprehension check, four exact R038 clarified
  persona/sign contexts x3 fresh replies=12 calls. Replace quoted type examples
  with explicit JSON-number field requirements; headline/economic context and
  conditional forecast question unchanged. No original-wording replay or
  old/new efficacy estimate. Record strict JSON-number compliance separately
  from reading extraction; finite canonical decimal strings may be extracted
  as numbers transparently, never expressions/booleans/NaN. Raw types retained.
  Numeric wrong/malformed replies resolve as recorded unsuccessful/missing
  slots, then next independent planned slot; NO repair or same-case resample.
  Provider/budget/output failure stops batch after existing one shared retry.
  Gate for new markets:all12 observed,valid,36 level fields correct. Neither
  a trading-sign test nor proof of natural-trading comprehension/human realism.
- [x] Same exact BharatCode Qwen8192/low/.3/180s,10RPM/60000 estimate TPM;
  R04020HTTP/350K reservations. Freeze code/messages/order/budgets, offline
  type/copy/failure/independent-invalid guards, then one bounded actual attempt.
  COMPLETE16:11:49 IST:12/12 strict numeric replies,36/36 level fields;
  gate passed,12HTTP/12187 reported tokens/143688 reservations/0 errors or
  unknown usages. Root runs/20261104_160858_candidate_reading_89b6e200.
  PID25388 exited. Explicit reading evidence only,no old/new market efficacy.
- [x] R041 PREDECLARED before R040 outputs: if reading gate passes, fresh
  downside-news sequential confirmation under two MM backgrounds. Fresh seeds
  20611/21727 x2 independent model repetitions xskew.02/0 xvisible/silent
  true permanent mean-.20 at INITIAL1=16 eight-round A markets,256 normal
  decisions. Same original R036 hidden-length/explicit-prior adapter; ONLY
  visible bulletin changes to clarified one-time-level text common in R040.
  No reuse of R036 replies, cash injection or state selection. Fixed rotated
  arm orders; same initial accounts/personas/background first books and
  same-seed dividends across visibility,background and repetitions. Backend
  randomness unseeded; repeats nest in TWO exogenous histories,not4 seeds.
  Focus on downside because earlier null/response coexist and both traders
  initially can sell; not a claim about all news signs. No financial-sign gate.
- [x] Primary: visible-minus-silent first3 signed EXECUTED shares, per target/
  combined/seed/repetition/skew; secondary difference between these contrasts
  under skew0vs.02. Keep requested/accepted/gross fills,opening exposure/capacity,
  all8-round paths/prices/gaps/activity/MM/inventory,both lifetime passive marks/
  counterparts and token/missing costs. No stable human/trait/component/model
  superiority or long-run-statistics claim. Clarified/old studies stay separate.
- [x] Eight actual zero-API F/M companions(seeds xskew xvisibility) first;
  same-regime visible/silent CSVs identical,all first books match and dividend/
  resource/accounting/MM/passive checks pass. No outcome-based baseline choice.
  Per live arm24HTTP/450K reservations,campaign384HTTP/6M,256 normal requests.
  First fatal provider/budget/output or persistent JSON fallback stops whole
  study; existing one identical-message transport/503 extra attempt only.
  No restart/splice/resample/continuation/next-seed delivery amendment. All
  source/prompt/config/schedule seals before live generation; reading gate
  receipt pinned. No further live phase after this fixed campaign.
  5 offline checks pass including256 mock calls and first/later stops. All8
  actual rule controls complete8/8 with gates passed. Frozen root
  runs/20261104_161605_downside_confirmation_1be3841b,protocol
  698b8bcdfb3230d74430d68e0032f297ef247390d3f206580ece3fa0bc82289f.
  FINISHED17:20:39 IST:all16 eight-round paths/256 choices,2 seed gates;
  PID10652 exited,no API job.256 successfulHTTP/588992 reported tokens/
  3823311 reservations,zero retries/repairs/errors/unknown/missing. Metadata
  runs/downside_confirmation_launch_20261104.json. No duplicate/source edits.
- [x] Finish or retain first fatal stop of the fixed16-market schedule, then
  audit full/partial/missing endpoints and write comparative interpretation.
  runs/downside_confirmation_analysis_20261104/INTERPRETATION.md:combined
  early3 news contrasts(original/no-skew)20611rep1 -2/-156,rep2 -122/0;
  21727rep1 -106/-106,rep2 -3/-128. Actor cancellation,identical-price-path
  transfer and identical-input response variation retained; no p-value/default.
  Full audit32 initial messages/16 books/256 histories/2688 balances passes.
- [x] Appropriate offline guards,readouts/figures/audit/archive; maintain diary
  and three-candidate index. A/B/C remains a separate selectable comparison,
  not multiplied into this news/background mechanism study. Student remaining
  quota unknown; no billing or silent substitution. Combined NEW ceiling
  404HTTP/6.35M reservations,not permission to spend for preferred signs.
  5 reading+5 driver+3 readout checks pass. Main/supplement/v2 figure hashes
  sealed,first figure retained. Preservation verified below; no further live phase.
  PRESERVED runs/downside_confirmation_20261104_evidence.zip,4,154,631bytes,
  SHA256b846393eedca7b694f4e99417cfa45cad43f89de78c69c50309d9a3c758db339.
  516 file hashes/1256 recursive configured-secret member checks pass;eight
  older evidence archives unchanged. Docs snapshot precedes checksum closure.
  All R040/R041 checks closed; no active API job or automatic next phase.

## R038 stopped/R039 completed - Bounded pass preserved (2026-11-04)

User "go ahead with what you think is good for thesis" authorizes bounded
implementation of R037 priorities. Existing source/defaults/A/B/C and sealed
evidence remain unchanged. Two independent questions, no outcome-based gate
between them. No new large live-market batch in this pass.

- [x] R038: freeze one corrected headline pair (positive/negative one-time
  expected dividend LEVEL shift, maintained later, realized payments uncertain).
  Copy R036's exact8 initial visible inputs and deduplicate to4 distinct
  persona/sign contexts. Compare original/corrected wording in an explicit
  reading task, three fresh replies/cell:24 normal requests, not trading.
  Ask expected dividend at sessions1/5/10 conditional on forecast accuracy,
  with previous mean.02 common. Classify level/growth/other paths; ambiguity
  means original growth reading is not necessarily a linguistic error.
  Gate for corrected candidate:all12 replies/36 numeric fields match the
  intended level. No requirement old performs worse or orders take any sign.
- [x] Same exact Qwen8192/low/temp.3/180s,10RPM/60000 input-estimate TPM;
  total40HTTP/700K reservations,0 configured-dollar prices/billing. Existing
  one shared identical-message transport/503 extra attempt. First provider/
  budget/output/malformed-response failure stops semantic batch. Incorrect
  finite numeric answers are recorded, not retried/screened. No automatic
  second wording/model/qualification batch. Freeze source/messages/order first;
  offline copy/dedup/classification/stop/duplicate guards before actual calls.
  5 offline checks pass; prepared/live root runs/20261104_154111_semantics_cd0076dc,
  protocol c1eca600e7442d2c39267437f7a20586f21b1331c226e487b5dbf3ffe8680e93.
  Launch metadata runs/semantic_launch_20261104.json; no duplicate run/source edits.
- [x] R039: new independent confirmation of existing R020 inventory-skew
  mechanism. Four unused seeds16253/17341/18433/19531;600 quiet rounds each,
  same14-slot F/M rule population/resources,window1,only MM skew.02 versus0.
  Eight markets,0 API. Alternate arm order by seed; no lowest-gap/default
  selection. Freeze configs/source/protocol before generating any outcomes.
  Primary no-skew-minus-original full600 log-price-return ACF1 per seed;
  secondary full lags1-10,abs returns,gap,turnover,MM share/boundary,cash/stock
  concentration,three200-session blocks and both passive marks/counterparts.
  Match dividend paths/initial states; accounting/MM/source gates only.
  Preserve all signs; four independent exogenous seeds, not8 replications.
  Prepared/running root runs/20261104_154730_market_validation_fff53e3b;
  five offline checks pass; no outcome inspected before freezing.
- [x] One external diagnostic context: Kenneth French's official daily US
  market factors CSV ZIP; choose last600 observed daily returns ending no
  later than2025-12-31 BEFORE download/inspection. Market simple total return
  =(Mkt-RF+RF)/100, log via log1p. Compare to SIM TOTAL SHARE RETURN
  log((P_t+d_t)/P_prev), distinct from primary price-only ACF. Keep zeros,
  dates/units/actual source snapshot/hash/retrieval metadata; no imputation,
  date-window/asset shopping, alpha test or calibrated realism pass score.
  Broad US portfolio versus14-agent single stock is an institutional mismatch;
  only a descriptive reference, not human validation or long LLM evidence.
  One <=10MB/60s public download attempt, no credentials; record unavailable
  if blocked, no silent dataset substitution. Primary metadata reviewed first.
  AVAILABLE:178326byte source ZIP,current202609 CRSP snapshot; selected600
  dates20230811--20251231. Total-return/absolute-return ACF1 -.0387/.2079;
  simulator original means .1754/-.0043,no-skew .1170/-.0032. No calibration claim.
- [x] Audit/readout/figures/archive both independent tasks; update diary and
  concise thesis-candidate index. Distinguish correction implementation,
  reading-check evidence and untested market benefit. No promotion of QA to
  research headline; choose follow-up from results without expanding this pass.
  Preserved runs/balanced_validation_20261104_evidence.zip,6,633,588bytes,
  SHA25604df396a0c84cf99ac66d5a842aae3168f2462caa2852dd7c78e52b7f326bb5b.
  194 exported file hashes/468 recursive configured-secret member checks pass;
  seven earlier archives unchanged. Docs snapshot precedes checksum closure.

R038 STOPPED at first original reply under strict numeric-field policy:
three quoted numeric strings; one successful HTTP/1090 reported tokens/
11717 reservations,23 unattempted,0 clarified replies. No provider failure.
Raw growth interpretation retained; corrected message is NOT live verified.
No blind restart, parser amendment or second batch. R039 is independent.

R039 COMPLETE:8x600 rounds/four fresh seeds,0 API. Primary ACF deltas
-.0499,-.0955,-.0496,-.0390; MM boundary fraction increases4/4,turnover falls3/4,
one whole-path gap worsens,3/12 nested time-block contrasts reverse. All signs,
both passive marks/counterparts,raw source/empirical records and two figures
retained.5 offline checks and4800 round/67200 account-state audit pass.
Read supplement/INTERPRETATION.md. No default selected; .02 baseline/0 sensitivity.
Headline comprehension still unverified; a future properly typed check needs
an explicit protocol. No additional API/live-market job scheduled in this pass.

## R037 direction review completed - Rebalance evidence (2026-11-04)

- [x] Review the whole objective after user requested another self-evaluation:
  economic/execution coherence, individual behaviour, collective market dynamics,
  news interpretation, fair policy comparisons, A/B/C and external validation.
  Evidence: R020/R021/R025-R032/R034-R036 readouts and current diary. Review only;
  no source/config/prompt edits, new run, API call or result reclassification.
- [x] Record candid assessment: experimental reliability has improved; increased
  human/market realism is NOT established. R033-R036 again concentrated effort
  on news/execution. External validation, independent repetitions and broader
  market dynamics remain underdeveloped. Routine software checks belong in
  methods, not headline findings. Preserve three candidates and all negatives.

Historical R037 proposals (R038/R039 above implement part; remaining work proposed):

- [ ] Close the known dividend-message ambiguity in ONE bounded correction/
  comprehension check. Old text admits level/growth readings; failure is in
  communicating the intended dynamics, not proof of model incompetence. Keep
  uncertainty, hidden true mean, common A/B/C semantics and independent failures.
  Acceptance concerns faithful interpretation, never a preferred trading sign.
- [ ] Before another market batch, select one leading thesis claim, its current
  evidence limits and the missing confirmation. Predesign fresh independent
  repetitions and one reasonable background sensitivity, with fixed budgets/
  stopping/missing rules. Existing failed cases remain missing. Evaluate actions,
  actual fills/exposure, prices/activity/MM participation, both passive marks
  and cost together. No broad news/provider/persona/component grid.
- [ ] Give the next substantial scientific pass explicit market-background/
  validation coverage: inspect existing dependence/activity/cash/inventory
  evidence and select a compatible external laboratory or market reference.
  State institutional/time-scale mismatches; no lowest-gap parameter selection.
  Longer quiet live paths are necessary IF long-run LLM statistics are claimed;
  otherwise narrow the thesis claim rather than imply12/24 rounds validate it.
- [ ] Retain selectable corrected A / factual B / reflective C. Existing C has
  one complete endogenous scenario; stable efficacy needs fresh full matched
  repetitions. Allocate them only if that claim is central; otherwise present
  the current mixed/cost evidence as exploratory. A/B/C need not multiply all
  other studies. No automatic reflection default or failed-path rerun.
- [ ] Synthesize at most three result stories with evidence, competing
  explanations, limitations and needed checks. Main figures include negative/
  null results; engineering and provider-recovery details move to methods/
  appendices. No human-bias/herding/general-superiority claims without evidence.

These are research-priority decisions, not implemented improvements or a frozen
API protocol. No automatic experiment is scheduled by this review. Do not let
the semantic correction become another sequence of increasingly narrow probes;
follow it with market validation/robustness or independent confirmation.

## R036 completed - Sequential initial-state controls; semantic caveat (2026-11-04)

- [x] User "carry on ... limit ... fine now" authorizes next proposed sequential
  pass; R035 already finished, no old run to resume. Fresh seeds13111/14227,
  12 rounds, A-only,5 cells each:quiet/up_silent/up_visible/down_silent/down_visible.
  Real permanent mean shifts+20%/-20% at round1; all use base initial dividend
  reference.02 and price100, same initial resources/personas/backgrounds.
  Predesign both blocks/order before calls;10 markets,240 normal decisions.
- [x] Research-only common hidden-length adapter also labels round1's supplied
  dividend reference honestly as initialization, not a paid observation in this
  recording. Current v2 USER says previous dividend paid although initializer
  is a reference(ECONOMIC_MODEL documents this). Shared semantic clarification,
  no private current-mean hint and no financial-rule change. New prompt version,
  baseline v2/selectable A/B/C/source unchanged; no behavioural benefit claimed.
- [x] Ten zero-API same-resource rule companions first. Visible/silent financial
  files identical per true regime; first-auction all5 rule books/trades same,
  dividend paths quiet scaled1.2/.8. Accounting/resource/path gates only.
- [x] Freeze primary: within-seed visible-minus-silent cumulative signed executed
  target flow over rounds1-3, per actor/combined, separately up/down. Secondary
  first-auction response, all12-round price/gap/activity/MM/fills, intentions/
  headroom, both lifetime conditional passive marks and all counterparts/costs.
  Silent true-shift vs quiet secondary economic-regime contrast. No sign oracle.
- [x] Implement gates: same-seed initial financial states/personas exactly matched; first silent
  prompts match across quiet/up/down, visible first prompts differ only headline;
 12 non-LLM first orders match. Later divergence is part of treatment/feedback.
  Model draws unseeded, two exogenous scenarios only, no inferential/human/
  stable-news or intrinsic LLM-vs-rule superiority claim. Initial-time timing
  lacks established pre-event trends; no pooling with R035 or older prompts.
- [x] Freeze same Qwen8192/low/temp.3/180s/memory5/no reflection/rate10/60000. Per-arm
  40HTTP/700K reservations; whole10-arm400/7M cap,240 normal calls. Student
  remaining daily quota unverified, no billing/provider/model switch. First
  fatal/fallback stops whole study, one existing identical-message extra retry;
  no automatic continuation, next seed after failure, resampling or prefix splice.
- [x] Freeze sources/configs/actual prompt versions/order/limits; offline guards
  including initial disclosure,10 complete fake markets, provider/partner stop
  and drift.4 driver+3 readout checks pass; all sim source guards unchanged.
- [x] Run block1 then predeclared block2 if technical gates clean, never
  dependent on financial direction. Audit terminal missing vs observed primary
  early3 endpoints explicitly; archive all signs/negatives and update diary.
  FINISHED15:03:43 IST: all10 live paths12/12, both blocks' initial gates pass,
  240 decisions/241 HTTP/606498 reported tokens/3750938 reservations/1 unknown/
  0 blocked. One existing identical-message URLError retry recovered. No missing,
  repair, persistent failure or reflection. PID3416 exited, no API job.
- [x] Final audit/interpretation/preservation and diary closure. Independent
  account reconstruction added to readout: fills/tax/interest/dividends reproduce
  every account's cash/shares/wealth.3 readout checks pass after addition;
  final20 rule/live paths3360 account-round checks, max error2.91e-11.
  Audit/INTERPRETATION/figures complete in runs/initial_news_analysis_20261104;
  preserved ZIP runs/initial_news_20261104_evidence.zip,3,179,404bytes/400 files,
  SHA256457fb1f642d759c5c7c5bfdd50d56e394cb6854b9f0395ff12c5378ca48ac669.
  970 recursive configured-secret member checks; all member hashes verified,
  six earlier evidence archives unchanged. Docs snapshot precedes checksum
  closure to avoid circular hash; no active API job/additional live phase.
  Primary combined up/down0/0,+22/-97; retain
  actor cancellation, unfilled intentions, both marks and mixed gaps.

New validity lead, PROPOSED only: unambiguously state a one-time permanent
expected dividend LEVEL change with uncertain realized payments. Delivered
"20% ... per trading session" was explicitly read as repeated per-session
decline by Arjun14227/down_visible1, though engine mean changes once. ALL8
initial visible inputs/replies retained in semantic_examples.json; no estimated
misunderstanding rate or effect-of-wording claim. Verify semantics in a small
predeclared control before more news market generation. No new prompt/default
or API run implemented/scheduled. Apply common wording across future A/B/C;
do not tune personas/switch models to force a preferred response. Existing raw
studies remain intact, with retrospective interpretive caution where relevant.

One bounded sequential research question, no new market features or component/
provider/wording grid. Before claims, assess both policy behaviour and collective
market effects;12-round paths cannot validate long-run stylized facts.

## R035 - Bounded phase completed; original other source missing (2026-11-04)

- [x] User "proceed" authorizes a new explicit source-independent gate, NOT
  restart of9623/R033. Freeze linked amendment retaining old2 HTTP/22284
  reservations/2 unknown/1 blocked and missing first source. Run only original
  untouched10729 config; one6-round A history, fixed frame2/6. No new seed,
  financial-sign gate, response screening or model/prompt/economic/default change.
- [x] Implemented: if clean source and exact replay/actual-history/rule-control gates pass,
  run ONLY its18 original scheduled conditional auctions(36 new choices),
  original frame indices2/3 and news/agent rotation. Independent source gating
  explicitly relaxes R033's both-sources gate; full study still missing9623.
  Single-history/2-frame pilot, not a completed two-history study/independent
  confirmation of R034's numeric effects;4096 and8192 conditions remain separate.
- [x] Freeze source40HTTP/600K,query54HTTP/1M,total94/1.6M; normal48 choices,
  0 reflections. Including old2/22284 <=original188/3.2M. Same Qwen8192/low/
  temp.3/180s, rate10/60000. One existing identical-message extra transport/503
  attempt; first fatal/fallback stops phase. No next seed, automated delivery
  phase, old-state substitution, missing-partner HOLD or increased retry limit.
- [x] Disclose source's first initial prompt may equal failed9623's because initial
  portfolios/personas match; it begins a DISTINCT originally planned exogenous
  seed, not replay of the failed path. Do not claim seeded provider randomness.
- [x] Offline schedule/parent-immutability/exact-replay/partial-joint guards;
  run once, audit all states/signs/opportunity/execution/market/both one-auction
  marks and costs; preserve parent/partials and update diary/archive. No new
  posterior liquidity grid; existing R034 post-hoc check remains separate.
  FINISHED07:01:15 IST, PID12220 exited; no API job. Source6/6 and phase18/18
  matched auctions complete; originalstudy1/2 histories and18/36 (9623 missing).
  48 successful HTTP/124808 reported tokens/702164 reservations; no errors,
  repairs/caps/unknowns/blocked. Linked totals50 HTTP/724448 reservations/
  2 old unknowns/1 old blocked.4 driver+3 readout checks pass offline.
  36 actual message checks/54 settlement variants/1512 analytic wealth checks
  pass. Readout+manual interpretation runs/news_source10729_analysis_20261104.
  Preserved ZIP runs/news_source10729_20261104_evidence.zip,1,046,836bytes,
  SHA256e3eda51c100d5eac2a7b59295e02509a691132e0df325a2019422a28d934b8c5.
  94 file hashes/236 recursive secret members verified, old archives unchanged.
  No additional API phase scheduled here; original missing half stays missing.

Historical R035 next option, subsequently implemented as R036 above: a small sequential headline-visibility
study with intervention at the INITIAL state, so every same-seed condition
starts from exactly equal portfolios/history rather than divergent pre-news
LLM paths. Fixed real positive/negative shifts with visible/silent headline pairs
and a quiet reference,12 rounds/A-only; initial-time timing removes need for
checkpoint/agent-state infrastructure or forced cash buffers. Predesign fresh
independent histories, bounds/failures/outputs and no financial-sign gate before
generation. This tests joint downstream effects, not another same-frame sweep.
At the R035 checkpoint no config/code/generation existed; R036 subsequently
froze repeat/budget scope before generation. Permanent A/B/C/old defaults remain.
No duplicate or additional run is authorized by this historical proposal text.

## R033 - Implementation/attempt closed; ZERO behavioural data (2026-11-04)

- [x] Freeze bounded immediate-response design before new generation: two fresh
  quiet A histories(seeds9623/10729),6 rounds; source snapshots at2/6 chosen
  without filtering on decisions/headroom/results. All use common hidden
  recording length research adapter, not a selected new production default.
  Same Qwen8192/low/temp.3/180s/memory5, original economics/personas/A/B/C intact.
- [x] Implement reconstruction of opening accounts, own actual histories and12 background
  traders' submitted orders. Exact full source-auction replay must recover
  source prices/trades and allocation RNG state; no engine/checkpoint rewrite.
- [x] Freeze positive/negative/no-headline x4 frames x3 fresh joint repetitions:
  36 conditional auctions,72 new decisions. Both focal agents change together;
  same pre-state, background orders and allocation RNG within every frame.
  No source reply reused for silent control; no selected favourable frame.
- [x] Freeze main outcome: within-frame/rep signed executed target flow, headline
  minus silent, per actor/combined; gross/requested/accepted/fills and price,
  depth/MM, opportunity and both one-auction conditional passive marks.
  Repetitions are model draws within4 frames nested in2 histories, not36
  independent full markets or isolated trait effects. No desired-sign gate.
- [x] Implement hidden economic mean multipliers1/.8/1.2 as counterfactual settlements
  of the SAME accepted orders/auction, not new behavioural replies/repeats.
  Verify identical executions; report payout/mark effects separately. Cannot
  identify later learning/price discovery/equilibrium profits from one step.
- [x] Implement four same-state F/M target-policy substitutions, equal opening resources,
  negative headline controls; not full rule-population/human skill comparison.
  Offline accounting/resource/source/history/negative-control gates first.
- [x] Freeze source caps40 HTTP/600K reservations each; query caps108/2M; total188/3.2M,
  normal24 source+72 query=96 decisions,0 reflection. One shared transport/503
  extra attempt per request, same delivery profile. First fatal/fallback stops
  phase; retain incomplete joint auction, never turn missing partner into HOLD.
  No automatic continuation/retry of failed paths, source substitution or new
  model/provider qualification. Daily remaining quota unverified.
- [x] Attempt once, audit all failures/missing slots, record diary and
  preserve source/config/prompt/raws. No additional feature/market grid here.
  STOPPED06:03:36 IST: first Meera1 request and identical retry time out180s
  each; Arjun1 blocked by shared fatal policy. PID25288 exited, no API job.
  2 HTTP/22284 reservations/0 known tokens/2 unknown usages/1 blocked.
  ZERO cleared rounds/sources/headline trials.9623 source partial0,10729 and
  all36 auctions/72 trial choices unattempted. No behavioural null/result.
  runs/20261104_055619_news_auctions_a2e319da. Four driver and3 offline
  readout checks pass. No new qualification/retry/provider escalation now.
  Four offline checks passed including complete96 fake calls, exact replay,
  joint partner failure and source quota stop. Actual source-frame gates run
  before query calls; they require the new source histories to exist first.

This is a conditional single-auction intervention with real settlement, NOT a
long sequential market study. A positive/negative forecast and actual shift
are independently controlled: effects not yet visible at order cutoff cannot
silently influence agents. Later sequential confirmation remains a proposal.

## R034 - OFFLINE retrospective extension completed (2026-11-04)

- [x] Freeze distinct secondary question before calculating counterfactual
  fills: ALL36 recorded A-only R025-R027 news choices each replace its focal
  agent's order in the ORIGINAL source auction. Retain other13 traders' orders,
  opening accounts/history and exact allocation RNG. One-agent intervention,
  not R033's two-agent fresh-state study or fresh replies. No response selection.
- [x] Exact original-auction replay gate; source/choice/input/prompt hashes and
  resource-feasible accepted quantities checked. All4 old frames/3 news/3 draws;
  B/C remain untouched/selectable. Original4096 Qwen v2 shown-length prompts,
  not pooled with8192/hidden-length studies. No extra API.
- [x] Canonical clearing/settlement/payout offline: accepted headline-minus-
  silent vs filled signed flow, price, counterpart and both one-auction stay-put
  marks. Base dividend/benchmark fixed for contrasts; same-order .8/1.2
  accounting variants are not extra draws/behaviour or new actual shock paths.
- [x] Audit/plot/interpret/preserve. Explicit RETROSPECTIVE conditional execution
  counterfactuals from observed replies, no fresh confirmation/independent full
  markets/trait causality/human validation. Archive separately-labelled R033
  failure and R034 extension/raw sources. No retry or old-frame substitution
  inside R033, no new API/provider grid.
  Main36 replays now verified. Add ONE explicitly POST-HOC depth sensitivity:
  regenerate only MM current quotes with quote_size20 instead of10, same
  opening cash/inventory, spread/skew/cap, histories, target replies and RNG.
  Must reproduce original quotes with size10 first. Revalidate resource/cap
  limits. Apply to all36 cases, no new sampling or default selection; this is
  current-book robustness, not regenerated-history/empirical liquidity validation.
  DONE: all36 base and36 deeper-book counterfactuals; original source quotes/
  full20-round prices/trades exactly replay. Arjun2882 positive accepted60 vs
  filled14(deeper20.67), negative accepted-6.67 vs filled+7(deeper+10.33).
  Meera1441 same negative sell goes0->10 fills with more MM depth. Mixed/nulls
  retained; no new reply, human/trait/full-market validation or default change.
  6048 analytic one-auction wealth-identity checks pass. Corrected manual draft
  A1441 count18->9 explicitly; old draft/manifest retained, numeric data intact.
  ZIP runs/news_execution_20261104_evidence.zip,1,629,573bytes, SHA256
  23fda86c514a776521b4d2359d4d2b1c61a9bb58ea943408f62491684dc47504;
  148 files/330 recursive secret checks, all ZIP/member hashes verified and
  old archives unchanged. No active API job/retry/provider grid. Fresh-state
  R033 confirmation remains unrun; this closes only the separate bounded work.

## R032 - Bounded pass closed; partial evidence retained (2026-11-04)

- [x] Select published design/reference anchors and write a concise evidence/
  limitations map. Reanalyse saved R02012 and R0303 long quiet rule markets;
  no new broad background sweep or externally calibrated pass claim.
- [x] Freeze one A-only horizon-disclosure pilot, fresh seeds7403(+20%) and
  8517(-20%),24 rounds/event11. Shown/hidden recording length from round1,
  matched within seed, rotate order. Only remove /24 in initial round line;
  all shared continuing-stock/economic/persona/rule information unchanged.
  Runtime research adapter must log ACTUAL sent messages and its version;
  original simulator/A/B/C/v2 source unchanged and still selectable.
- [x] Four zero-API quiet/shock rule companions before live cases; gate on
  engineering matching/accounting only, never desired financial directions.
- [x] Attempt four fresh live markets ONCE,192 normal planned decisions, no reflections;
  same Qwen8192/temp.3/low/timeout180, per-arm90/1.1M, phase360/4.4M.
  Freeze primary late executed net flow(last3) and both wealth marks plus
  exposure/quotes/fills/MM/news paths. Single scenario per shock direction;
  horizon contrasts are small pilots, not causal news/sign interaction or
  human replication. Never resample old C or pick cases for nicer outcomes.
  STOPPED05:36 IST: all4 market arms attempted,3 full24,8517 shown partial12
  after Arjun13 timeout180s and its one identical retry also timeout180s.
  PID21424 exited; no API job active.171 HTTP/470131 reported tokens/2775388
  reservations/2 unknown usages/0 blocked.169 delivered:168 cleared,Meera13
  cancelled; one failed decision slot and22 later decisions unattempted. No
  quota/503/parse/repair/output failure. No rerun/splice or shortened endpoint.
  Study runs/20261104_045742_horizon_pilot_2617baf7. Four adapter checks and
  two scripted analysis checks pass; no change to original168 regressions.
- [x] Audit, preserve negative/inconclusive outcomes, update diary/index and
  archive. No larger horizon grid or new feature/model expansion in this pass.
  Audited readout/interpretation: runs/horizon_analysis_v2_20261104/. v1 retained;
  v2 corrects figure colors only; numeric reports identical. Positive7403 has
  zero gross/net last3 trades in both conditions, not equivalence. Downside
  terminal contrast missing. Hidden downside Arjun sells194 by21 while
  Meera holds73; descriptive execution/trajectory example, not isolated trait/
  headline or horizon causality. No default, model or production prompt change.
  Evidence ZIP: runs/horizon_environment_20261104_evidence.zip,10,645,118bytes,
  SHA25628bd727d162f6a586b2c697634318d57822f1e5d52052adc92cd9f16202cb812.
  455 member hashes and1043 recursive secret checks pass; prior archives intact.
  This closes the bounded attempt/audit, NOT the missing downside scientific
  endpoint. No more horizon work scheduled; next research milestones below
  remain proposals and require a fresh bounded design before API calls.

Reference/environment synthesis complete: runs/realism_review_20261104/
READOUT.md,report.json,background_diagnostics.png/pdf. Existing15 quiet rule
paths only, no new repetitions. R020/R030 cohorts separate, all hashes checked.
Retain original defaults; multi-outcome trade-offs are not external validation.

## R031 direction review - rebalance before more experiments (2026-11-04)

Review only: no new API calls, markets, source/prompt/config/model changes.
This roadmap supersedes treating the R030 horizon lead as the sole next stage.
R006/R019 already warned against overconcentration; cautions need concrete
research milestones. A/B/C remains selectable permanently, but is one mechanism
study within behaviour/news/market research. Keep original defaults/evidence.

- [x] Reassess internal correctness, individual behaviour, collective dynamics,
  news/control quality, fair policy comparisons and thesis value against all
  existing evidence. Record maturity/gaps and a selective shortlist in R031.
- [x] Define two core thesis questions and the claims they can support. Working
  scope: how agent information/persona/policy changes affect intended/executed
  trading and market outcomes in a controlled laboratory market. Distinguish
  internal coherence, behavioural plausibility and empirical/human validation.
  Choose one appropriate published/empirical reference and a small set of
  comparable outcomes/time scales before saying externally realistic. If no
  suitable feasible reference, narrow the claim rather than invent validation.
- [x] Environment checkpoint, mainly offline: synthesize EXISTING R020 crossed
  sensitivity and R030600-round controls, actual volumes/inventory/exposure,
  return dependence and both marks. Do not rerun the screen or select a default
  solely for lower benchmark gaps. MM share alone is not proof of unrealistic
  liquidity. Identify at most ONE mechanism/robustness variation needed for the
  eventual main finding; no full exchange rewrite or engineered stylized facts.
- [x] Attempt one bounded episode-design control alongside that environment checkpoint:
  investigate disclosed episode end, which is currently a single-case lead.
  Preserve continuation rule; decide observation window versus investment
  deadline; account for deadline beliefs already in past reasoning. Freeze
  controls/endpoints/budget before generation. No larger horizon/prompt grid,
  no replacement of primary24-round results by the post-hoc21 cutoff.
- [ ] Main behavioural/news confirmation: preselect an informative positive AND
  downside/no-signal contrast, with both buy/sell opportunities measured. Earlier
  falling snapshots/control markets exist; they do not substitute for a planned
  downside execution test. Separate public message from economic change for a
  headline claim, or explicitly define the treatment as a bundled shock. Matching
  simulator seeds alone does not ensure matched pre-event LLM states.
  Measure signed intentions/accepted/fills, exposure and capacity, then prices/
  activity/liquidity/MM and both passive marks. Retain corrected A and equal-slot
  rule policies as references; do not multiply every test into all A/B/C modes.
- [ ] Confirm a leading finding on fresh independent scenarios and ONE justified
  alternative assumption, with caps set beforehand. No universal five-seed pass
  rule, counting correlated agents/rounds as independent, resampling old failed C,
  wording tuned to force expected bias, or expanding until a desired sign appears.
- [ ] Promote at most three main findings with clear question/control/evidence/
  limitations and one useful figure each. Current candidates: execution/headroom
  measurement, market-background trade-offs, context/cost of agent components.
  Horizon and memory anecdotes remain diagnostic leads pending controls. Preserve
  all nulls/raw failures; tests, API recovery and hashes go to methods/appendix.

No new model qualification/provider comparison, social feed, multi-asset system,
continuous book or further reflection machinery without a specific blocked
research question. Do not require perfect market statistics before behavioural
work. Prioritize a coherent bounded thesis, not completion of all P1-P13 prompts.

## R030 - Last four untouched markets (completed, 2026-11-04)

- [x] User "try now, should be fine" authorizes remaining A5209,C/A/B6317.
  Freeze one between-independent-market scheduling amendment: terminal double503
  retains partial/missing market, waits60s, then attempts next untouched market.
  Other provider/auth/quota/transport, output/budget or operational fallback
  failures stop batch. Within-market stops/one-extra-attempt policy unchanged.
- [x] Four offline checks pass: all200 fake calls with true own C feedback;
  double503 cooldown/next independent market; quota stop; drift/duplicate guards.
  All simulator sources/configs/model/prompts/economics remain R028-identical;
  original168 tests unchanged, not rerun. Both old C partials remain untouched.
- [x] Retain247 HTTP/4150340 reservations/753060 known tokens/6 unknown usages/
  1 blocked. Phase caps360/4.4M within campaign810/9.9M; same per-arm90/1.1M,
  Qwen8192/temp.3/reflection0/low. Daily provider balance unverified.
- [x] Attempt the four frozen markets ONCE. First real scheduled request is
  availability check; no extra qualification/model switch or automatic restart.
  FINISHED04:21 IST; hidden PID14456 exited. Phase
  starter_code/runs/20261104_034344_sequential_tail_f50a2cdd. Inspect existing
  progress or runs/sequential_tail_progress_20261104.py and launch logs.
- [x] Audit all attempted/missing markets, actual executions/sizing/headroom,
  news paths/liquidity/MM and both passive marks/costs. At most one complete
  A/B/C scenario; preserve old secondary analyses without replacing endpoints.
  New200 HTTP/578745 known tokens/3300817 reservations, zero failures/retries.
  All9 slots attempted;7 full24, C4103/5209 partial22/19 retained. No unattempted
  slots or API job. All22 reflection cycles/23 attempt prompts and six B/C
  initial-message pairs verified; source/accounting/secret scans pass. All
  primary and post-hoc endpoints labelled in final analysis/readout.
- [x] Update diary/candidate index and seal raw/source/config/prompt evidence.
  Diary/index updated. Final analysis: starter_code/runs/sequential_final_analysis_20261104.
  Final archive runs/sequential_campaign_20261104_evidence.zip, SHA256527bf047b71a0081...
  124 member hashes/1005 recursive secret checks pass; all prior ZIPs unchanged.

## Next proposed scientific controls (not implemented or launched)

- [ ] Design a bounded episode-end disclosure control before further feature
  work: A6317 Meera22 cites few rounds left, SELL40; Arjun23/24 sells after
  realized fall. Permanent-stock rule already present. Test rather than assume
  a horizon cause; prior reasoning may carry deadline beliefs, so one late-line
  redaction is insufficient for a fully blind condition. Preserve primary24
  results and old v2 modes; round21 sensitivity is explicitly post-hoc only.
- [ ] Consider fresh downside/loss-selling controls after that review, alongside
  baseline persistence/MM dependence and actual liquidity/exposure. No automatic
  reflection default, model switch or repeated qualification. This campaign is
  exhausted; failed C endpoints may not be resampled to obtain nicer results.

## R029 - Next independent seed (stopped, 2026-11-03)

User said "try now". Only between-seed stopping is explicitly amended: permit
the previously designated seed5209 despite R028's double503. No retry/splice
of C4103, original parent files untouched; no economic/prompt/model change.
- [x] Seal linked amendment and exact copied B/C/A seed5209 configs in
  starter_code/runs/20261103_195320_sequential_next_fd0fc07c. All simulator
  sources remain identical to R028. Three run-specific offline checks pass
  (full152-call fake block with own C feedback, fatal first-slot stop,
  config/duplicate guards). Existing168 regressions unchanged, not rerun.
- [x] Retain prior150 HTTP/2507774 reservations/456004 reported tokens/2 unknown
  usages/1 blocked; phase caps270/3.3M remain within campaign810/9.9M. Same
  per-arm90/1.1M,Qwen8192/temp.3/reflection0/low, existing delivery/fatal stops.
- [x] Attempt ONCE seed5209 B/C/A only; first real planned decision is availability
  check. Stop on terminal failure; no extra probe or automatic restart. Seed6317
  remains unrun. Record PID/logs after launch; no driver/simulator edits live.
  STOPPED20:31 IST on C/Arjun20 HTTP503 plus its one retry, also503. B24
  complete,C19 partial,A unattempted; six reflections, one cancelled Meera20
  delivered HOLD (no financial round20). PID8980 exited; no API job active.
  New97 attempts/297056 reported tokens/1642566 reservations/4 unknown usages.
- [x] Audit histories/fills/exposure/news/market/MM/passive marks/costs and
  provenance; preserve all signs, partials and old analysis separately. No
  best-mode or realism claim from a single complete A/B/C scenario.
  No complete A/B/C scenario exists yet. Linked report/plots in
  starter_code/runs/sequential_next_analysis_20261103. C5209 has100 accepted
  post-news buys but13 fills; four bids below actual clearing prices. Secondary
  AFTER-stop observed horizons22/19 are labelled separately, no terminal result
  replacement or harmless-missingness assumption. All14 completed reflections/
  15 attempt prompts verified; four exact initial B/C persona pairs match.
- [x] Seal new evidence with original immutable R028 bundle; archive/checksum
  in diary. Do not rerun or splice failed markets to fill missing endpoints.
  runs/sequential_next_20261103_evidence.zip SHA256599bd886cf4772c2...
  87 member hashes/772 recursive secret scans pass; all prior bundles unchanged.

## Previous remaining-slot proposal (completed by R030)

- [x] Seal scheduling of ONLY four unattempted independent markets: A5209,
  then originally ordered C/A/B6317. Preserve both C partials permanently.
  Explicitly decide between-market stopping/pacing after delivery failures;
  within-market stops, prompts/model/economics remain unchanged. No health
  sweep or financial-result selection. Current stopped driver cannot resume.
- [x] Preserve cumulative247 HTTP/4150340 reservations/753060 known tokens/
  6 unknown usages/1 blocked within original810/9.9M ceilings. Remaining563
  attempts/5749660 reservations; four arm maxima360/4.4M fit. Provider daily
  remaining quota unverified. No new callbacks or model swap from bad outcomes.
- [x] Audit all attempted/missing markets, actual fills/limits/pre-event
  exposure, liquidity/MM, both passive marks and cost. At most ONE complete
  A/B/C scenario remains possible, not two. Keep broader realism concerns.

## Active R028 - Fresh sequential market gate (user approved, 2026-11-03)

- [x] Implement/freeze three new seeds4103/5209/6317,24 rounds/event11, same
  fourteen slots/endowments/background and combined +20% mean/uncertain forecast.
  A/B/C from round1 with actual own fills/history; C reflects every5 with memory5.
  Seed mode order ABC/BCA/CAB; no default or economic tuning from outcomes.
- [x] SAME Qwen max8192 across all modes (new study profile; no pooling old4096
  probes), temp.3/reflection0/low/timeout180. Per-arm90 HTTP attempts/1.1M
  reservations, chosen10RPM/60000 input-estimate TPM, one shared extra transport/
  503 attempt. First-block caps270/3.3M; campaign810/9.9M. Student daily remaining
  balance unverified; no billing/model/NVIDIA change.
- [x] Freeze failure policy: fatal provider/output/budget stops block; existing
  invalid-JSON HOLD/old-diary reflection fallback remains logged and marks an
  operationally affected arm, then stops further arms after that run. No rerun
  of failed cases/arms or prefix splicing. Independent-query amendment not used.
- [x] Verify offline all matching, true C execution feedback, snapshots/failure
  stops, common caps/profile, baseline controls and study/source guards.
  Full suite168 pass. New bounded runner sim/sequential_markets.py only;
  prior economic/agent/API source unchanged. Study runs/20261103_183126_sequential_markets_bb927356.
- [x] Run nine zero-API rule companions FIRST: for every seed,24-round quiet/
  combined plus600-round quiet. Gate only on engineering invariants, never
  favourable prices/liquidity. Preserve drift/persistence/negative evidence.
  Complete with zero API calls. Fresh600-round backgrounds retain return ACF1
  .157-.251 and MM volume share42.3-47.0%; not a realism validation/default change.
- [x] Attempt ONLY first seed's three live A/B/C markets (144 decisions +8 reflections,
  152 normal calls). Next two frozen seeds remain unrun pending this gate review.
  STOPPED19:11 IST on C/Meera round23 HTTP503 and its identical retry, also503.
  A/B24 complete; C22/24 preserved, all8 reflections; no round23 auction.
  PID10680 exited.140 valid decisions;150 HTTP attempts/456004 reported tokens/
  2507774 reservations/2 unknown usages/1 blocked. No cap/JSON/reflection failure.
- [x] Audit actual requested/accepted/executed orders, event paths, sizes,
  participation/MM liquidity, both passive marks, failures/costs and provenance.
  This first gate is n=1, not confirmed component/market/human-realism evidence;
  24 rounds cannot validate stylized facts. Update diary/candidate index/plan.
  Source/config/manifest/accounting audits pass; all8 own-C reflection inputs
  and both identical B/C initial messages verified. Readout/plots in
  starter_code/runs/sequential_analysis_20261103/. C metrics are partial22,
  never ranked against24-round terminals. No API job or C resume/retry.
- [x] Seal first-gate evidence, all9 rule companions, source/configs/requests/
  reflections/checks/plots and documentation snapshots.279 member hashes/630
  recursive secret-scan members pass; prior bundles unchanged. Archive
  starter_code/runs/sequential_gate_20261103_evidence.zip, SHA25621e7bd5737c73bab...
  Full checksum and limitations recorded in RESEARCH_DIARY.md R028.

## Next bounded passes after first gate review (not started)

- [x] Freeze a linked continuation amendment before further calls: first gate
  ended on delivery503, so the original runner refuses a later seed. Preserve
  C4103 partial22 and its missing rounds without rerunning/splicing them. Permit
  only the already designated NEW independent seeds; no generic resume or
  favourable-financial-outcome gate. Implemented as R029, now stopped separately.
- [x] Attempt the ALREADY FROZEN seed5209 block (B/C/A), then audit/preserve it.
  Do not tune prompts/economics, reorder conditions or pool old4096 samples
  in response to financial outcomes. Prior150 HTTP/2507774 reservations remain
  recorded; original campaign810/9.9M totals include them.
- [x] Run the frozen seed6317 block (C/A/B) and audit all nine live markets.
  Complete-seed comparisons then have at most1 scenario because both prior Cs are partial;
  no repeat of a failed arm, prefix splicing or favourable-seed selection.
- [x] Synthesize all requested/accepted/executed sizes, exposure before news,
  market-maker dependence, paths/liquidity, both passive marks and actual costs.
  Retain A as reference and B/C selectable; no automatic reflection upgrade.
  Decide the next scientific question from this full evidence, keeping rule
  baseline realism and the broader thesis goal alongside component effects.

## R027 - Completed scheduled cases with explicit missing outputs

R026 stopped at the unchanged4096 output cap:50 valid decisions/12 reflections,
70 cumulative HTTP attempts/912386 reservations. The failed C reply used all
4096 tokens in reasoning and returned no order. It will NOT be rerun or counted
as HOLD. This is an explicit batch-stop amendment, not a prompt/model/cap change.
- [x] Freeze a specific research-tail driver and offline-check it. Normalize
  that actual length failure as one missing case, retain all prior valid data
  and diaries, then attempt57 remaining cases +12 reflections at SAME settings.
  Driver runs/component_tail_20261103.py; three run-specific offline integrity
  checks pass. All simulator sources unchanged;162 regression tests previously
  pass. Prepared runs/20261103_174525_components_tail_90002a97.
- [x] Remaining caps194 attempts/3087614 reservations within original264/4M.
  Isolated decision output/JSON failures remain missing and the next independent
  case proceeds. Provider/budget/reflection failures remain terminal. No hidden
  retries, repeated failed choice or new model. Actual market error policy unchanged.
- [x] Run once, audit all108 scheduled slots including failures, report valid
  counts and partial contrasts. Never claim108 valid replies if any are missing.
  Preserve original R025/R026 artifacts and record amendment/limitations in diary.
  Complete at18:01 IST; PID12952 exited.107 valid +1 capped/missing slot,
  all24 reflections. No unattempted inputs or API job. Cumulative139 attempts/
  424042 reported tokens/1816876 reservations/7 old unknown usages; original
  caps264/4M preserved. Final analysis runs/component_final_analysis_20261103/.

## R026 - Explicit R025 continuation (stopped at output cap)

User authorized continuing after the503 stop; no claim that availability has
been independently verified. First pending real query doubles as the delivery
check; no qualification/probe sweep or provider substitution.
- [x] Add/test one versioned continuation for this frozen study only. Skip all
  34 completed choices; reuse the existing fourth-frame/repeat1 C diary for
  its two missing news queries. Then execute remaining original blocks/order.
- [x] Freeze parent hashes, pending inputs, source and remaining budgets BEFORE
  calls.74 decisions +16 fresh reflection calls; caps215 attempts/3358787
  reservations, retaining all49 prior attempts/641213 reservations within the
  original264/4M. No economic/prompt/model/delivery-policy changes.
  Full suite162 pass. Prepared runs/20261103_172911_components_continue_f62a08f1;
  controller addition only, all existing R025 source files/parent evidence match.
- [x] Run once; stop on terminal failure, preserve parent and new artifacts
  separately, no further automatic restart. No simulator edits during live run.
  Stopped on output cap:16 new valid choices/four reflections, no HTTP errors.
  50 valid choices total; actual failed cap slot retained by explicit R027 amendment.
  PID11356 exited. Prior phases remain sealed; no rerun of successful cases.
- [x] Audit combined coverage/usage/inputs and scientific contrasts without
  overwriting the earlier partial analysis. Update diary and thesis index;
  continue to distinguish conditional queries from full-market evidence.

## Bounded pass R025 (2026-11-03, stopped with partial evidence)

- [x] Implement/freeze a fixed-history news/component study using ALL four
  designated R024 control-market round11 frames, without changing accounts or
  inventing trades. Positive/negative/no headline x A/B/C x three fresh repeats:
  108 decisions. These are fresh calls on reused states, not held-out markets.
- [x] Implement C's two real reflections per frame/repeat from that agent's
  actual rounds1-5 and6-10 outcomes, carrying the first reflection into the
  second. Share the resulting pre-news diary across its three news variants.
  This adds24 calls; total132 planned. It conditions on a common A-generated
  past, not an endogenous C trajectory, execution test or news-retention proof.
- [x] Verify exact source records, only-treatment prompt differences, no
  future/hidden inputs, fresh independent choice instances, unique IDs,
  counterbalanced mode/news order and terminal-failure stops offline.
  Full suite158 pass. Prepared runs/20261103_023441_news_components_da6bdf79;
  no prior simulator source changed, only the new bounded runner added.
- [x] Freeze source/inputs/settings before calls; run Qwen once with existing
  opt-in one-extra-attempt delivery policy. New separate study caps264 total
  attempts/4M conservative reservations, chosen10RPM/60000 input-estimate TPM;
  all retries/JSON repairs count, unknown failed usage retained. No NVIDIA or
  model substitution. Stop on terminal provider/output/budget/parse/reflection
  failure and preserve partials; no blind restart or general replay framework.
  Stopped at03:04 IST:34/108 choices,8/24 reflections. Terminal503 and its
  single retry both failed; PID15368 exited, no API job active. No restart.
  Full suite158 pass, all34 choices valid/unclipped, no full repeat set.
  49 attempts/135427 reported tokens/641213 reservations/7 unknown usages.
- [x] Audit every available condition and negative/null case. Report requested/accepted
  quantities, natural buying/selling headroom, executable price intervals,
  repeat variation, A/B and B/C news contrasts, failures and reflection cost.
  No orders execute; no full-market/performance/human-realism conclusion.
  Update diary, candidate index, working notes and next bounded decision.
- [x] Attempt all108 scheduled decisions and24 reflections (not achieved in
  R025 alone; linked R027 completes107 valid +1 explicitly missing decision).
  Historical partial analysis:
  starter_code/runs/component_analysis_20261103/ (READOUT.md/report.json).
  Historical remaining_work.json inventoried74 pending choices +16 reflections;
  final component_final_analysis_20261103 has zero unattempted slots.
  Any future explicitly linked continuation must preserve prior usage and the
  last block's generated diary; remaining caps215 attempts/3358787 reservations.
  This is an inventory, not a resume implementation or automatic restart.
  No model switch, new retry framework or qualification sweep in this pass.

**Prior checkpoint, 2026-11-03:** R024 COMPLETE. The existing background
job finished 2026-11-02 23:06 IST during the user's usage-limit pause; PID22644
exited. All 8 rule + 8 live 20-round markets and 24 same-state queries completed.
No API job is active; do not rerun after the reset. Final readout/audit:
`starter_code/runs/news_query_first_analysis_20261102/` (READOUT.md/report.json/
delivery_audit.json). All phases count 402 attempts/1122587 reported tokens/
4879158 reservations/10 unknown usages/1 blocked request. Seven transport retries
recovered; no server-503 retry was needed live. 150 offline tests pass.
Meera's first-seed positive headline contrast is mixed in seed2882; both Arjun
frames lack buying headroom. Combined real-shift/news gaps are smaller in both
seeds, but market pre-event states differ. Preserve negatives and constraints,
old partials, order/fill distinctions, both passive marks and A/B/C.
The old R022/R023 stopped checkpoints below are history; R024 supersedes their
completion status. Read the diary before new work. No model/default change.

Approved by the user on 2026-11-02. This is a resumable working checklist;
lasting decisions and evidence belong in RESEARCH_DIARY.md. Complete and verify
one bounded stage per coding pass. Do not mix later research features into an
unfinished foundation. The existing staged diary/AGENTS changes belong to the
user's working tree; do not stage, unstage, or commit them automatically.

## Stage 1 - Correct execution and controlled randomness (complete)

- [x] Enforce buy/sell budgets including transaction tax and the actual maximum
      market-order execution price; reject invalid/non-finite orders safely.
- [x] Initialize share cost basis explicitly (default: initial reference price).
- [x] Correct tick/band treatment and remove systematic equal-price ID priority.
- [x] Validate a whole settlement batch before mutation; conserve shares and
      cash plus the tax ledger and prevent accidental borrowing/shorting.
- [x] Connect top-level news; isolate environment, allocation, and trader RNGs.
- [x] Make malformed LLM replies and exhausted API calls produce logged HOLDs;
      retain the current decision prompt and memory behaviour as a simple base.
- [x] Add meaningful regression tests and run the original smoke checks and a
      mock end-to-end simulation. Record engineering outcomes, not realism claims.
- [x] Update diary, README, and this checklist; stop at the verified boundary.

Acceptance: reproduced negative-cash and array-JSON bugs are fixed; valid trades
respect original limits; equal-price allocations are proportional with seeded
integer tie handling; population changes do not change dividends; mock runs are
repeatable with valid logs. No paid or live LLM calls are needed for this stage.

## Stage 2 - Explicit experiment configuration and coherent economics (complete)

- [x] Add checked configuration and reject unsupported options.
- [x] Specify time units, cash-flow/auction timing, conservative baseline rate and
  dividend scales, and valuation assumptions. Initially use simple cash flows
  and permanent shocks, keeping legacy configs identifiable as legacy.
- [x] Add two-sided, capital/inventory-constrained market-maker orders and liquidity
  diagnostics, without introducing a persistent continuous order book.
- [x] Validate long rule-based runs, cash growth, tax/dividend/interest accounting,
  and expected-value response to permanent shocks.
- [x] Document the economic assumptions and engineering results in the diary.

Chosen bounded economic baseline: one round is a trading session, cash earns a
configured per-round rate, and closing holders receive that round's random
dividend after the auction. Use positive bounded IID dividends with a configurable
relative noise level and permanent mean shifts; mean/r is the stationary-regime
risk-neutral benchmark, not an externally calibrated price prediction. Keep the
original AR(1) demo explicitly marked legacy. Add per-round cash-flow conservation
and liquidity records. The A/B/C agents share these economic rules.

## Stage 3 - Minimal comparable agents and pilot provenance (complete, bounded)

Review adjustment (approved direction): bound this stage to selectable
conditions and minimum reliable provenance/usage limits. Bring a small live-model
pilot forward once those essentials exist. Do not require a polished cache,
general replay framework, exhaustive metrics suite, or further architecture before
learning whether real agents behave usefully. Investigate the baseline cycles in
a small rule-only sensitivity check, keeping that distinct from live-agent tuning.
Continue to evaluate individual behaviour, macro dynamics, and news/brain-type
comparisons alongside A/B/C. See R006; do not optimize solely for value tracking.

- Define/version condition A (raw observations + actual recent outcomes), B
  (A + factual summaries), C (B + reflection). Preserve A as a selectable mode.
- Add run manifests, model/provider/prompt/persona versions, raw/validated/executed
  orders, every call/repair/reflection, and failure records. Save responses for
  later replay; a general replay command is explicitly deferred.
- Record code/config hashes and dirty state; never log credentials.
- Add request limits, measured usage/cost accounting, and an explicit pilot
  budget before any paid-model evaluation.
- Test all modes offline with deterministic/scripted clients. Do not interpret
  mock differences as evidence about real LLM behaviour.

Bounded acceptance checklist for this pass:
- [x] A/B/C are selectable; all share raw facts, persona, recent verified fills,
  and market constraints. B adds computed facts, C adds periodic reflection.
- [x] Memory records executions, unfilled orders, cash income, and account state;
  reflection never replaces authoritative portfolio bookkeeping.
- [x] Save per-call attempts including reflections, exact source/config/persona
  provenance, usage/cost estimates, and explicit completed/failed/budget statuses.
- [x] Enforce shared request/token reservations and a declared-price cost ceiling
  for live pilots; unknown billing/usage stays explicit. No hidden HTTP retries.
- [x] Test leakage, matching, reflection failures, and budget stops before versus
  after settlement; preserve short mock A/B/C runs as engineering evidence only.
- [x] Screen unchanged baseline versus inventory_skew=0 and varied trend horizons,
  2x2 across seeds 101/202/303, 1000 rounds, same resources and exogenous paths.
  Keep current baseline regardless of which screen cell looks best.
- [x] Update a concise diary entry and candidate index, then stop at the pilot
  checkpoint. Full caching/general replay and a broad metrics rewrite are deferred.

## Stage 4 - Small live-LLM diagnostic pilot (integration checkpoint)

User update: explicitly switched the primary provider to BharatCode student
access, model qwen-3.8-27b, with API_KEY in starter_code/.env. Gemini access
failures are historical, not an instruction to keep retrying Gemini.
Bounded current pass:
- [x] Verify authenticated model access; load API_KEY only for BharatCode's
  official HTTPS endpoint; keep it out of configs/artifacts/source control.
- [x] Adapt the existing pilot for provider settings, queue timeouts and
  student-included usage; test offline before generation.
- [x] Run the same 18 diagnostic cases with raw requests and exact settings.
- [x] If usable, complete six matched four-round A/B/C micro-runs (two seeds,
  two LLM personas), at most 96 generation attempts / 700000 byte-based reserved
  tokens for the batch. No larger study or paid upgrade in this pass.
- [x] Audit matching, actual orders/fills/reflection, usage and failures; retain
  null results and update the diary. No cross-provider causal comparison.

BharatCode integration verified with 96 offline tests. Catalog saved at
starter_code/runs/bharatcode_access_20261102/models.json. Active v4 Qwen protocol:
temperature 0.3 decisions, 0 reflections; low reasoning effort; output cap 2048;
180-second queue/network timeout; chosen 10 RPM / 60000 byte-based input
estimates per minute (not asserted provider limits). Zero incremental per-token
price within the user-reported included student allowance; no paid upgrade.
Qwen probes completed in `20261102_050006_qwen_probes_e918237e`: 18 requests,
10209 reported tokens, no HTTP/parse/truncation errors. Direct arithmetic 8/8;
one empty-account buy was safely clipped; headline pairs bought versus HOLD,
risk-trait pairs were mixed. All six markets completed. Whole batch: 71 calls,
76839 reported tokens, one recovered empty reply, no API/output-cap failures.
Matching and executed-memory audits pass. See qwen_pilot_diagnostic_20261102.json
and R014. No API jobs remain running. Do not rerun completed API phases as a resume.

Historical next-pass proposal after R014 (completed/superseded by R016-R018):
- Disclose common price-band/tick/conservative market-buy reservation rules to
  every agent condition, version the common prompt, and verify the disclosure.
  Eleven market-order reductions here are not automatically numerical errors;
  model agents were not told the full reservation formula. No change implemented
  yet; do not relabel the current v1 prompts/results after making it.
- Repeat fresh contextual-numeracy, risk and news scenarios before freezing a
  larger study. Preserve empty-account failure and null/mixed responses.
- Include both closing-price and regime-benchmark valuations in evaluation;
  neither is a realized liquidation return or proof of welfare/skill.
- Advance toward news/intervention and equal-resource brain comparisons;
  retain A/B/C as one explanatory study. No general reflection benefit follows
  from two four-round diagnostic scenarios.

Completed capability follow-up (DeepSeek key will be provided later):
- [x] Disclose the actual shared tick/band/tax, raw-price cash reservation,
  holding limits and partial-fill rules, retaining all A/B/C treatments. Increase
  the common prompt version; preserve old data without relabelling it.
- [x] Verify configured rule propagation, non-tick boundary/tax examples and
  common information parity offline. Do not alter auction or settlement policy.
- [x] Freeze a fresh model-neutral battery: 14 cases x 3 independent repetitions,
  including objective mechanics/account-memory tasks and discretionary resource,
  news, disclosed-value and one-trait risk contrasts. No profitable-action oracle.
- [x] Run Qwen only, at most 54 attempts / 400000 reserved tokens, preserving
  failures and per-case results. Use the existing included student access.
- [x] Audit all first attempts and repairs, report family/repetition results,
  and preserve the exact battery for the later DeepSeek challenger. No claim of
  causal before/after improvement from comparison with older scenarios.
- [x] Once the battery and adapter specification are concrete, request local
  NVIDIA_API_KEY setup. No NVIDIA generation calls before a key is available.

Capability checkpoint: 107 offline checks passed then (118 after R018). Common prompt is
comparable_agents_v2_disclosed_rules; old v1 artifacts remain unchanged. Frozen
battery: starter_code/runs/20261102_053910_capability_battery_fa9fc215/battery.json.
Qwen qualification is complete (R017). User will provide NVIDIA's key later;
no NVIDIA request has been made and the challenger need not block core work.
Interruption update: the prior turn ended its runner after 13 completed cases;
no runner survived. `20261102_053929_capability_qwen_6cdca7bd` is preserved as
externally_interrupted, with possible unlogged in-flight usage left unknown.
User asked to continue and will provide NVIDIA's key later. One clean whole
42-check Qwen restart is underway using the unchanged frozen battery; partial
results will not be pooled or selectively replayed. Fresh bound: 54 attempts /
400000 reservations, in addition to the preserved prefix (13 known calls plus
at most one unlogged request possible for the sequential runner). No NVIDIA call.
Completion: clean restart completed 34 checks, then a TimeoutError stopped it.
The exact remaining eight were frozen in capability_remaining_20261102 and
completed by 20261102_183644_capability_qwen_2d10464c with the remaining allowance.
Combined: 42 checks, 43 requests including the timeout, 49019 reported tokens,
291582 reservations; objective 54/54 fields and all 30 delivered orders passed.
No current API process. The next-pass visibility/control/protocol work identified
at that checkpoint is now complete in R018; see Stage 5 for the next live pilot.
Objective tasks have numeric oracles; discretionary choices have no profit/sign
oracle. News/persona/value cases use production zero-tax rules; resource cases
include explicit synthetic tax/tick stress. Models will see the same stored
messages, with requested sampling/hidden-compute differences recorded separately.

Historical Gemini pass (user provided GEMINI_API_KEY in starter_code/.env):
- [x] Verify key presence without displaying it; authenticated read-only model
  discovery confirms gemini-3.8-flash is listed for this key.
- [x] Load the Gemini key locally, add shared pacing and fail-fast provider
  stops, then verify offline. Preserve the default mock behaviour.
- [x] Freeze a tiny probe protocol before looking at behavioural replies:
  syntax/arithmetic, resource constraints, signal sensitivity and a one-trait
  risk contrast; retain raw requests and negative/inconclusive outcomes.
- [ ] If access/quotas permit, run short matched A/B/C trials with common
  scenarios and at least two independent repetitions. These are diagnostic
  micro-runs, not evidence about long-run market statistics or human realism.
- [x] Bound the whole live pass to at most 96 generation attempts, conservative paid-rate
  reservations of at most USD 1.00 for the new 3.8 batch (free eligible model;
  account billing unknown; original Lite batch had a separate USD 0.25 ceiling),
  no hidden retries, and stop on quota/auth failures. Do not enable billing.
- [x] Preserve available results/protocol/source and update the diary with
  limitations. The primary 3.8 live trial itself remains incomplete.

Historical Lite progress (superseded as primary model by user): fixed probes completed in
`starter_code/runs/20261102_034741_live_probes_73582e3f/`: 18 attempts, no API
errors/repairs; 8/8 direct arithmetic fields correct. Value=100 versus 120
changed HOLD to BUY 10 in both repeats. Risk-label-only and unverified-headline
pairs stayed HOLD. All constrained orders were feasible, but explanations
contained incorrect cash claims and an invented prior-history claim. Preserve
these limitations. Three market runs completed for seed 704; seed-905 C was
externally interrupted after two logged financial rounds when the user selected
3.8 Flash. See model_switch.json and the partial run's interruption.json; usage
for an interrupted in-flight request may be missing. No Lite job remains running.
Do not pool the models. Do not blindly rerun API commands: reruns make fresh
requests and are not resumes. Current offline suite: 93 pass.

Historical 3.8 primary pilot: gemini-3.8-flash, reasoning_effort=low, output cap 2048,
provider-default sampling (send_temperature=false), protocol
first_live_diagnostic_v3_flash38_default_sampling. The first access attempt
`20261102_040526_flash38_probes_09b9a76b` stopped on HTTP 503 with no model
answer; the explicit retry `20261102_040700_flash38_probes_9054fea8` also stopped
on HTTP 503. These are availability failures, not model-quality evidence.
The native-route diagnostic `20261102_040821_flash38_native_access_0e0abbd4`
also returned HTTP 503 / UNAVAILABLE. No 3.8 answer has returned. Stopped after
these three access attempts; no API job or automatic retry remains running.
Next pass: retry the unchanged v3 protocol when access is available, inspect
its results, then run the matched markets. Do not infer a general provider outage
or quota exhaustion from these responses.
Model/reasoning/cap changes are recorded; this is not an isolated model-size
ablation. Save new probes and matched markets independently of the Lite batch.
User has Google Pro, but do not infer the API project's quota or billing tier
from that subscription. Keep five RPM and fail-fast provider stops until actual
quota evidence supports a change. No billing setup or upgrade is authorized.

Screenshot update (R012): user supplied AI Studio quota evidence for "Gemini
Project", Free tier. 3.8 Flash shows 5 RPM and 250000 TPM; Lite shows 15 RPM and
250000 TPM. Daily limits are not legible; 28-day peaks are not remaining quota.
The existing five-RPM / 15000-input-estimate pacing is within those ceilings.
An unchanged v3 retry `20261102_042706_flash38_probes_9982497f` again stopped on
its first HTTP 503, with no returned answer. No API job remains running.
User's next explicit single retry, `20261102_044650_flash38_probes_2b43ef3b`,
made one request and timed out at 90.223 seconds without an HTTP status/answer.
No automatic or background retry is active; see R013.

- Connect one available provider after the corrected baseline and provenance
  exist. Ask for provider/key only when actually needed; use environment settings.
- Provider checkpoint: user selected Gemini 3.8 Flash after the initial Lite
  pilot. R008's original model selection is superseded; see R009/R010. Verify
  3.8 generation access and keep the same model/settings across its A/B/C runs.
- Before a free-tier market run, add minimal shared request pacing using the
  account's actual RPM/TPM limits. Existing cumulative reservations do not enforce
  provider rate limits. Start with tiny probes; record quota failures separately
  from agent HOLD decisions. Do not enable billing or assume zero prices on a paid
  account. Keep one exact model/settings across A/B/C and record returned IDs.
- Run fixed-observation probes for arithmetic, feasible orders, input sensitivity,
  and one-trait persona differences; keep wording and scenario versions.
- Trial short sequential A/B/C runs, record costs/failures and independent repeats.
- A live comparison with the original buggy simulator is not needed for the
  thesis. A corrected A/B/C component comparison is worth preserving.

## Stage 5 - Headline experiments and credible baselines

Completed R024 (user approved continuation; UI reports 663.8K/10M used today,
resets midnight IST; this is user-reported allowance evidence, not measured RPM):
- [x] Add opt-in HTTP-503 handling, share the one-extra-attempt limit with
  transport retries, honor valid Retry-After up to 60s (otherwise stop), default
  10s wait without header. No auth/quota/client/certificate/output-cap retries.
- [x] Verify safe header parsing, budget/logging and unchanged prompts offline (150 pass).
- [x] Freeze query-first linked phase: first-seed 12 same-state decisions FIRST,
  then five missing markets, then second-seed 12 queries. No favourable selection.
  Explicitly reallocate restart allowance under SAME global 688 attempts/9M
  reservations: prior 171/2055022; each of 5 arms 80/1M; each query half 24/.5M
  gives maxima 619 attempts /8055022 reservations. Older per-arm caps are
  superseded only for this documented phase; all prior work remains counted.
- [x] Run once, stop on terminal failure, no blind phase restart; audit all
  results/limits and update R024. Model, economics, personas and A/B/C unchanged.
  Started hidden PID22644, driver runs/news_query_first_20261102.py;
  study delivery_v4_query_first. Source/config/first-query frames are frozen.
  Complete: all five missing markets plus both query halves, finalized before
  this resumption; no further API calls. Audit date2026-11-03; all hashes,
  matched resources/payouts, exact source/query inputs and global bounds pass.
  Seven transport retries recovered; no live 503 retry. User's usage reset
  requires no rerun. See R024 final entry and READOUT.md.

Next bounded scientific work (PROPOSED, not started):
- [ ] Freeze independent positive/negative/no-news confirmation across both
  balanced and constrained portfolios. Retain naturally constrained nulls;
  analyze buying/selling headroom instead of selecting only favourable states.
- [ ] Preserve the full A simple / B factual summaries / C added reflection
  question. Fixed-state A/B isolates representation; C must use actual logged
  histories/reflections, with retention and extra calls explicit. Do not invent
  reflections or assume absence of an exact old headline proves forgetting.
- [ ] Use that evidence to choose adequate independent full-market confirmation
  and horizon. Keep pre-event divergence, policy order-size differences, fills,
  market activity/dynamics and both passive returns in view. No model switch or
  broad infrastructure extension is motivated by the current mixed results.

R023 ended with partial evidence (user approved continuation after R022):
- [x] Opt-in one transport retry per request group, zero by default; each HTTP
  attempt reserved, paced, logged, unknown usage retained. No HTTP status/auth/
  quota, certificate-validation, malformed-JSON or output-cap transport retries.
  Preserve one separate JSON repair; unique group/attempt IDs and safe reason
  type/code metadata. Do not change prompts, personas or economic mechanics.
- [x] Test recovery, exhaustion, budget/pacing, JSON-repair separation and error
  redaction offline. Confirm old payloads and default financial regression.
- [x] Freeze a new linked delivery phase for ONLY five unfinished market arms
  and the 24 original probes. Combined/1441 is a fresh full arm, keeping its
  old 9-round partial separate; deduct 20 prior attempts/226543 reservations
  (remaining 60/773457). Other four arms 80/1M; probes 48/1M. Prior 142 attempts
  and 1709925 reservations remain counted; whole original bounds still apply.
- [x] Run once with shared pacing, preserve every retry/error and stop on a
  terminal failure; no further phase restart this pass. NVIDIA remains deferred.
  Started hidden PID 8832, recovery_transport_v3, driver
  runs/news_recover_20261102.py. Inspect progress/summary before any calls.
- [x] Audit all phases/partial evidence and report actual news findings/limits
  in R023, preserving A/B/C and avoiding general human-realism claims.
  Stopped as specified: HTTP 503 on round 15, no transport retry eligible;
  new partial 14 rounds stays separate from old 9-round partial. No further calls.

Historical R023 proposal (implemented in R024): opt-in server-503 retry with safe header
parsing and bounded wait/attempts, distinct from auth/quota/client errors. Keep
all attempts/unknown usage within original GLOBAL 688/9M ceilings; explicitly
document any per-arm restart allowance changes before calls. Run available
first-seed same-state pairs first, label subset, then missing frames as available.
Avoid another long run that reaches no clean headline queries. No model switch.

News pass stopped with partial evidence (R022, after its one allowed continuation):
- [x] Implement/freeze news_live_pilot_v2_matched_event_probes before calls.
  Preserve v1's eight A markets, seeds 1441/2882, 20 rounds/event 11, four cells,
  qualified Qwen profile, counterbalanced order and per-market 80 attempts/1M
  reservations. Add eight equal-slot rule counterparts (no API).
- [x] Implement the planned 24 same-state event queries: every control run's two LLM frames
  at round 11, crossed with no headline/the same forecast, three repetitions.
  Derive exact messages/state from saved records, no outcome-based frame choice.
  Extra cap 48 attempts/1M reservations, for total 688 attempts/9M reservations.
  This explicitly amends v1; its numerical market design remains unchanged.
  Remaining student quota is unknown. No billing or NVIDIA calls.
  Not generated: second seed's control is unavailable. Four available first-seed
  variants reproduce source prompts exactly and are marked prepared/not run.
- [x] Verify matching, hidden-state separation, snapshot derivation, metrics,
  failure stops and end-to-end operation offline before generation.
  Full suite 139 pass; final targeted five pass after clarifying failed-arm counts.
- [x] Freeze source/config/protocol, start bounded execution with shared pacing in a hidden
  sequential job; stop whole study on incomplete/provider/output-cap failure.
  Started once, hidden PID 26812, study runs/20261102_202946_news_pilot_786a0370.
  Frozen study SHA256 starts 0a901d2fc24f41d5. Inspect progress/process/summary;
  do not restart or modify simulator source while this job is active.
  Update: original stopped on URLError/no HTTP status, one unknown-usage call.
  Explicit continuation_1 (PID 14112) retains 9 complete markets, repeats only
  the failed zero-round arm then unstarted cases, with used budgets deducted.
  Driver runs/news_continue_20261102.py; first arm now 78/985870. No further
  restart in this pass. All simulator source/model/prompt/economic settings match.
- [x] Complete all eight live arms and 24 same-state queries (not achieved in
  R022; completed later in R024, with linked source/delivery profiles retained).
- [x] Report all available cells, missing/partial arms and pre-event differences; requested/accepted/executed
  quantities, LLM trade involvement, liquidity and both passive wealth marks.
  Preserve no-response/non-convergence cases. Twenty-round/two-seed results
  are exploratory; paired snapshot queries are not full market counterfactuals.
- [x] Audit artifacts, update R022 and review evidence before confirmation/A-B-C.

Historical R022 proposal (implemented in R023/R024; no restart of old phase):
- [x] Opt-in transport retries at request orchestration, every HTTP attempt
  logged/budgeted/paced and unknown usage retained. Zero-retry default preserved;
  no retry on auth/quota errors or output truncation; distinguish JSON repairs.
- [x] Safe underlying error reason-type diagnostics and offline failure tests.
- [x] Version/link the changed delivery profile and recover only incomplete
  arms after deducting all used budgets. Preserve old complete and partial data.
  Do not mistake the partial pilot for a confirmed news or brain-type finding.

Completed bounded live follow-up after R020 (R021):
- [x] Add only the fixed-input runner/action scoring for the saved
  matched_trait_states_v1 battery; reject input/render drift before calls.
- [x] Verify scoring, failure handling and exact-input use offline (134 tests).
- [x] Run Qwen only, 48 scheduled decisions / maximum 96 HTTP attempts /
  1000000 conservative token reservations, included student-token prices zero.
  Temperature .3, low effort, cap 4096, timeout 180; chosen 10 RPM / 60000
  input-estimate TPM, fail fast, no hidden HTTP retry/model substitution.
  Quota remaining is unknown. NVIDIA stays deferred. Freeze scoring before calls.
  Started once as hidden PID 11360, run 20261102_195440_behaviour_qwen_ee95d92d.
  Do not blindly rerun: inspect logs/process/summary first. Inputs hash begins
  67929bd362979762. Request and source snapshots are already on disk.
- [x] Preserve every choice/repair/error and matched risk/gain-loss contrasts,
  failures excluded from preference numerators but retained in reliability.
  No action/profit oracle, no assumed persona effect and no simulated fills.
- [x] Record exact metadata, limitations, useful/null findings and next decision
  in R021. Do not start the news markets before reviewing this bounded battery.
  Complete: no new wording sweep/qualification; retain Qwen. Next bounded pass
  is the v1 news feasibility pilot with matched fourteen-slot rule counterparts,
  passive accounting and explicit LLM intent/fill/volume influence. Do not count
  this 48-response synthetic diagnostic as a market A/B/C study.

R019 review checkpoint (user has since resumed): the v1 live
pilot below remains preserved, with diagnostic scope only. Its 20 rounds/two
seeds/two LLMs cannot support long-run market or human-realism conclusions.
Before expanding, balance the next bounded work across:
- [x] Limited market-background sensitivity: MM skew and last-payout valuation
  versus a past-payout average with equivalent information; preserve original
  conditions and examine liquidity/activity as well as mispricing. No tuning
  solely to pass stylized-fact thresholds or manufacture expected effects.
- [x] Minimal fresh one-trait/state checks, including gain/loss context;
  persona bundles and reasoning strings alone cannot establish behavioural bias.
- [x] Passive no-trade performance under the same payout/rate path and both
  wealth marks; equal-resource fourteen-slot rule counterpart for brain effects.
- [ ] Use the small news pilot for decisions/feasibility, then select adequate
  independent confirmation and horizon from variability. Retain A/B/C as an
  explanatory comparison without letting it displace market/behaviour research.
R020 implements the marked accounting/templates and rule sensitivity checks.
R021 completed the live trait diagnostic with contextual/null results; broader
behavioural/brain comparisons remain unverified.
Do not restart qualification or add general infrastructure in place of science.

Completed bounded response to R019 (R020):
- [x] Add selectable past-dividend averaging for fundamentalists; default one
  preserves existing decisions. Only already observed payouts, no future truth.
- [x] Add read-only passive-account evaluation with both wealth marks and a
  clear conditional-price-path interpretation; verify hand-calculated examples.
- [x] Build equal-resource fourteen-slot rule/mock templates; preserve background
  slots, rule parameters and public information. No live API integration change.
- [x] Freeze/run a rule-only 2x2 screen: skew .02/0 x dividend window 1/5,
  seeds 317/628/939, 600 no-news rounds, hidden benchmark, same fourteen slots.
  Report price, dependence, liquidity/activity, inventory and passive-relative
  outcomes together. Keep every case and default; no realism score optimization.
- [x] Prepare a small versioned matched-state trait/gain-loss battery with exact
  messages and repeats, without generation or a profitable-action oracle.
- [x] Verify, preserve source/config/run provenance and update R020. Stop at the
  evidence review; choose any live follow-up from these findings, not blindly.

Completed bounded pass (R018):
- [x] Add explicit announcement visibility independent of economic effect;
  existing events remain public by default. Hidden events may omit a headline.
- [x] Preserve a researcher-only event audit; hidden event labels/effects must
  not enter observations or reflection memory. Keep legacy announced rows in
  events.csv; its benchmark field remains researcher-only, never an agent feed.
- [x] Test config round-tripping, multiple events, timing, cashflows and prompt
  non-disclosure. Demonstrate that explicit fundamental disclosure is a separate
  information channel; keep it OFF in the four-cell information study.
- [x] Freeze a 4-cell rule-only protocol before running: actual permanent mean
  shift (no/yes) x public forecast (no/yes); 3 fresh seeds, same resources and
  exogenous draws, 600 rounds with event at 301. Keep all cases/defaults.
- [x] Verify exact announcement-only negative controls for rules, shared/scaled
  dividend innovations, prefix matching, event audit and financial conservation.
- [x] Preserve all configs, run IDs, source, results and limitations; freeze a
  bounded live-news pilot protocol for a later pass. No live API calls this pass.

- Freeze pilot choices; evaluate fresh scenarios/repetitions.
- Matched headline-only / fundamentals-only / combined / control news experiments.
  Visibility separation and private audit are now implemented and rule-verified
  (R018), superseding the previous proposal here; live effects remain untested.
  Retain the frozen capability run's source/inputs unchanged.
- Preserved v1 proposal (unrun, after fresh trait/state check): implement/freeze the news_live_pilot_proposal_v1 runner
  and exact configs before API work. Eight 20-round A markets, seeds 1441/2882,
  event 11, two LLMs, Qwen qualified 4096-cap profile, 320 planned decisions /
  640 maximum attempts / 8M conservative reservations. See permanent proposal
  for settings, counterbalanced order, metrics, failure rules and limitations.
  No new provider or NVIDIA key is needed. Preserve A/B/C for the later matched
  explanatory study; do not prematurely triple this diagnostic's API work.
- Equal-resource rule/LLM/mixed populations with common exogenous paths, rotated
  assignments, and modest rule-agent tuning on separate pilot scenarios.
- Report decision-level effects, price discovery, normalized performance,
  liquidity, failures, cost, and uncertainty across independent runs.
- Evaluate stylized facts on stable baselines; preserve zero-volume rounds and
  separate event windows. Treat GARCH/Hurst as optional diagnostics.

## Stage 6 - Optional extensions after the core evidence is solid

- Social forum or one policy experiment; choose based on the strongest open
  question, remaining time, and evidence. Retain null and negative findings.
- Defer multi-asset trading, a full LOB, fine-tuning, and large populations unless
  necessary for a concrete question.

## API and comparison decision

Real LLM access is not necessary during mechanical/economic repairs. It becomes
necessary at Stage 4, before selecting or tuning behavioural enhancements based
on apparent model behaviour. Keep the corrected simple mode available so A/B/C
can all be run later with the same model, matched scenarios, and comparable
settings. This avoids paying for a misleading buggy-versus-fixed comparison.

## Verification record

Stage 1 completed on 2026-11-02. Python 3.13.1, numpy 2.1.3, PyYAML 6.0.3.
`python -B -m unittest discover -s tests -v` (from starter_code): 28 tests passed,
including wrappers around all four original smoke tests. The initial sandboxed
attempt was blocked by temporary-directory ACLs; final verification ran outside
the sandbox with mock clients only. No package installation was necessary.

Preserved CLI demo: `starter_code/runs/20261102_010715_dev_mock_d9460de1/`.
60 rounds completed; round-30 news delivered; no negative portfolios or model
failures in this mock run. Its economic assumptions remain legacy, uncalibrated.
Both decision prompt templates were checked against commit 0f80f2c and remain
unchanged. Next coding pass starts at Stage 2; no live API integration is needed
until the diagnostic pilot at Stage 4.

Stage 2 completed on 2026-11-02. All 54 unittest checks pass, including the
Stage-1 suite and the original smoke tests. Preserved 1,000-session rule baseline
and matched permanent-shock diagnostics, plus a 100-session mock demonstration.
The paired rule runs match exactly before round 500, use identical standardized
dividend noise, and maintain cash/share/inventory invariants. Final-100-session
mean prices are 99.775 versus benchmark 100, and 120.022 versus benchmark 120.
These are single-seed engineering checks, not live-LLM or human-realism evidence.
Rule-only plots also show recurring price cycles and return autocorrelation;
investigate those in later baseline calibration rather than claiming realism.

Artifacts: starter_code/runs/stage2_diagnostics_20261102.json and
stage2_source_20261102.zip, plus run IDs recorded in diary R005. The economic
conventions are documented in starter_code/ECONOMIC_MODEL.md. Baseline prompts
now use raw_economics_v2 for accurate time units, payout rules, and small-rate
precision; this common correction is not the factual-summary treatment.
Next pass: Stage 3, selectable A/B/C modes and reproducible call provenance.

Stage 3 completed on 2026-11-02: 76 tests pass, three 30-round matched mock
examples completed (A/B 240 requests; C 280 including 40 reflections). Full
request/decision/outcome logs, source manifests, price/call controls, and safe
budget-stop semantics exist; generic replay/caching remains deferred. The source
and financial baseline were preserved: a fresh rule seed-42 regression reproduces
all six key Stage-2 financial CSVs byte for byte.

The predeclared 12-run screen suggests inventory skew affects predictability and
mispricing, with a turnover trade-off. Changing trend horizons alone had little
effect in these three seeds; no default was selected or altered. All cases and
protocols are saved in starter_code/runs/stage3_checks_20261102.json and companion
PNG/PDF. This is exploratory rule-only evidence; mock A/B/C differences are not
behavioural findings. Live-model access is now useful for the small pilot.
