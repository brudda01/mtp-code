# MTP Pack — LLM Agent-Based Stock Exchange Simulation
### Masters Thesis Project (2 semesters) · AI Department, IIT Kharagpur
### Topic: Simulation of human social systems using agent-based modeling and LLMs → LLM-agent stock exchange

---

## Current work (2026-11-05)

Read [THESIS_RESULTS.md](THESIS_RESULTS.md) for the implemented project and
checked findings, [RESEARCH_DIARY.md](RESEARCH_DIARY.md) for its evidence history,
and [starter_code/README.md](starter_code/README.md) to work with the code.
The original semester plans and feature promises below are historical reference;
they do not describe the current implementation or validated results.

## What this pack is

This is a **complete, self-contained kit** for your entire MTP. It contains everything decided, planned, and specified in advance, so that you can execute the project by feeding instructions to coding agents (Claude Code, Cursor, Copilot, etc.) without needing to design anything yourself.

**Read this file first. Then read files in numerical order.**

| File | What it is | When to use it |
|---|---|---|
| `00_START_HERE.md` | This file. Overview + decisions already made for you | Read now |
| `01_CONCEPTS_PRIMER.md` | Everything you must *understand* (for viva/prof discussions): ABM, order books, stylized facts, behavioral economics, LLM agents, and plain-language summaries of the 3 papers your prof shared | Read in week 1–2, re-read before every prof meeting and viva |
| `02_SYSTEM_DESIGN.md` | The full technical specification of what you're building: architecture, agent attributes, market mechanism, data schemas, config format | Give to coding agents as context; read yourself to know what exists |
| `03_SEMESTER_1_PLAN.md` | Week-by-week plan for semester 1, with milestones and what to show the prof | Follow it |
| `04_SEMESTER_2_PLAN.md` | Week-by-week plan for semester 2 (experiments + thesis) | Follow it |
| `05_CODING_AGENT_PROMPTS.md` | **Copy-paste prompts**, in order, one per module. This is your main workflow file | Every coding session |
| `06_EVALUATION_AND_EXPERIMENTS.md` | How to prove the simulation "works": stylized-facts tests, metrics, full experiment configurations for semester 2 | Sem 1 end + all of sem 2 |
| `07_REPORT_TEMPLATES.md` | Chapter-by-chapter skeletons for both semester reports + presentation outline + likely viva questions with answers | Report-writing weeks |
| `08_RESOURCES.md` | All papers, all open-source repos (with what to steal from each), LLM cost management, troubleshooting, backup plans | Whenever stuck |
| `starter_code/` | A **tested, runnable** minimal simulator (call-auction market + pluggable agents + mock-LLM mode). Your coding agents extend this instead of starting from zero | Week 2 onwards |

---

## The project in three sentences

You will build a simulated stock exchange where the traders are **LLM agents** — each agent is a persona (with attributes like risk aversion, aggressiveness, wealth, trading horizon, behavioral biases) that reads the market state each round, "thinks" in natural language, and submits buy/sell orders. The market engine matches orders, forms prices, and feeds outcomes back to agents, so that **macro-level market phenomena (bubbles, crashes, fat-tailed returns, volatility clustering, herding) emerge from micro-level LLM decisions**. You will validate the simulation against known "stylized facts" of real markets, run policy/behavioral experiments on it (news shocks, circuit breakers, transaction taxes, social influence), and compare LLM agents against classical rule-based/parametric agents (the kind your senior built with differential equations).

## Why this framing is exactly what your prof asked for

Your prof's setup: a senior built a stock exchange where agents are **parametric** — attributes like risk, boldness, wealth enter equations (differential equations make tuning easy because you can smoothly vary parameters). Your job: **same exchange concept, but the agent's "brain" is an LLM** — the attributes go into the agent's *prompt/persona* instead of into an equation. This is precisely the paradigm shift described in AgentSociety (the paper he gave you): replacing rule/equation-driven agents with LLM-driven generative agents because real humans decide via language and reasoning, not scalar equations.

Being from the Economics department, you additionally weave in economics throughout (this is your differentiator and easy marks):
- **Fundamental value** via dividend-discount pricing (agents can be told the dividend process; do prices track fundamentals?)
- **Behavioral finance**: loss aversion, disposition effect, overconfidence, herding — encoded as persona traits, then measured in behavior
- **Market efficiency tests**: are simulated returns predictable? (they shouldn't be, mostly)
- **Classic experimental-economics replications**: Smith–Suchanek–Williams (1988) bubble experiments; Gode–Sunder (1993) zero-intelligence traders as a baseline
- **Policy experiments**: Tobin tax, circuit breakers, interest-rate changes

## Decisions already made (so you never have to decide)

These are the design decisions, made deliberately. If your prof pushes back on any, `02_SYSTEM_DESIGN.md` §"Design rationale" has the justification for each, plus the fallback.

1. **Build your own lightweight simulator** (starter code included) rather than forking a big framework. Reason: you must be able to explain every line at the viva; big frameworks (TwinMarket, StockSim) have heavy infrastructure (databases, RabbitMQ) that will eat your semester. You *reference* the open-source projects (see `08_RESOURCES.md`) and copy specific ideas/prompts from them.
2. **Market mechanism: periodic call auction first (Sem 1), continuous limit order book as an upgrade (early Sem 2, optional).** Call auction = collect all orders each round, compute the single clearing price that maximizes matched volume. Simple, robust, and used by real exchanges at open/close (including NSE/BSE pre-open — a nice line for your report).
3. **One risky asset ("the stock") + cash.** Multi-asset is a stretch goal, not a requirement.
4. **Time = discrete rounds** ("trading days"). 100–300 rounds per run.
5. **Population: 20–50 LLM agents** per run (cost-controlled), mixable with unlimited rule-based agents (zero-intelligence, momentum, fundamentalist) — these rule-based agents ARE your bridge to the senior's parametric world and your comparison baseline.
6. **Agent interface is pluggable**: every agent (LLM or rule-based) implements `decide(observation) -> Order`. This single abstraction is the heart of the design.
7. **LLM access: OpenAI-compatible API endpoint**, so the same code works with OpenAI (gpt-4o-mini / gpt-5-mini class), DeepSeek, Groq (free tier, fast Llama), OpenRouter, or **local Ollama (free)**. Default assumption: a cheap mini-class model. Full cost math in `08_RESOURCES.md` (short version: a full 30-agent × 200-round run is roughly 2–4M tokens ≈ **$1–3 on a mini-class model, $0 on Ollama**).
8. **Structured outputs**: agents must reply in strict JSON (`action, quantity, limit_price, reasoning`). A validator retries once, then falls back to HOLD. This kills 90% of LLM-agent engineering pain.
9. **Everything logged**: every prompt, every raw LLM reply, every order, every trade, every price — to CSV/JSONL. Your entire evaluation and both reports are generated from these logs.
10. **Reproducibility**: every run has a config file (YAML) + random seed + model name recorded. Runs live in `runs/<timestamp>_<name>/`.

## The two-semester shape (details in files 03 & 04)

**Semester 1 = build + validate.** Deliverable: working simulator, LLM agents trading, first evidence of realistic market behavior (stylized facts), sem-1 report. Milestones: (M1) market engine with rule-based agents, wk 4; (M2) LLM agents trading end-to-end, wk 8; (M3) stylized-fact validation + persona ablation, wk 12; (M4) report + presentation, wk 14–16.

**Semester 2 = experiment + compare + write.** Deliverable: 4–6 experiments (news shocks, herding/social board, policy interventions, LLM vs parametric agents, bubble replication), robustness/repeats, thesis. This is where economics knowledge shines.

## How to work with coding agents (the workflow)

1. Put this whole pack folder + `starter_code/` into your project repo.
2. Open `05_CODING_AGENT_PROMPTS.md`. Prompts are numbered P1, P2, ... in build order. Each prompt tells the coding agent exactly what file to create/modify, the interface it must satisfy, and the test that must pass.
3. Paste one prompt at a time. After each, **run the stated test yourself** (each prompt includes the exact command). Never move on with a failing test.
4. If the agent goes off-spec, paste the relevant section of `02_SYSTEM_DESIGN.md` and say "conform to this spec."
5. Commit to git after every passing prompt. Commit message = prompt number.

**The one rule: you must read the code the agent writes for `market.py` and `llm_agent.py` closely enough to explain them.** Everything else can be treated as plumbing, but those two files are your thesis, and viva questions will target them. `01_CONCEPTS_PRIMER.md` gives you the vocabulary.

## Your safety nets

- If LLM costs/API access become a problem → Ollama with `llama3.1:8b` or `qwen2.5:7b` (free, runs on a lab GPU or decent laptop) — the code needs zero changes (same OpenAI-compatible API).
- If LLM agents behave absurdly → the mock-LLM mode and rule-based agents keep the simulator demonstrable; "LLM agents behave weirdly under X" is itself a reportable finding (StockAgent's paper is largely about exactly this).
- If you fall behind → the minimum-viable thesis is: simulator + LLM agents + stylized-facts validation + one experiment + comparison with rule-based agents. Everything in Sem 2 beyond that is stacked in priority order; cut from the bottom.
- If the prof wants something different mid-way → the pluggable agent interface means new agent types (different personas, different models, fine-tuned models, the senior's ODE agents) drop in without touching the market engine.

Good luck. Start with `01_CONCEPTS_PRIMER.md`.
