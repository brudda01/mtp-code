# Project working notes

Read `RESEARCH_DIARY.md` at the start of work on this project. It records the
current research direction, findings, open issues, and proposal status.

Maintain that diary after meaningful implementation changes, experiments,
discoveries, or research decisions. Include the date, question, change and
rationale, evidence or run IDs, limitations, and thesis relevance. Preserve
negative and inconclusive results. Distinguish proposed, approved, implemented,
and verified work; never present a proposal as an implemented improvement.
Correct earlier entries explicitly rather than silently rewriting their history.
Routine formatting edits do not need diary entries.

For experiment results, record the code revision (and any uncommitted changes),
config, prompt/persona version, exact model, randomness settings, repetitions,
metrics, and artifact paths when available. Do not invent missing metadata,
reconstruct exact prompts from memory, or call a before/after association causal
without an appropriate controlled comparison. Do not include API keys or secrets.

The user's current priority is substantial, defensible results within the current
semester. The old semester split and prepared P1-P13 prompts are reference
material, not an obligation to implement every feature. Follow the user's latest
scope and decisions. On 2026-11-02 the user approved beneficial modifications
and requested implementation in bounded stages. Follow `WORK_PLAN.tmp.md` when
present, update its completed checks, and preserve the selectable corrected
simple-agent baseline for future component comparisons. Approval does not mean
that unimplemented proposals have already been validated experimentally.

Permanent thesis requirement: retain comparable selectable conditions A
(corrected simple agent with raw observations and recent executed outcomes),
B (A plus factual summaries), and C (B plus reflection). These modes are implemented
and tested offline; live behavioural effects remain unverified. Keep the same economic
rules, public information, personas, and constraints across modes, and preserve
their prompts/versions and matched exogenous scenarios. Live-model evidence and
independent repeats are required for behavioural conclusions; mock differences
only verify software. Do not lose this comparison when the temporary plan goes away.

Current checkpoint (2026-11-03 audit of 2026-11-02 runs): Stages 1-3 and
live integration are implemented; 150 offline tests pass. User selected
BharatCode student access and qwen-3.8-27b after Gemini failures (R011-R013).
API_KEY in starter_code/.env is scoped to its official HTTPS endpoint. No billing
or silent model substitution. NVIDIA_API_KEY is deferred; do not call NVIDIA or
block core research on that optional challenger.

Common prompt suite is comparable_agents_v2_disclosed_rules (R016). Qwen passed
54/54 objective numeric fields and 30/30 delivered orders in the disclosed-rule
qualification (R017); this is capability evidence, not market realism. R014's
18 probes/six tiny A/B/C markets remain exploratory. Keep Gemini/Lite, old/new
prompts, and different market populations separate; clipping alone is not an
arithmetic error.

R018 separated news visibility from economic effects, with private event audits.
R020 added selectable dividend_window (default 1 unchanged), conditional passive
accounts with both terminal marks, equal-resource fourteen-slot replacements,
and a 12-market background screen. Five-payout averaging raised persistence;
no default was selected. Retain seed-633 no-news drift and sensitivity trade-offs.
R021 completed 48 fresh trait/state replies: risk contrasts positive 10/12,
both reversals in falling contexts; 23 HOLD/1 BUY/0 SELL makes the selling test
inconclusive. Do not tune wording or switch models to manufacture expected bias.

R024 COMPLETE: the existing background job finished 2026-11-02 23:06 IST;
PID22644 exited, no API job active. All 8 rule + 8 live 20-round markets and
24 same-state headline queries completed in the linked study
starter_code/runs/20261102_202946_news_pilot_786a0370, latest phase
delivery_v4_query_first. No rerun is needed after the usage-limit reset.
Cumulative ALL phases: 402 HTTP attempts, 1122587 provider-reported tokens,
4879158 conservative reservations, 10 unknown-usage failures, 1 blocked request.
Seven transport retries recovered on identical messages; no 503 retry was
needed live. Opt-in retry_http_503 shares one extra attempt with transport,
honors safe Retry-After <=60s/default10s; both opt-ins default off. Original
688 attempts/9M reservations ceiling retained; amended phase maxima619/8055022.
Preserve old zero-, nine- and fourteen-round incomplete attempts separately.
Do not splice them into full runs or relabel linked delivery phases as a causal
before/after improvement. Prompts/policy/economics were checked unchanged.

Read starter_code/runs/news_query_first_analysis_20261102/READOUT.md and diary
R024 for final evidence: Meera's within-state news contrast positive in seed1441
but mixed (-50,-20,+40 shares) in seed2882. Arjun HOLD in both stored frames,
but both lack cash for even one executable buy; this is not proof of ignored news.
Combined real-shift/news markets had smaller post-event benchmark gaps in both
seeds, but pre-event states differ and only two short scenarios exist. Large
requested/accepted orders need not fill; equal resources do not standardize
policy order size. Keep all passive-relative gains/losses and both wealth marks.
No stable human-realism, herding, superior-LLM, or confirmed A/B/C effect follows.

Next scientific pass is PROPOSED, not started: opportunity-aware positive/negative
news confirmation, followed by the preserved A/B/C component comparison and
adequate full-market confirmation. Reflection must use actual logged histories;
do not assume raw A forgets all news when its structured window expires, since
prior order reasoning may carry beliefs. Avoid general infrastructure and repeated
qualification without a new failure. Inspect WORK_PLAN.tmp.md before API work.
Student 10M tokens/day is the stated allowance, not a verified remaining balance
or RPM limit. Do not enable billing or silently substitute another model. Preserve the wider
research objective: agent behaviour, market statistics, news/intervention
responses, and fair LLM-versus-rule comparisons. A/B/C is one explanatory study,
not a replacement for that objective. Improve consistency without forcing expected
outcomes. Keep a concise thesis-candidate index; retain raw and negative evidence
without presenting routine engineering checks as headline research results.
