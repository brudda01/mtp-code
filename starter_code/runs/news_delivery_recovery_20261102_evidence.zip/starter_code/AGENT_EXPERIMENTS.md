# Comparable agents and the live-pilot checkpoint

The exchange and economic rules are common to all three conditions. The study
asks whether additional assistance changes decisions, market outcomes, failures,
and computational cost. Better performance or greater human realism is not assumed.

| Condition | Inputs and private memory |
| --- | --- |
| A | Raw market/account observations plus recent verified execution outcomes |
| B | A plus a deterministic arithmetic summary of those observations |
| C | B plus periodic, fallible reflection and compressed past experience |

Choose `agents[].llm.condition: A`, `B`, or `C`. The common system prompt, persona,
public history length, resources, asset process, and order constraints stay fixed.
Use the same `memory_window` across compared conditions. Set `reflect_every: 0`
for A/B. C requires `0 < reflect_every <= memory_window`. It makes no reflection
call after the final decision, because that call cannot affect future behaviour.

Ready-to-run mock recipes, each with 20 traders and eight mock agents:

```powershell
python -B -m sim.engine --config configs/pilot_a_mock.yaml
python -B -m sim.engine --config configs/pilot_b_mock.yaml
python -B -m sim.engine --config configs/pilot_c_mock.yaml
```

These recipes share seed 42, 30 rounds, initial resources/personas, and dividends.
Mock behaviour uses prompt hashes and simple heuristics; differences between
its conditions do not establish semantic effects of summaries or reflection.

## What each assistance layer does

B computes recent percentage price change, stock weight, unrealized gain/loss,
previous dividend yield, cash interest, and the last executed quantities. A
price/value gap is included only when the value estimate is already disclosed
in A's inputs. No hidden dividend regime, future news, or trading recommendation
is supplied. These are presentation/computation aids, not extra market signals.

All modes remember requested and accepted orders separately from actual fills,
plus their own account state, price, paid income, and observed news. They do not
infer a purchase merely because they requested one. Counterparty portfolios and
other agents' private observations are absent. Portfolio records remain Python
bookkeeping; model text cannot change them.

C asks for Observations, Beliefs, and Plan in at most 120 words, preserves the
previous diary, and labels beliefs as fallible in future prompts. B/C compares
the reflection-and-memory package: it adds both model calls and compressed older
experience. It does not isolate reasoning from extra memory retention. Until
the first reflection, B and C receive identical prompts given identical state.

The common prompts state that this asset continues after the recorded episode;
episode termination does not make shares expire. The finite-horizon bubble
experiment remains a separate, unimplemented economic model.

## Reproducibility and logs

Each run saves normalized config, exact `personas.json`, initial accounts,
`manifest.json`, and `source.zip`. The manifest includes parent revision/dirty
state, runtime source/config hashes, template hashes/labels, model settings,
timestamps, endpoints, final status, and output hashes. A live provider's returned
model identifier/fingerprint is retained when supplied. API keys and authorization
headers are never recorded. Template hashes are authoritative alongside labels.

- `llm_requests.jsonl`: each actual request/reply/error immediately, including
  repairs/reflections and blocked requests. It retains an earlier reply even
  when its repair is blocked before a decision finishes.
- `llm_calls.jsonl`: completed decision/reflection records, linked to request IDs,
  with parse errors, raw intent, accepted order, and any diary update.
- `agent_outcomes.jsonl`: verified own executions, account state, and income.
- `orders.csv` adds LLM-requested fields alongside validated order fields.

Completed, failed, interrupted, and budget-exhausted runs are distinguished.
`rounds` counts financially completed rounds; `requested_rounds` is the requested
horizon. A decision-stage limit stops before clearing the partial batch. A
reflection-stage limit stops after the entire settled/payout round is logged.
Provider errors may produce HOLDs while the market continues; inspect failure
rates before treating a completed run as usable behavioural evidence.
With `llm_limits.stop_on_api_error: true`, the first recorded provider failure
instead stops the run with `status: provider_error`. A decision-stage failure
clears no partial batch; a reflection-stage failure retains the fully paid round.
Use this setting for small live pilots so exhausted quota cannot masquerade as
an inactive trading strategy. No automatic HTTP retries occur.

## Request and cost limits

`llm_limits` accepts `max_requests`, `max_reserved_tokens`, and `max_cost_usd`.
Requests share one thread-safe budget across agents, repairs, and reflections.
There are no hidden HTTP retries: a retry must be separately recorded/budgeted.
Client timeout is controlled by `agents[].llm.timeout_seconds`.
Optional `requests_per_minute` evenly spaces requests across all agents and
`input_tokens_per_minute` reserves rolling 60-second byte-based input estimates.
Pacing waits and provider latency are logged separately. This is local pacing;
other applications share the provider project's quota. An input larger than
the configured minute allowance is blocked before making a request.

Live configurations require explicit `input_usd_per_million` and
`output_usd_per_million` in the LLM group, plus a run cost limit. Use verified
provider/model prices at pilot time; no stale price table is assumed. Explicit
zero prices support a free local endpoint or included student token allowance;
record that basis separately from observed billing. Mock clients have zero monetary cost.

Before a call, the budget reserves UTF-8 byte counts plus overhead and maximum
output tokens. Reservations are not refunded, including on errors, because an
ambiguous request might be billed. These are conservative screening estimates,
not a provider tokenizer or guaranteed billing cap. Provider-reported usage,
mock estimates, and missing usage are distinct. Cost estimates use the declared
rates and do not claim to reproduce invoices, caching discounts, or every
provider-specific token charge. Provider account limits remain useful.

`python -B -u -m sim.pilot probes` saves a fixed-observation protocol before
generation. It checks direct arithmetic, A/B resource constraints, disclosed
value, an unverified headline, and a one-trait risk contrast, with two independent
repetitions for paired probes. `sim.pilot markets --probe-dir ...` then permits
two independent four-round A/B/C micro-run sets. Per-seed accounts, personas,
economic rules and exogenous randomness match; model sampling is not fixed by
the simulator seed. Condition order is ABC then CBA to reduce a fixed time-order
confound, without claiming this eliminates provider drift. Two repeated prompts
or two micro-runs do not support a general behavioural significance claim.

The primary pilot uses BharatCode student access, `qwen-3.8-27b`, requested
temperature 0.3 for decisions and 0 for reflection, low reasoning effort and
output cap 2048 including reasoning. Chosen pacing is ten RPM / 60000 byte-based
input estimates per minute, with a 180-second timeout. These are local controls,
not verified provider quotas or a guaranteed queue-wait limit. Included student
tokens have zero incremental per-token price; the claimed 10M/day allowance and
remaining balance are not measured by the model catalog. The combined caps are
96 attempts and 700000 token reservations, well below the stated daily allowance
if no other application consumes it; reservations are not a provider tokenizer.
Requests/tokens/latency, rather than USD estimates of zero, measure A/B/C overhead.
Provider
errors preserve HTTP/status and structured quota information, excluding raw
error messages that could contain credentials. Billing is never enabled here.
Earlier Gemini/Lite artifacts are preserved separately. The user explicitly
approved the provider switch; this is not an isolated model-size ablation.
Requested sampling settings are logged; their effective server implementation
and model RNG are not exposed. Simulator seeds do not fix model responses.
Provider latency includes queuing and network time, not just inference.

An exhausted model output budget (`finish_reason: length`) is saved and counted
as `output_truncations`. Strict pilots stop with `OutputLimitExceeded` and do
not automatically retry the same cap. In non-strict mode a truncated decision
becomes a labelled HOLD without a repair; an incomplete reflection cannot
replace the existing diary. Inspect these separately from voluntary inactivity.

## Next scientific work

The 18-probe/six-market Qwen diagnostic completed (diary R014); keep earlier
Gemini attempts separate. The shared tick/price-band/raw-reservation disclosure
is implemented as comparable_agents_v2_disclosed_rules. Old v1 results are
preserved. Clipping alone is not automatically a numerical error. Keep closing-price and
regime-benchmark valuations distinct; neither alone establishes trading skill.
A/B/C is
one explanatory experiment within the broader news/market/brain-type project.
Fresh repetitions and confirmation scenarios must follow pilot choices.

`python -B -u -m sim.capability_check prepare` freezes a 14-case/three-repeat
battery. Use `qwen --battery runs/<battery-directory>` or, once a local
`NVIDIA_API_KEY` is ready, `deepseek --battery runs/<the-same-directory>` with
the same module. Each run saves a copy/hash of the exact battery, raw attempts,
case-level scores and source/config snapshots. Changed rendering fails before
calls. Objective tasks have numeric oracles; trading choices have no prescribed
profitable direction, and feasibility is reported separately. The synthetic
memory fixture uses actual validation/settlement with a partial execution.

Profiles request temperature .3, output cap 4096, timeout 180, chosen ten RPM and
60000 input-estimate tokens/minute; each run permits 54 attempts / 400000 reserved
tokens. Qwen uses low reasoning effort; NVIDIA initially uses provider default
because its documented example does not establish that parameter. These settings
qualify served-model configurations; equal hidden compute is not claimed. An
output-cap stop needs investigation before any model-quality comparison. NVIDIA
access/quotas require a separate check; no account billing is enabled here.

The Qwen v2 capability battery completed through a documented timeout/tail
continuation (diary R017): 54/54 objective fields and all 30 delivered orders
passed. The timeout remains in reliability accounting; this is neither an
uninterrupted run nor a causal comparison with older prompts. It supports
continuing with Qwen while the later DeepSeek check remains optional. Headline
and risk responses were mixed; no general human-behaviour effect is claimed.

## Independent news controls and next live pilot

Implemented and verified (diary R018): `news[].announce` defaults to true and
controls headline visibility independently of `effect`. Hidden events may omit
text. `event_audit.jsonl` retains private provenance; agents cannot read it.
Explicit benchmark disclosure remains a separate channel and is disabled here.

`python -B -u -m sim.news_controls` freezes its protocol before running twelve
local markets: seeds 211/422/633, 600 rounds, event at 301, permanent +20% mean
shift when enabled. Four cells cross no/yes shift with no/yes public forecast.
All use the unchanged 20-rule-trader baseline, equal initial resources and
matched environmental innovations. The headline says the rise is a forecast
and future payments are uncertain; it is identical in both announced cells.
The seven financial CSVs must match exactly between control/headline-only and
silent-shock/combined, because these rule agents ignore text. These are
engineering negative controls, not evidence that news is ineffective for humans
or LLMs. Retain drifting prices and nulls; no calibration parameter was selected.

**Frozen next-pilot proposal, not yet run:** `news_live_pilot_proposal_v1`.
User resumed after the R019 direction review. This proposal is preserved and
unrun; its numerical settings have not changed. R020 implements the passive
evaluation, matched-slot rule/mock templates and background screen below, and
prepares fresh trait inputs. Live behavioural responses remain unverified.
A 20-round pilot with
two LLM traders can diagnose immediate decisions, not establish human realism
or long-run market effects.

Start with A only to inspect news decisions before multiplying the study by
three memory conditions. B and C remain selectable and required for the later
component comparison. The following choices are fixed before seeing pilot data;
any subsequent change needs a version and rationale in the diary.

- Eight markets: four cells for each fresh seed 1441 and 2882; 20 rounds,
  event at 11, same +20% permanent shift/uncertain forecast as the rule check.
  Run order is control/headline-only/silent-shock/combined for 1441 and the
  reverse for 2882. Simulator seeds fix environmental paths, not LLM sampling.
- Population: 1 market maker, 4 random, 3 fundamentalist, 4 momentum, 2 LLM
  traders; use the prior micro-pilot's endowments and rule parameters. The two
  current library personas are Meera and Arjun; archive their exact realized
  texts and mappings. Match these across cells; this does not isolate any one
  persona trait. This population differs from the 20-rule-trader check, so
  comparing those populations directly would not be a fair LLM-versus-rule test.
- Retain the baseline economics (.02 mean, .2 relative noise, .0002 rate,
  tick .1, band .2, zero tax) and `reveal_fundamental: false`. Use the existing
  common prompt suite v2, A, memory window 5, no reflection, price history 20,
  one worker. No future schedule, latent mean or researcher benchmark in prompts.
- Same BharatCode `qwen-3.8-27b`, temperature .3, low reasoning effort, cap
  4096 including reasoning (the qualified battery profile), timeout 180 seconds,
  chosen pacing ten RPM / 60000 input-estimate tokens/minute. Stop on API errors
  or output truncation; preserve partial runs and unknown usage. Do not silently
  switch models or rerun/select responses. Optional NVIDIA access is deferred.
- 40 planned decisions per market, at most 80 attempts with one JSON repair per
  decision, no HTTP retries: 320 planned decisions / 640 maximum attempts across
  the pilot. Set each run's conservative reservation ceiling to 1000000, for
  8000000 overall, zero incremental student-token prices and zero cost ceiling.
  These limits may stop early; the stated 10M/day allowance is not verified
  remaining quota, and reservations are not provider-tokenizer counts. Keep
  pacing shared across runs and account for any additional probes separately.
- Primary diagnostics: event-round requested and accepted signed quantities,
  direction/HOLD rates and actual fills by persona; compare announced versus
  silent cells at the same economic state. Report all four cells, both seeds,
  pre-event differences and failures. Subsequent price/liquidity responses are
  exploratory with only ten post-event rounds. Report zero-volume periods and
  time-to-price-response without dropping runs that never respond.
- Also report normalized price gaps to the stationary-regime benchmark, turnover,
  fill rates, and wealth marked both at the last auction and at the benchmark,
  including recorded income exactly once. Separate intent, acceptance and
  execution. A movement toward the benchmark or profit is not a pass criterion.

Two seeds and two personas support feasibility and exploratory leads only;
traders/rounds within one market are not independent repetitions. Live pre-event
paths can differ despite matched exogenous draws because provider sampling is
uncontrolled. Do not infer a causal treatment effect from one pair or diagnose
human bias from persona labels. Freeze a confirmation design using fresh seeds,
more independent repeats, negative news and alternate wording after the pilot.
Use equal-resource replacements/rotated assignments for later brain comparisons;
study A/B/C under matched conditions without assuming reflection helps.

Full caching/general replay, resume, and extensive statistical reporting are
deliberately deferred. The current code records responses for audit; it does not
claim an implemented end-to-end replay command or reproducible provider sampling.

## R020 balanced follow-up

`python -B -u -m sim.background_check` freezes and runs a rule-only 2x2 screen:
MM inventory skew .02/0 crossed with fundamentalist dividend window 1/5,
seeds 317/628/939, 600 no-news rounds, hidden benchmark. Fourteen fixed slots
hold 160000 cash and 1450 shares. The common background has MM1/ZI4/F3/M4;
slots 12/13 are F1/M1, with the same endowments as the two future LLM slots.
`slot_recipe(..., brain="mock")` builds that equal-slot A template. Its mock
provider cannot establish live brain effects. Background identities, RNG states,
resources, market and observation settings match; persona assignments/brain
responses still need matching/versioning in a future live comparison.

The screen retains every case and reports price gaps, return/absolute-return
dependence, turnover, fills, no-trade periods, inventory, concentration, capital
growth and both conditional passive wealth comparisons. Return statistics here
include all 600 changes from initial price onward; earlier minimal metrics
omit the first change, so do not mix their counts silently. Three seeds are
exploratory. Averaging five payouts increased return persistence in all six
matched comparisons; removing skew lowered it while reducing activity. The
lowest-gap cell also had greater return persistence and MM volume participation
than the original. No default or prompt changed and no realism winner was selected.

`python -B -m sim.behaviour_check` prepares `matched_trait_states_v1`, with no
generation: 16 fixed A cases, three planned fresh model repetitions (48
decisions, maximum 96 attempts if each requires one JSON repair). It crosses
risk descriptions with rising/falling price contexts, and acquisition gain/loss
basis with neutral/loss-sensitive profiles and two clause wordings. Identity,
current wealth, information and resources are matched within the relevant
contrasts. Neutral cases duplicated across wording contrasts remain explicit.
All exact messages, source archive, schedule and proposed qualified Qwen profile
are saved before any requests. These synthetic observations are not actual
executed histories. Score choices/exposure, feasibility and interaction/context
stability; there is no preferred profitable trade or human-realism pass oracle.
The gain/loss probes do not estimate a population disposition ratio.

R020 made no API calls. R021 completed the bounded fresh behavioural check below.
Next is the news feasibility pilot; preserve independent confirmation,
equal-slot brain comparisons and A/B/C for later research. Add only the minimal
runner/scoring needed for those fixed inputs, using existing logs and limits.

R021 implements that runner as `sim.behaviour_run` and validates it with six
additional offline checks (134 total). It reads the existing battery; no case
or prompt is regenerated/edited for the live call. Example:

```powershell
python -B -u -m sim.behaviour_run --battery runs/20261102_193749_behaviour_inputs_5e633670
```

Each invocation starts a new full battery; it is not resume. The first live run
completed in R021; do not blindly invoke it again as continuation.
The profile remains Qwen/.3/low/4096 with 180-second timeout, chosen ten RPM /
60000 input-estimate TPM, 96 attempts / 1M conservative reservation ceiling,
zero declared incremental student-token cost and strict provider/output stops.
Requested and accepted signed quantities are distinct. Failed parses remain
null in preference contrasts and count in reliability; these fixed snapshots
do not produce fills or realized performance. The frozen risk contrast is
high-minus-low signed shares; the gain/loss interaction is the change in
gain-minus-loss selling between loss-sensitive and neutral profiles. Every
direction/null is reported, with no behavioural correctness oracle.

R021 results: 48 completed decisions/48 attempts/40352 reported tokens, no
errors, repairs or clipping. High-risk signed exposure is greater in 10/12
contrasts, with two reversals in falling-price contexts. Rising context agrees
in all six contrasts across wordings. Gain/loss cells contain 23 HOLDs/one BUY
and no SELL, so their zero selling interaction provides limited information
about disposition. The neutral duplicates reveal some identical-input response
variation. This is exploratory context sensitivity, not stable trait or human
validation. Preserve all cases and pursue the economic/news opportunity study;
do not adjust wording to force expected selling or switch models for this null.

## R022 news-pilot execution

`sim.news_pilot` implements `news_live_pilot_v2_matched_event_probes`. This
explicit amendment retains all v1 market settings and adds eight equal-slot
rule counterparts plus 24 fresh same-state headline queries. The source/config
freeze is `runs/20261102_202946_news_pilot_786a0370/study.json`; R022 records the
launch. R022 and its single explicit continuation stopped after two transport
failures: all eight rule arms and only three of eight live arms completed.
Combined/1441 has nine cleared rounds; second-seed live arms and same-state
queries are unrun. No news effect is established. No API job remains active.

```powershell
# Preparation never calls a model; each new study is a new experiment:
python -B -u -m sim.news_pilot prepare
# A prepared study may be started once. Inspect the current job before running:
python -B -u -m sim.news_pilot run --study runs/<prepared-study>
```

Rule controls run before spending model requests. All cases retain the same
fourteen endowments/background; only the last two rule policies are replaced by
the two bundled LLM personas. The study stops on incomplete delivery, provider/
output/budget errors or persistent parse failure, preserving failed/partial arms.
Full live market paths can differ before the event because model draws are not
fixed by simulator seeds. They support exploratory comparisons, not a clean
immediate headline effect by themselves.

After markets, deterministic extraction takes BOTH LLMs' control-market frames
at round 11 for BOTH seeds. Accounts, observed history and verified own memory
come only from saved data through round 10. Re-rendered no-headline prompts must
match their logged first attempts exactly. The snapshot battery then crosses
only no headline/the same uncertain forecast, with three fresh repetitions and
reversed pair order in repeat 2. These 24 queries do not clear orders or alter
market trajectories. Their exact inputs are frozen before query calls; frames
are selected by design rather than by a favourable response.

Market bounds remain 640 attempts/8M reservations. Snapshot queries add maximum
48 attempts/1M reservations: overall 688/9M, with shared chosen ten RPM/60000
input-estimate TPM. These are caps, not verified quota remaining or token counts.
Student incremental declared prices are zero; billing is not enabled. No model
switch or NVIDIA request. The expanded budget is recorded before all calls.

Output metrics keep target-slot intent, acceptance and execution separate; union
trade involvement counts an LLM-to-LLM trade once, while trade-leg share counts
both participants. Both passive-relative wealth marks and all pre-event
differences are retained. Half-gap time is censored/null when the benchmark
distance has not halved in the observation window; it is not causal response
latency. The two-seed/twenty-round study is a feasibility pilot, not stylized-fact
validation, intrinsic-model superiority or a general persona/A-B-C result.

R022's partial-data audit preserves both URLErrors with unknown usage, the
failed/unexecuted replies, all missing arms and pre-event divergence. Total
142 attempts/402899 reported tokens, no hidden retry. One explicitly linked
continuation deducted prior calls/reservations from the failed zero-round arm;
it also stopped, with no further restart. Read R022 and
`runs/news_analysis_20261102/report.json` before API work. A minimal opt-in
logged/budgeted transport retry is proposed next, with safe reason diagnostics
and offline tests. It is not implemented; no new model or key is required by
these observed transport errors. Complete/partial data must remain linked if
delivery settings change. Do not blindly rerun the entire frozen study.

## R023 transport-only retry profile

`agents[].llm.transport_retries` accepts 0 (default) or 1. The opt-in setting
allows one recorded retry for URLError/TimeoutError/ConnectionError, excluding
HTTPError and certificate-validation failures. A retry waits two seconds, then
uses shared pacing and a NEW reservation. Unknown failed usage is never refunded.
Each actual HTTP attempt has a unique call ID, common request-group ID,
`json_attempt`, `transport_attempt` and `attempt_kind`. Raw error text is omitted;
safe reason type/errno/winerror are retained. JSON repair remains separate from
transport retry, and output caps are not retried. Engine summaries count both
retry kinds; model manifests record policy version and the opt-in value.

146 offline tests pass; archived prompt/policy methods and financial baseline
match. The five-arm recovery phase reached 14 rounds of combined/1441, then
stopped on HTTP 503 at round 15. No eligible transport retry actually occurred
live, so do not claim an empirically improved failure rate. No API job remains.
Overall 171 attempts/479359 reported tokens/three unknown usages; original eight
rule arms and three full live arms remain, with separate partial trajectories.
Same-state queries and second-seed live arms are unfinished. R023 records a
proposed explicit server-503/Retry-After policy and query-first scheduling; those
changes are not implemented. Every future attempt must retain original global
caps and link the prior successful/partial data. A/B/C and economic rules remain.
