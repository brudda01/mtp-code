"""Minimal OpenAI-compatible HTTP client, one HTTP attempt per recorded call.

No automatic retry is hidden from the shared request budget. Invalid model JSON
may trigger the agent's separately recorded corrective request. Credentials are
read from environment/constructor and never returned in call metadata.
"""
from __future__ import annotations

import json
import os
from urllib.parse import urlparse
import urllib.request


class LLMClient:
    def __init__(self, model="gpt-4o-mini", base_url=None, api_key=None, timeout=30, **kwargs):
        self.model = model
        self.base_url = (base_url or os.environ.get(
            "LLM_BASE_URL", "https://api.openai.com/v1")).rstrip("/")
        parsed = urlparse(self.base_url)
        if (parsed.scheme not in ("http", "https") or not parsed.netloc or
                parsed.username or parsed.password or parsed.query or parsed.fragment):
            raise ValueError("base URL must be HTTP(S), without embedded credentials/query/fragment")
        self.api_key = api_key or os.environ.get("LLM_API_KEY", "")
        self.timeout = timeout
        self.total_tokens = 0
        self.total_cost = 0.0  # Declared-price estimates are recorded by UsageBudget.
        self.last_usage = None
        self.last_response_metadata = {}

    def chat(self, messages, temperature=0.7, max_tokens=300, json_mode=True, retries=1):
        if retries != 1:
            raise ValueError("hidden retries are disabled; record and budget each new request")
        self.last_usage = None
        self.last_response_metadata = {}
        body = {"model": self.model, "messages": messages,
                "temperature": temperature, "max_tokens": max_tokens}
        if json_mode:
            body["response_format"] = {"type": "json_object"}
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        request = urllib.request.Request(self.base_url + "/chat/completions",
                                         data=json.dumps(body).encode(), headers=headers)
        with urllib.request.urlopen(request, timeout=self.timeout) as response:
            data = json.loads(response.read())
        usage = data.get("usage", {})
        if (isinstance(usage, dict) and all(type(usage.get(k)) is int and usage[k] >= 0
                for k in ("prompt_tokens", "completion_tokens"))):
            total = usage["prompt_tokens"] + usage["completion_tokens"]
            reported = usage.get("total_tokens", total)
            if type(reported) is int and reported >= total:
                self.last_usage = {"prompt_tokens": usage["prompt_tokens"],
                                   "completion_tokens": usage["completion_tokens"],
                                   "total_tokens": reported, "source": "provider"}
                self.total_tokens += reported
        self.last_response_metadata = {
            k: data[k] for k in ("model", "system_fingerprint") if isinstance(data.get(k), str)}
        content = data["choices"][0]["message"]["content"]
        if not isinstance(content, str):
            raise ValueError("provider returned non-text message content")
        return content
