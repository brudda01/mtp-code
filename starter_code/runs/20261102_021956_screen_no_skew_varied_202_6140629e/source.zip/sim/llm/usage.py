"""Thread-safe pilot request limits and explicit, conservative cost estimates.

Reservations are never refunded: failed/ambiguous requests may still be billed.
UTF-8 byte counts plus overhead are a screening estimate, not a provider tokenizer
or a guarantee about a provider's final bill. Use provider account limits too.
"""
import json
import threading


class UsageLimitExceeded(RuntimeError):
    """A request was blocked before calling the model."""


class UsageBudget:
    def __init__(self, max_requests=10000, max_reserved_tokens=20000000, max_cost_usd=None):
        self.max_requests = max_requests
        self.max_reserved_tokens = max_reserved_tokens
        self.max_cost_usd = max_cost_usd
        self.requests = self.reserved_tokens = self.rejections = 0
        self.reserved_cost_usd = 0.0
        self.provider_tokens = self.estimated_tokens = self.unknown_usage_requests = 0
        self.failed_requests = 0
        self.observed_cost_estimate_usd = 0.0
        self._lock = threading.Lock()

    def reserve(self, messages, max_output_tokens, input_price, output_price):
        input_tokens = len(json.dumps(messages, ensure_ascii=False).encode("utf-8")) + 256
        tokens = input_tokens + max_output_tokens
        cost = (input_tokens * input_price + max_output_tokens * output_price) / 1e6
        with self._lock:
            reason = None
            if self.requests + 1 > self.max_requests:
                reason = "request limit"
            elif max(self.reserved_tokens, self.provider_tokens + self.estimated_tokens) + tokens > self.max_reserved_tokens:
                reason = "token reservation limit"
            elif self.max_cost_usd is not None and max(
                    self.reserved_cost_usd, self.observed_cost_estimate_usd) + cost > self.max_cost_usd + 1e-12:
                reason = "declared-price cost reservation limit"
            if reason:
                self.rejections += 1
                raise UsageLimitExceeded(reason)
            self.requests += 1
            self.reserved_tokens += tokens
            self.reserved_cost_usd += cost
            return {"reservation_id": self.requests, "input_token_estimate": input_tokens,
                    "max_output_tokens": max_output_tokens, "reserved_cost_usd": cost}

    def record(self, usage, success, input_price, output_price):
        with self._lock:
            if not success:
                self.failed_requests += 1
            if usage is None:
                self.unknown_usage_requests += 1
                return None
            tokens = usage["total_tokens"]
            if usage["source"] == "provider":
                self.provider_tokens += tokens
            else:
                self.estimated_tokens += tokens
            cost = (usage["prompt_tokens"] * input_price +
                    usage["completion_tokens"] * output_price) / 1e6
            self.observed_cost_estimate_usd += cost
            return cost

    def snapshot(self):
        with self._lock:
            return {"requests_made": self.requests, "max_requests": self.max_requests,
                    "reserved_tokens": self.reserved_tokens,
                    "max_reserved_tokens": self.max_reserved_tokens,
                    "reserved_cost_usd": self.reserved_cost_usd,
                    "max_cost_usd": self.max_cost_usd,
                    "provider_reported_tokens": self.provider_tokens,
                    "estimated_mock_tokens": self.estimated_tokens,
                    "unknown_usage_requests": self.unknown_usage_requests,
                    "failed_requests": self.failed_requests,
                    "observed_cost_estimate_usd": self.observed_cost_estimate_usd,
                    "blocked_requests": self.rejections,
                    "reservation_method": "utf8_bytes_plus_256_and_max_output_no_refunds"}
