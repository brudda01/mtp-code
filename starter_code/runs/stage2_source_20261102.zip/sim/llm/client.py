"""Minimal OpenAI-compatible chat client. Works with OpenAI, DeepSeek, Groq,
OpenRouter, Ollama (base_url http://localhost:11434/v1). Extend per P6:
retries/backoff, cost table, caching, budget abort."""
from __future__ import annotations
import os, time, json
import urllib.request


class LLMClient:
    def __init__(self, model: str = "gpt-4o-mini", base_url: str | None = None,
                 api_key: str | None = None, **kwargs):
        self.model = model
        self.base_url = (base_url or os.environ.get(
            "LLM_BASE_URL", "https://api.openai.com/v1")).rstrip("/")
        self.api_key = api_key or os.environ.get("LLM_API_KEY", "")
        self.total_tokens = 0
        self.total_cost = 0.0  # fill price table in P6

    def chat(self, messages, temperature=0.7, max_tokens=300, json_mode=True,
             retries=3):
        body = {"model": self.model, "messages": messages,
                "temperature": temperature, "max_tokens": max_tokens}
        if json_mode:
            body["response_format"] = {"type": "json_object"}
        req = urllib.request.Request(
            self.base_url + "/chat/completions",
            data=json.dumps(body).encode(),
            headers={"Content-Type": "application/json",
                     "Authorization": f"Bearer {self.api_key}"})
        last_err = None
        for attempt in range(retries):
            try:
                with urllib.request.urlopen(req, timeout=60) as resp:
                    data = json.loads(resp.read())
                usage = data.get("usage", {})
                self.total_tokens += usage.get("total_tokens", 0)
                return data["choices"][0]["message"]["content"]
            except Exception as e:  # noqa: BLE001
                last_err = e
                time.sleep(2 ** attempt)
        raise RuntimeError(f"LLM call failed after {retries} tries: {last_err}")
