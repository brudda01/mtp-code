"""LLM-driven trader: persona system prompt + market observation -> JSON order.
Includes JSON repair, budget validation, rolling memory + periodic diary
reflection. See spec sections 5-6; extend per prompt P8."""
from __future__ import annotations
import json, math, re
from sim.agents.base import Agent, Observation
from sim.market import Order

PROMPT_VERSION = "raw_economics_v2"

SYSTEM_TEMPLATE = """You are {name}, a {age}-year-old {occupation} trading stocks with your personal savings.
Profile: risk tolerance {risk}; style {style}; horizon {horizon}. {backstory} {biases}
You trade shares of {ticker} on a simulated exchange. Each round is one {round_unit}.
The exchange batches all orders and clears at one price. No short selling, no borrowing:
you can only sell shares you own and spend cash you have. limit_price is in currency units
(e.g. 101.5), or null to accept the clearing price.
After the auction, holders receive the dividend; remaining cash earns interest.
The interest rate quoted below is per round. Dividend income earns interest from the next round.
Respond ONLY with a JSON object, no other text:
{{"action": "buy"|"sell"|"hold", "quantity": <int >= 0>, "limit_price": <number or null>, "reasoning": "<1-2 sentences in character>"}}"""

USER_TEMPLATE = """Round {rnd}/{total}. Recent closing prices (old to new): {hist}
Previous round: volume {vol}, dividend paid {div:.6g} per share. Risk-free rate: {r:.8g} per round.
{news}{bbs}{fund}Your account: cash {cash:.2f}, shares {shares} (avg cost {avg:.2f}), total wealth {wealth:.2f}.
Your recent trades: {trades}
Your trading diary: {diary}
Decide your order for today. Remember: JSON only."""


class LLMAgent(Agent):
    def __init__(self, agent_id, cash, shares, rng, params=None,
                 persona=None, client=None, temperature=0.7, log_fn=None,
                 initial_price=100.0, initial_cost=None,
                 transaction_tax=0.0, price_band=0.2):
        super().__init__(agent_id, cash, shares, rng, params,
                         initial_price=initial_price, initial_cost=initial_cost,
                         transaction_tax=transaction_tax, price_band=price_band)
        self.persona = persona or {}
        self.client = client
        self.temperature = temperature
        self.diary = "New to this market; no view yet."
        self.memory: list[str] = []
        self.log_fn = log_fn or (lambda rec: None)
        self.parse_failures = 0
        self.api_failures = 0

    def system_prompt(self, ticker: str) -> str:
        p = self.persona
        return SYSTEM_TEMPLATE.format(
            name=p.get("name", self.agent_id), age=p.get("age", 35),
            occupation=p.get("occupation", "professional"),
            risk=p.get("risk_tolerance", "medium"),
            style=p.get("strategy_inclination", "balanced"),
            horizon=p.get("horizon", "medium"),
            backstory=p.get("backstory", ""),
            biases=p.get("bias_clauses", ""), ticker=ticker,
            round_unit=self.params.get("round_unit", "trading_session").replace("_", " "))

    def user_prompt(self, obs: Observation) -> str:
        news = f"News today: {'; '.join(obs.news)}\n" if obs.news else ""
        bbs = (f"Forum posts from other traders: {' | '.join(obs.bbs_posts)}\n"
               if obs.bbs_posts else "")
        fund = (f"Analyst fair-value estimate: {obs.fundamental_hint:.1f}\n"
                if obs.fundamental_hint is not None else "")
        return USER_TEMPLATE.format(
            rnd=obs.round, total=obs.total_rounds,
            hist=[round(x, 2) for x in obs.price_history],
            vol=obs.last_volume, div=obs.last_dividend, r=obs.risk_free_rate,
            news=news, bbs=bbs, fund=fund, cash=obs.my_cash,
            shares=obs.my_shares, avg=obs.my_avg_cost, wealth=obs.my_wealth,
            trades="; ".join(obs.my_recent_trades) or "none",
            diary=self.diary)

    @staticmethod
    def _extract_json(text: str) -> dict | None:
        if not isinstance(text, str):
            return None
        for candidate in (text,
                          re.sub(r"^```(json)?|```$", "", text.strip(), flags=re.M),
                          text[text.find("{"): text.rfind("}") + 1]):
            try:
                result = json.loads(candidate)
                if isinstance(result, dict):
                    return result
            except Exception:  # noqa: BLE001
                continue
        return None

    def decide(self, obs: Observation) -> Order:
        ticker = self.params.get("ticker", "KGP")
        msgs = [{"role": "system", "content": self.system_prompt(ticker)},
                {"role": "user", "content": self.user_prompt(obs)}]
        order, raw = None, ""
        attempts, failure_type = [], None
        for attempt in range(2):
            call = {"messages": [dict(m) for m in msgs]}
            try:
                raw = self.client.chat(msgs, temperature=self.temperature,
                                       max_tokens=self.params.get("max_tokens", 300))
            except Exception as exc:
                self.api_failures += 1
                failure_type = "api_failed"
                call["error_type"] = type(exc).__name__
                attempts.append(call)
                break
            call["raw"] = raw
            attempts.append(call)
            d = self._extract_json(raw)
            error = "response must be a JSON object with buy, sell, or hold action"
            if d and d.get("action") in ("buy", "sell", "hold"):
                try:
                    qty = d.get("quantity")
                    if type(qty) is not int or qty < 0:
                        raise ValueError("quantity must be a nonnegative integer")
                    lp = d.get("limit_price")
                    if lp is not None:
                        if type(lp) not in (int, float) or not math.isfinite(lp) or lp <= 0:
                            raise ValueError("limit_price must be positive and finite, or null")
                        lp = float(lp)
                    order = Order(self.agent_id, d["action"], qty, lp,
                                  obs.round, str(d.get("reasoning", ""))[:400])
                    break
                except (TypeError, ValueError) as exc:
                    error = str(exc)
            call["validation_error"] = error
            msgs.append({"role": "assistant", "content": raw})
            msgs.append({"role": "user", "content":
                         f"Your reply was invalid: {error}. "
                         "Reply with ONLY the JSON object."})
        if order is None:
            if failure_type is None:
                self.parse_failures += 1
                failure_type = "parse_failed"
            order = Order(self.agent_id, "hold", 0, None, obs.round,
                          failure_type)
        order = self.validate(order, obs.price_history[-1])
        self.log_fn({"agent_id": self.agent_id, "round": obs.round,
                     "prompt_version": PROMPT_VERSION,
                     "prompt": msgs[1]["content"], "raw": raw,
                     "system_prompt": msgs[0]["content"],
                     "attempts": attempts, "failure_type": failure_type,
                     "parsed": dict(order.__dict__)})
        return order

    def end_round(self, obs: Observation, order: Order, price: float):
        self.memory.append(f"r{obs.round}: P={price:.2f} I chose "
                           f"{order.side} {order.quantity}")
        self.memory = self.memory[-10:]
        reflect_every = self.params.get("reflect_every", 10)
        if reflect_every and obs.round % reflect_every == 0 and obs.round > 0:
            msgs = [{"role": "system", "content":
                     "You are the trader's inner voice. Summarize situation, "
                     "market view, and plan in under 120 words, first person."},
                    {"role": "user", "content":
                     f"Diary so far: {self.diary}\nRecent rounds: "
                     f"{'; '.join(self.memory)}\nWealth now: "
                     f"{self.wealth(price):.2f}"}]
            try:
                self.diary = self.client.chat(msgs, temperature=0.0,
                                              max_tokens=self.params.get("max_tokens", 300),
                                              json_mode=False)[:800]
            except Exception:  # noqa: BLE001
                pass
