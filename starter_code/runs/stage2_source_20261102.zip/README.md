# LLM-agent stock exchange — checked economic foundation

Small batch-auction simulator with rule-based and mock-LLM traders. The current
implementation completes Stages 1 and 2: execution correctness, checked
configuration, explicit cash-flow timing, and constrained two-sided liquidity.
Original planning documents are in the parent directory;
current decisions and evidence are in `../RESEARCH_DIARY.md`.

Read [ECONOMIC_MODEL.md](ECONOMIC_MODEL.md) for the timing, valuation assumptions,
configuration rules, and output meanings. New baselines use bounded independent
dividends and permanent mean shifts. The original `dev_mock.yaml` is labelled
legacy and retains its approximate valuation. This is not yet a validated
financial-market model.

## Quickstart
From `starter_code/`:

```powershell
python -m pip install -r requirements.txt
python -B -m unittest discover -s tests -v
python -B -m sim.engine --config configs/baseline_mock.yaml
python -B -m sim.engine --config configs/baseline_rules.yaml
python -B -m sim.engine --config configs/diagnostic_shock.yaml
python -B -m sim.metrics runs/<the-new-run-dir>
```

The new regression suite uses standard-library `unittest` and also runs under
pytest. It exercises all four original smoke tests as well as accounting,
allocation, failure-handling, news, and reproducibility regressions. No live API
calls are made by the suite or by the supplied mock config. All dependencies in
`requirements.txt` are not needed just to run the foundation tests: numpy and
PyYAML suffice. Pytest, arch, and tqdm support later/optional workflows.

Every run gets a unique directory. `--output-root <directory>` changes its parent.
`events.csv` records delivered news. `cashflows.csv` checks monetary accounting,
`liquidity.csv` records quotes/fills, and `initial_state.csv` saves endowments.
Account logs include cost basis and paid income. `summary.json` identifies the
random-stream scheme, economic model, and prompt version. The saved normalized
configuration can be reloaded; unsupported settings fail before creating outputs.

## Implemented execution rules

- Market buys reserve cash at the full configured upper band, including tax.
  Limits and sell quantities respect available cash and holdings.
- Initial shares use the initial reference price as acquisition cost; an agent
  group may supply `initial_cost` explicitly. Buyer tax enters acquisition cost.
- Tick rounding preserves original limits; bands restrict valid execution prices.
- Better-priced orders fill first. At equal prices, integer pro-rata allocation
  uses largest remainders, with seeded random ties. Remaining symmetric clearing
  price ties choose the lower price after volume and distance to previous close.
- Settlement checks the entire batch before changing accounts. Same-auction
  proceeds cannot finance buys. Tax is recorded separately from trader cash.
- Environment, population, personas, and auction allocation have separate seeded
  streams. Agent count and execution randomness cannot alter the dividend path.
- Malformed replies receive one corrective attempt; persistent failures and
  exhausted client requests become logged HOLDs. Repair attempts are retained.
- Market makers may return one buy and one sell order, with finite cash and a
  hard inventory cap; other agents keep the single-order interface.
- News arrives before orders; the dividend draw and payouts occur after clearing.
  Interest applies to post-settlement cash, without reinvesting the new dividend.

## Live models and research comparisons

A minimal OpenAI-compatible client already exists. Keep `provider: mock` during
foundation work. Live-model access is planned after economic consistency and
run provenance are ready, for controlled decision probes and the comparison of
raw observations, factual summaries, and reflection. The corrected simple agent
will remain a selectable baseline. The permanent comparison is A: corrected
simple agent, B: A plus factual summaries, C: B plus reflection. These separate
modes are scheduled for Stage 3; they are not implemented by Stage 2.

## Next bounded stages

Versioned observation/memory modes and complete call provenance; then a small
live-model pilot and matched experiments. Resume, a forum, policy experiments,
and a continuous order book remain later work. The prepared P1-P13 sequence is
reference material; follow the revised temporary plan and research diary.
