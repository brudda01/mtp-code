# Economic conventions (Stage 2)

This is a controlled laboratory market. Its parameters are explicit modelling
choices, not estimates fitted to an actual stock exchange. The thesis component
comparison must keep these conventions fixed across A (corrected simple agent),
B (factual summaries), and C (added reflection). Those selectable modes are
scheduled for Stage 3; Stage 2 does not implement their behavioural comparison.

## One round

1. Start the period and announce its scheduled news. Agents see previous payouts,
   their portfolios, recent auction prices, and the permitted public information.
2. Collect orders and hold a uniform-price auction. Reserve cash and shares from
   opening portfolios; proceeds from this auction cannot finance its other orders.
3. Settle trades and collect tax from both parties, if configured.
4. Draw the current dividend. Post-auction holders keep their positions through
   the period and receive the per-share payout. Post-settlement cash earns the
   per-round interest rate. Dividend income is not reinvested within the round.
5. Record cash flows, portfolios, and liquidity. Mark stock holdings at the latest
   auction price. No separate post-dividend price auction is simulated.

Thus `prices.csv` contains auction clearing prices before the round's income,
not a separately observed ex-dividend closing price. Account wealth includes
cash income already paid. Price-return diagnostics and portfolio total returns
must be distinguished; do not add recorded income to wealth a second time.

`time.round_unit` labels the period. `time.periods_per_year` describes its scale;
it does not convert rates behind the scenes. `asset.risk_free` is always per
round. A yearly compound return corresponding to r and n periods is (1+r)^n-1.

## New baseline: iid_permanent

For current dividend mean m and relative noise h:

    dividend = m * Uniform(1-h, 1+h),  0 <= h <= 1

Draws are independent across rounds. The distribution is nonnegative and has
exact expectation m, without a truncation-induced upward shift in its mean.
Permanent shocks multiply m starting at the announced round. Finite `duration`
is rejected in this model instead of applying an inconsistent valuation formula.
Headline-only events are allowed and do not alter m or the random draws.

For a stationary regime, a constant risk-neutral benchmark P satisfies:

    P * (1+r) = P + E[dividend]
    P = m/r

This benchmark assumes a positive rate, constant expected future cash flows,
no anticipation of future unannounced regime changes, no risk premium, and no
trading friction. It is a frictionless reference when a transaction tax is used,
not a prediction that every risk-averse trader should agree or transact at P.
It does not anticipate the simulator's future scripted news schedule.

The supplied baseline uses r=0.0002 and m=0.02, giving P=100. Relative dividend
noise is 0.2. A 300-round interest-only account grows by about 1.062, compared
with about 19.788 under the old r=0.01. With 252 sessions per year the new rate
corresponds to about 5.17% compounded annually; this is a scale choice, not a
calibrated estimate. Dividends and interest inject cash from an external issuer
and bank. Aggregate cash is not required to remain constant over long runs.

## Legacy AR(1) demonstration

`legacy_ar1` retains the clipped AR process and temporary mean effects:

    d = max(0, m + rho*(previous_dividend-m) + sigma*Normal(0,1))

Its m/r reference is explicitly labelled `legacy_perpetuity_approximation`.
Clipping, transitory effects, and conditional AR expectations are not priced
exactly. `dev_mock.yaml` retains the old parameters under this explicit label;
it is not the recommended foundation for mispricing research. Old configurations
with rho/sigma and no model are interpreted as legacy with a warning.

## Accounting and liquidity

Every round must satisfy, within floating-point tolerance:

    cash_after = cash_before - tax_paid + dividends_paid + interest_paid
    dividends_paid = total_shares * dividend
    interest_paid = post_settlement_cash * r

Total shares remain constant. `cashflows.csv` records the inputs and error,
`initial_state.csv` records the starting endowments, and `agents_state.csv`
records each account's dividend and interest income. Initial share cost defaults
to the initial reference price unless explicitly supplied; buyer tax is included
in subsequent acquisition cost.

The market maker posts one buy and one sell quote around an inventory-adjusted
center. It cannot borrow cash, short stock, or buy beyond its inventory cap.
Quotes may remain unfilled; liquidity is not guaranteed. Other trader types
continue to return a single Order. `validate_orders` supports both interfaces,
prevents self-crossing, and allows at most one quote per side per trader.

`liquidity.csv` records submitted limit quotes, fill rate, market-maker volume
participation, and price-band hits. A pre-clearing batch can have a negative
`quoted_spread` because bids and asks cross. This is not a continuous-market
effective spread or transaction cost. Missing quote sides remain blank.

## Checked configuration

`sim/config.py` loads typed configuration and rejects unknown options, duplicate
YAML keys, invalid values, unsupported agent parameters, and unimplemented
mechanisms. Validation happens before a run directory is created. Saved
`config.yaml` includes normalized defaults and can be loaded again.

Supported rule parameters are activity_prob (random), delta/aggressiveness
(fundamentalist), window/aggressiveness (momentum), and spread/inventory_limit/
inventory_target/inventory_skew/quote_size (market maker). Spread is a half-spread.
Currently unimplemented risk_aversion/horizon numerical parameters are rejected.
LLM persona traits still come from the library. Use environment variables for
provider credentials; configuration does not accept API keys.

Agent groups may use either fixed cash or `cash_dist: lognormal(mu, sigma)`.
The sampler uses the population stream, so it cannot alter the dividend path.
Heterogeneous cash is optional; controlled comparisons should match resources.

## Diagnostic recipes

- `baseline_rules.yaml`: 1,000 rounds, 20 rule traders, disclosed benchmark,
  no news. Disclosure makes this a value-trading engineering diagnostic.
- `diagnostic_shock.yaml`: identical setup, with a permanent +20% dividend-mean
  shock at round 500. Pre-shock exogenous paths match the no-news recipe.
- `baseline_mock.yaml`: 100-round pipeline demo including eight mock agents,
  with the benchmark hidden. Its population and disclosure differ from the
  rule diagnostic, so these files are not a controlled LLM-versus-rule experiment.
- `dev_mock.yaml`: explicitly labelled legacy demonstration.

These diagnostics do not validate human behaviour. Keep pilot calibration,
held-out evaluation, and the A/B/C live-model component study distinct.
