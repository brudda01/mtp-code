# Thesis results brief

**Writing updated (R048, 2026-11-05):** The
[revised thesis draft](thesis/THESIS_DRAFT.md) now integrates R047 into its
abstract,methods,all-context results,discussion and conclusion. Its
[claim map](thesis/README.md) and [study inventory](thesis/appendix/STUDY_INVENTORY.md)
retain the execution and background-market findings alongside reflection.
This is a checked content draft;formatting,wider literature and final review
remain unfinished. No new experiments were run during integration.

**Controlled follow-up completed (R047, 2026-11-05):** All24 common-history
B/C continuations completed. Reflection narrowed the post-history gap in2of6
contexts,widened it in1,and left it unchanged in3. Same-mode branch differences
were at least as large as the between-mode mean contrast in every context;
this is descriptive,not an equivalence/significance test. Individual returns
remain mixed. C used25.62% more known reported tokens;one recovered B attempt
has unknown usage. Saved-response replay verified23paths/161financial CSVs;
the recovered-error path is explicitly excluded. See the
[manual interpretation](starter_code/runs/common_prefix_analysis_20261105/INTERPRETATION.md).
The earlier R043 pattern below remains historical descriptive evidence.

**Examiner-audit correction (R046):** C's gap advantage was already present
in all six B/C pairs before reflection. The R043 whole-run gap pattern below
is descriptive,not evidence that reflection caused an improvement. Exact
offline financial replay passed for all42final paths;fresh LLM repeatability
and external realism remain separate questions. See
[the critical review](thesis/EXAMINER_REVIEW.md).

**Follow-up completed, 2026-11-05:** R043 finished all18 quiet A/B/C markets,
432 decisions and24 own-history reflections. Averaging two model draws within
each of three fresh scenarios, C had a smaller price-to-value gap than B in all
three (5/6 individual draws). But C versus A worsened the average gap in one
scenario, individual return effects were mixed across traders/valuation marks,
and C used16.5% more reported tokens than B. This adds a bounded component
trade-off result, not a universal reflection or human-realism improvement.
Read the [R043 interpretation and all-case tables](starter_code/runs/quiet_components_analysis_20261105/INTERPRETATION.md).
The original R042 brief and older evidence remain in their unchanged archives.

Evidence checked on 2026-11-05. This brief brings together completed studies;
it adds no model calls or simulated markets. Numerical checks and source hashes
are in the [R042 synthesis pack](starter_code/runs/thesis_synthesis_20261105/report.json).
The [research diary](RESEARCH_DIARY.md) retains the decisions, failures and earlier findings.

## The question we can answer

**How do trading constraints, market design and an LLM agent's information
representation affect the conclusions drawn from a simulated stock market?**

We have a working exchange, experiments and useful findings. The strongest
current contribution is a careful account of how conclusions depend on the
environment and measurement. We have not demonstrated that LLM traders reproduce
human behaviour or consistently outperform rules.

The exchange runs one stock through repeated batch auctions: agents submit
orders, compatible orders trade at a common session price, then accounts receive
dividends and cash interest. Cash and shares constrain trading; orders can be
accepted without filling. A market maker supplies liquidity. In the live studies,
two of fourteen traders use the same Qwen model with different personas; the
other traders follow rules. Matched rule-only populations preserve total resources.

Trading decisions used BharatCode's `qwen-3.8-27b`, temperature 0.3 and low
reasoning effort; backend randomness was unseeded. R041 used an 8,192-token
output cap, as did the sequential A/B/C study. The older fixed-state A/B/C
study used 4,096. Prompt versions, personas, configs and actual messages remain
in each source study's sealed artifacts; these differing cohorts are not pooled.

There are three selectable LLM modes: **A**, raw observations and recent actual
outcomes; **B**, A plus factual summaries; **C**, B plus reflection on actual
history. These remain available for comparisons. The economic mechanism is
documented in [ECONOMIC_MODEL.md](starter_code/ECONOMIC_MODEL.md).

## Finding 1: prices alone can hide a meaningful news response

R041 completed sixteen eight-session markets: two fresh dividend scenarios,
two fresh model repetitions, two market-maker settings, and a visible/silent
headline pair for each combination. Both sides of each pair received the same
actual permanent 20% dividend-mean reduction from session one. Only one side
received the truthful bulletin. All 256 decisions completed without API or
output failures. A separate explicit reading task passed 12/12 replies, but
that does not establish understanding in every natural trading decision.

Our primary measurement was the headline's visible-minus-silent difference in
the two LLM traders' **net executed purchases during the first three sessions**.
A negative number means more selling, less buying, or both.

| Scenario | Model repetition | Original market maker | No inventory skew |
|---|---:|---:|---:|
| 20611 | 1 | -2 shares | -156 shares |
| 20611 | 2 | -122 shares | 0 shares |
| 21727 | 1 | -106 shares | -106 shares |
| 21727 | 2 | -3 shares | -128 shares |

Seven contrasts were negative and one was zero. These are eight comparisons
nested in **two exogenous scenarios**, not eight independent seed replications.
The background change did not consistently strengthen the response: its four
differences were -154, +122, 0 and -125 shares.

Two examples explain why aggregate measures need care:

- In scenario 21727, repetition two, original background, Meera's news contrast
  was -90 shares and Arjun's was +87. The combined -3 concealed opposing responses.
- In scenario 20611, repetition two, no-skew background, the entire closing-price,
  dividend and private-value paths matched between visible and silent markets.
  Yet the silent market included a session-five sale of 50 shares from Arjun to
  Meera at 92.8 that did not occur in the visible market. Relative to the silent
  market, Meera's terminal wealth above her passive account was higher by
  **580.54 at the auction mark, or 640.54 at the private-value mark**; Arjun had
  the opposite differences. Other traders' account paths matched. This was a
  transfer between individuals that a price-only analysis would miss.

**Interpretation:** measure requested orders, executable orders, actual fills,
counterparties and both wealth marks. HOLD can express avoiding a purchase or
sale; it is not automatically evidence of ignoring information. A passive
comparison separates trading gains from gains or losses on initial holdings.
Transfers do not establish aggregate welfare or profitability improvements.

The same first-visible Arjun input and generation settings produced two BUY,
one SELL and five HOLD replies across eight calls. Model draws matter even before
histories diverge. This does not identify human biases or the cause of backend
variation. We have tested initial truthful downside news, not established trends,
misinformation, general positive/negative symmetry or long-run behaviour.

Sources: [all eight contrasts and interpretation](starter_code/runs/downside_confirmation_analysis_20261104/INTERPRETATION.md),
[exportable response figure](starter_code/runs/downside_confirmation_analysis_20261104/figure_v2/executed_responses.pdf),
[raw-source mechanism audit](starter_code/runs/downside_confirmation_analysis_20261104/mechanism_audit.json).

## Finding 2: improving one market statistic can worsen another

R039 tested the market background independently of the LLM: four fresh matched
scenario pairs, each with 600 sessions, using rule traders. The single change
removed the market maker's inventory-dependent quote adjustment. Inventory
bounds and all other economic settings stayed the same.

| Measurement, mean across four scenarios | Original skew | No skew |
|---|---:|---:|
| Lag-one log-price-return autocorrelation | 0.1745 | 0.1160 |
| Sessions with market-maker inventory empty or full | 0.875% | 4.458% |
| Shares traded per session / total shares | 1.311% | 1.216% |
| Mean absolute price gap from private value | 6.394% | 4.878% |

Autocorrelation measures how strongly one return is associated with the next.
It fell in all four full-path pairs, while empty/full inventory time rose in all
four. Turnover fell in three pairs, not all four; the price gap also worsened in
one pair. Three of twelve nested 200-session block contrasts reversed the
full-path autocorrelation direction. No-skew is therefore a sensitivity result,
not a selected realistic default.

A fixed 600-observation US market reference (2023-08-11 to 2025-12-31) adds
context. Using comparable **total-return** definitions, its lag-one correlation
was -0.0387, versus 0.1754/0.1170 in the original/no-skew rule markets.
Correlation of absolute total returns, a simple volatility-persistence diagnostic,
was +0.2079 in the reference but -0.0043/-0.0032 in the simulations. That leaves
an evident diagnostic gap even when one simulation statistic improves.
The reference is a diversified US portfolio, not this small simulated stock;
one historical window supplies context rather than a universal pass criterion.
The saved source is the [Kenneth French daily factors dataset](https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/data_library.html);
market total return is Mkt-RF plus RF, following the
[official factor definition](https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/Data_Library/f-f_factors.html).

**Interpretation:** market realism needs several diagnostics and robustness
checks. A smaller valuation gap alone cannot establish realism. These are long
rule-market tests; short LLM markets have not demonstrated long-run stylized facts.

Sources: [new paired comparison figure](starter_code/runs/thesis_synthesis_20261105/background_tradeoff.pdf),
[all paths, inventory and qualifications](starter_code/runs/20261104_154730_market_validation_fff53e3b/supplement/INTERPRETATION.md),
[full numerical readout](starter_code/runs/20261104_154730_market_validation_fff53e3b/READOUT.md).

## Exploratory result: more memory is not yet a demonstrated upgrade

The earlier fixed-state A/B/C study attempted all 108 scheduled choices:
107 valid orders and one retained output-cap failure. C used 24 genuine
reflections, costing **59,907 provider-reported tokens** in addition to its
decision calls. Reported totals include known retry usage, but seven failures
have unknown usage, so the totals are incomplete. Those reflections shared A's prior history
across news branches, so this was not C following its own market trajectory.

The subsequent sequential comparison did give C its own executed history.
Seven of nine 24-session markets completed. Two C markets stopped after 22 and
19 sessions; these remain incomplete. Only scenario 6317 has a complete A/B/C
comparison. There, C versus B had a **0.476 percentage-point larger post-event
mean valuation gap**, 29,842 more reported tokens, and lower passive-relative
returns for both traders under both terminal marks. Meera's differences were
-3.871/-3.533 percentage points; Arjun's were -0.820/-0.028 points
(auction/private-value marks). B versus A results varied by scenario and mark.

This is useful evidence against assuming reflection automatically helps, but
one complete scenario cannot establish that reflection generally hurts either.
Older studies also disclosed the finite horizon and used a dividend sentence
that allowed a compounding interpretation. They remain separate from the newer,
clarified initial-news studies; there is no causal old/new wording result.

[EconAgent](https://arxiv.org/abs/2310.10436) motivates investigating heterogeneous
LLM agents and memory/reflection in work-and-consumption macroeconomic simulation.
It does not validate our exchange or establish that adding reflection should
improve stock-trading outcomes here. Our selectable A/B/C comparison examines
that question in a different environment.

Sources: [fixed-state coverage, costs and limitations](starter_code/runs/component_final_analysis_20261103/READOUT.md),
[full sequential comparison, including missing markets](starter_code/runs/sequential_final_analysis_20261104/READOUT.md).

## What to take into the thesis, and what comes next

The first two findings can support bounded results sections now. The A/B/C
comparison belongs in an explicitly exploratory section. Engine checks, model
qualification and the reading gate support methods; they are not headline
human-realism findings. Preserve counterexamples and incomplete outcomes in the
results and appendix, rather than selecting only successful-looking paths.

R043 has now completed the **fresh, complete, matched quiet A/B/C replication**
proposed at R042, with common information/horizon disclosure, own-history
reflections, repeated model draws and a frozen failure policy. It supplies
three complete exogenous scenarios but remains a small within-model study.
The clearest next decision is selecting the thesis claims and the external
validation they would require. No further component, provider or parameter
sweep is automatically scheduled.

For now, use this brief and the linked figures to select the thesis claims with
the supervisor. No additional API integration is needed to use these results.
Human validation, herding and general LLM superiority remain outside the claims
supported by the completed work.
