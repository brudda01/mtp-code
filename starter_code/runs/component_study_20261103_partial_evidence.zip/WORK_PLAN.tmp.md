# Temporary implementation plan

## Bounded pass R025 (2026-11-03, stopped with partial evidence)

- [x] Implement/freeze a fixed-history news/component study using ALL four
  designated R024 control-market round11 frames, without changing accounts or
  inventing trades. Positive/negative/no headline x A/B/C x three fresh repeats:
  108 decisions. These are fresh calls on reused states, not held-out markets.
- [x] Implement C's two real reflections per frame/repeat from that agent's
  actual rounds1-5 and6-10 outcomes, carrying the first reflection into the
  second. Share the resulting pre-news diary across its three news variants.
  This adds24 calls; total132 planned. It conditions on a common A-generated
  past, not an endogenous C trajectory, execution test or news-retention proof.
- [x] Verify exact source records, only-treatment prompt differences, no
  future/hidden inputs, fresh independent choice instances, unique IDs,
  counterbalanced mode/news order and terminal-failure stops offline.
  Full suite158 pass. Prepared runs/20261103_023441_news_components_da6bdf79;
  no prior simulator source changed, only the new bounded runner added.
- [x] Freeze source/inputs/settings before calls; run Qwen once with existing
  opt-in one-extra-attempt delivery policy. New separate study caps264 total
  attempts/4M conservative reservations, chosen10RPM/60000 input-estimate TPM;
  all retries/JSON repairs count, unknown failed usage retained. No NVIDIA or
  model substitution. Stop on terminal provider/output/budget/parse/reflection
  failure and preserve partials; no blind restart or general replay framework.
  Stopped at03:04 IST:34/108 choices,8/24 reflections. Terminal503 and its
  single retry both failed; PID15368 exited, no API job active. No restart.
  Full suite158 pass, all34 choices valid/unclipped, no full repeat set.
  49 attempts/135427 reported tokens/641213 reservations/7 unknown usages.
- [x] Audit every available condition and negative/null case. Report requested/accepted
  quantities, natural buying/selling headroom, executable price intervals,
  repeat variation, A/B and B/C news contrasts, failures and reflection cost.
  No orders execute; no full-market/performance/human-realism conclusion.
  Update diary, candidate index, working notes and next bounded decision.
- [ ] Complete all108 decisions and24 reflections (NOT achieved). Analysis:
  starter_code/runs/component_analysis_20261103/ (READOUT.md/report.json).
  remaining_work.json inventories74 pending choices +16 new reflections.
  Any future explicitly linked continuation must preserve prior usage and the
  last block's generated diary; remaining caps215 attempts/3358787 reservations.
  This is an inventory, not a resume implementation or automatic restart.
  No model switch, new retry framework or qualification sweep in this pass.

**Prior checkpoint, 2026-11-03:** R024 COMPLETE. The existing background
job finished 2026-11-02 23:06 IST during the user's usage-limit pause; PID22644
exited. All 8 rule + 8 live 20-round markets and 24 same-state queries completed.
No API job is active; do not rerun after the reset. Final readout/audit:
`starter_code/runs/news_query_first_analysis_20261102/` (READOUT.md/report.json/
delivery_audit.json). All phases count 402 attempts/1122587 reported tokens/
4879158 reservations/10 unknown usages/1 blocked request. Seven transport retries
recovered; no server-503 retry was needed live. 150 offline tests pass.
Meera's first-seed positive headline contrast is mixed in seed2882; both Arjun
frames lack buying headroom. Combined real-shift/news gaps are smaller in both
seeds, but market pre-event states differ. Preserve negatives and constraints,
old partials, order/fill distinctions, both passive marks and A/B/C.
The old R022/R023 stopped checkpoints below are history; R024 supersedes their
completion status. Read the diary before new work. No model/default change.

Approved by the user on 2026-11-02. This is a resumable working checklist;
lasting decisions and evidence belong in RESEARCH_DIARY.md. Complete and verify
one bounded stage per coding pass. Do not mix later research features into an
unfinished foundation. The existing staged diary/AGENTS changes belong to the
user's working tree; do not stage, unstage, or commit them automatically.

## Stage 1 - Correct execution and controlled randomness (complete)

- [x] Enforce buy/sell budgets including transaction tax and the actual maximum
      market-order execution price; reject invalid/non-finite orders safely.
- [x] Initialize share cost basis explicitly (default: initial reference price).
- [x] Correct tick/band treatment and remove systematic equal-price ID priority.
- [x] Validate a whole settlement batch before mutation; conserve shares and
      cash plus the tax ledger and prevent accidental borrowing/shorting.
- [x] Connect top-level news; isolate environment, allocation, and trader RNGs.
- [x] Make malformed LLM replies and exhausted API calls produce logged HOLDs;
      retain the current decision prompt and memory behaviour as a simple base.
- [x] Add meaningful regression tests and run the original smoke checks and a
      mock end-to-end simulation. Record engineering outcomes, not realism claims.
- [x] Update diary, README, and this checklist; stop at the verified boundary.

Acceptance: reproduced negative-cash and array-JSON bugs are fixed; valid trades
respect original limits; equal-price allocations are proportional with seeded
integer tie handling; population changes do not change dividends; mock runs are
repeatable with valid logs. No paid or live LLM calls are needed for this stage.

## Stage 2 - Explicit experiment configuration and coherent economics (complete)

- [x] Add checked configuration and reject unsupported options.
- [x] Specify time units, cash-flow/auction timing, conservative baseline rate and
  dividend scales, and valuation assumptions. Initially use simple cash flows
  and permanent shocks, keeping legacy configs identifiable as legacy.
- [x] Add two-sided, capital/inventory-constrained market-maker orders and liquidity
  diagnostics, without introducing a persistent continuous order book.
- [x] Validate long rule-based runs, cash growth, tax/dividend/interest accounting,
  and expected-value response to permanent shocks.
- [x] Document the economic assumptions and engineering results in the diary.

Chosen bounded economic baseline: one round is a trading session, cash earns a
configured per-round rate, and closing holders receive that round's random
dividend after the auction. Use positive bounded IID dividends with a configurable
relative noise level and permanent mean shifts; mean/r is the stationary-regime
risk-neutral benchmark, not an externally calibrated price prediction. Keep the
original AR(1) demo explicitly marked legacy. Add per-round cash-flow conservation
and liquidity records. The A/B/C agents share these economic rules.

## Stage 3 - Minimal comparable agents and pilot provenance (complete, bounded)

Review adjustment (approved direction): bound this stage to selectable
conditions and minimum reliable provenance/usage limits. Bring a small live-model
pilot forward once those essentials exist. Do not require a polished cache,
general replay framework, exhaustive metrics suite, or further architecture before
learning whether real agents behave usefully. Investigate the baseline cycles in
a small rule-only sensitivity check, keeping that distinct from live-agent tuning.
Continue to evaluate individual behaviour, macro dynamics, and news/brain-type
comparisons alongside A/B/C. See R006; do not optimize solely for value tracking.

- Define/version condition A (raw observations + actual recent outcomes), B
  (A + factual summaries), C (B + reflection). Preserve A as a selectable mode.
- Add run manifests, model/provider/prompt/persona versions, raw/validated/executed
  orders, every call/repair/reflection, and failure records. Save responses for
  later replay; a general replay command is explicitly deferred.
- Record code/config hashes and dirty state; never log credentials.
- Add request limits, measured usage/cost accounting, and an explicit pilot
  budget before any paid-model evaluation.
- Test all modes offline with deterministic/scripted clients. Do not interpret
  mock differences as evidence about real LLM behaviour.

Bounded acceptance checklist for this pass:
- [x] A/B/C are selectable; all share raw facts, persona, recent verified fills,
  and market constraints. B adds computed facts, C adds periodic reflection.
- [x] Memory records executions, unfilled orders, cash income, and account state;
  reflection never replaces authoritative portfolio bookkeeping.
- [x] Save per-call attempts including reflections, exact source/config/persona
  provenance, usage/cost estimates, and explicit completed/failed/budget statuses.
- [x] Enforce shared request/token reservations and a declared-price cost ceiling
  for live pilots; unknown billing/usage stays explicit. No hidden HTTP retries.
- [x] Test leakage, matching, reflection failures, and budget stops before versus
  after settlement; preserve short mock A/B/C runs as engineering evidence only.
- [x] Screen unchanged baseline versus inventory_skew=0 and varied trend horizons,
  2x2 across seeds 101/202/303, 1000 rounds, same resources and exogenous paths.
  Keep current baseline regardless of which screen cell looks best.
- [x] Update a concise diary entry and candidate index, then stop at the pilot
  checkpoint. Full caching/general replay and a broad metrics rewrite are deferred.

## Stage 4 - Small live-LLM diagnostic pilot (integration checkpoint)

User update: explicitly switched the primary provider to BharatCode student
access, model qwen-3.8-27b, with API_KEY in starter_code/.env. Gemini access
failures are historical, not an instruction to keep retrying Gemini.
Bounded current pass:
- [x] Verify authenticated model access; load API_KEY only for BharatCode's
  official HTTPS endpoint; keep it out of configs/artifacts/source control.
- [x] Adapt the existing pilot for provider settings, queue timeouts and
  student-included usage; test offline before generation.
- [x] Run the same 18 diagnostic cases with raw requests and exact settings.
- [x] If usable, complete six matched four-round A/B/C micro-runs (two seeds,
  two LLM personas), at most 96 generation attempts / 700000 byte-based reserved
  tokens for the batch. No larger study or paid upgrade in this pass.
- [x] Audit matching, actual orders/fills/reflection, usage and failures; retain
  null results and update the diary. No cross-provider causal comparison.

BharatCode integration verified with 96 offline tests. Catalog saved at
starter_code/runs/bharatcode_access_20261102/models.json. Active v4 Qwen protocol:
temperature 0.3 decisions, 0 reflections; low reasoning effort; output cap 2048;
180-second queue/network timeout; chosen 10 RPM / 60000 byte-based input
estimates per minute (not asserted provider limits). Zero incremental per-token
price within the user-reported included student allowance; no paid upgrade.
Qwen probes completed in `20261102_050006_qwen_probes_e918237e`: 18 requests,
10209 reported tokens, no HTTP/parse/truncation errors. Direct arithmetic 8/8;
one empty-account buy was safely clipped; headline pairs bought versus HOLD,
risk-trait pairs were mixed. All six markets completed. Whole batch: 71 calls,
76839 reported tokens, one recovered empty reply, no API/output-cap failures.
Matching and executed-memory audits pass. See qwen_pilot_diagnostic_20261102.json
and R014. No API jobs remain running. Do not rerun completed API phases as a resume.

Historical next-pass proposal after R014 (completed/superseded by R016-R018):
- Disclose common price-band/tick/conservative market-buy reservation rules to
  every agent condition, version the common prompt, and verify the disclosure.
  Eleven market-order reductions here are not automatically numerical errors;
  model agents were not told the full reservation formula. No change implemented
  yet; do not relabel the current v1 prompts/results after making it.
- Repeat fresh contextual-numeracy, risk and news scenarios before freezing a
  larger study. Preserve empty-account failure and null/mixed responses.
- Include both closing-price and regime-benchmark valuations in evaluation;
  neither is a realized liquidation return or proof of welfare/skill.
- Advance toward news/intervention and equal-resource brain comparisons;
  retain A/B/C as one explanatory study. No general reflection benefit follows
  from two four-round diagnostic scenarios.

Completed capability follow-up (DeepSeek key will be provided later):
- [x] Disclose the actual shared tick/band/tax, raw-price cash reservation,
  holding limits and partial-fill rules, retaining all A/B/C treatments. Increase
  the common prompt version; preserve old data without relabelling it.
- [x] Verify configured rule propagation, non-tick boundary/tax examples and
  common information parity offline. Do not alter auction or settlement policy.
- [x] Freeze a fresh model-neutral battery: 14 cases x 3 independent repetitions,
  including objective mechanics/account-memory tasks and discretionary resource,
  news, disclosed-value and one-trait risk contrasts. No profitable-action oracle.
- [x] Run Qwen only, at most 54 attempts / 400000 reserved tokens, preserving
  failures and per-case results. Use the existing included student access.
- [x] Audit all first attempts and repairs, report family/repetition results,
  and preserve the exact battery for the later DeepSeek challenger. No claim of
  causal before/after improvement from comparison with older scenarios.
- [x] Once the battery and adapter specification are concrete, request local
  NVIDIA_API_KEY setup. No NVIDIA generation calls before a key is available.

Capability checkpoint: 107 offline checks passed then (118 after R018). Common prompt is
comparable_agents_v2_disclosed_rules; old v1 artifacts remain unchanged. Frozen
battery: starter_code/runs/20261102_053910_capability_battery_fa9fc215/battery.json.
Qwen qualification is complete (R017). User will provide NVIDIA's key later;
no NVIDIA request has been made and the challenger need not block core work.
Interruption update: the prior turn ended its runner after 13 completed cases;
no runner survived. `20261102_053929_capability_qwen_6cdca7bd` is preserved as
externally_interrupted, with possible unlogged in-flight usage left unknown.
User asked to continue and will provide NVIDIA's key later. One clean whole
42-check Qwen restart is underway using the unchanged frozen battery; partial
results will not be pooled or selectively replayed. Fresh bound: 54 attempts /
400000 reservations, in addition to the preserved prefix (13 known calls plus
at most one unlogged request possible for the sequential runner). No NVIDIA call.
Completion: clean restart completed 34 checks, then a TimeoutError stopped it.
The exact remaining eight were frozen in capability_remaining_20261102 and
completed by 20261102_183644_capability_qwen_2d10464c with the remaining allowance.
Combined: 42 checks, 43 requests including the timeout, 49019 reported tokens,
291582 reservations; objective 54/54 fields and all 30 delivered orders passed.
No current API process. The next-pass visibility/control/protocol work identified
at that checkpoint is now complete in R018; see Stage 5 for the next live pilot.
Objective tasks have numeric oracles; discretionary choices have no profit/sign
oracle. News/persona/value cases use production zero-tax rules; resource cases
include explicit synthetic tax/tick stress. Models will see the same stored
messages, with requested sampling/hidden-compute differences recorded separately.

Historical Gemini pass (user provided GEMINI_API_KEY in starter_code/.env):
- [x] Verify key presence without displaying it; authenticated read-only model
  discovery confirms gemini-3.8-flash is listed for this key.
- [x] Load the Gemini key locally, add shared pacing and fail-fast provider
  stops, then verify offline. Preserve the default mock behaviour.
- [x] Freeze a tiny probe protocol before looking at behavioural replies:
  syntax/arithmetic, resource constraints, signal sensitivity and a one-trait
  risk contrast; retain raw requests and negative/inconclusive outcomes.
- [ ] If access/quotas permit, run short matched A/B/C trials with common
  scenarios and at least two independent repetitions. These are diagnostic
  micro-runs, not evidence about long-run market statistics or human realism.
- [x] Bound the whole live pass to at most 96 generation attempts, conservative paid-rate
  reservations of at most USD 1.00 for the new 3.8 batch (free eligible model;
  account billing unknown; original Lite batch had a separate USD 0.25 ceiling),
  no hidden retries, and stop on quota/auth failures. Do not enable billing.
- [x] Preserve available results/protocol/source and update the diary with
  limitations. The primary 3.8 live trial itself remains incomplete.

Historical Lite progress (superseded as primary model by user): fixed probes completed in
`starter_code/runs/20261102_034741_live_probes_73582e3f/`: 18 attempts, no API
errors/repairs; 8/8 direct arithmetic fields correct. Value=100 versus 120
changed HOLD to BUY 10 in both repeats. Risk-label-only and unverified-headline
pairs stayed HOLD. All constrained orders were feasible, but explanations
contained incorrect cash claims and an invented prior-history claim. Preserve
these limitations. Three market runs completed for seed 704; seed-905 C was
externally interrupted after two logged financial rounds when the user selected
3.8 Flash. See model_switch.json and the partial run's interruption.json; usage
for an interrupted in-flight request may be missing. No Lite job remains running.
Do not pool the models. Do not blindly rerun API commands: reruns make fresh
requests and are not resumes. Current offline suite: 93 pass.

Historical 3.8 primary pilot: gemini-3.8-flash, reasoning_effort=low, output cap 2048,
provider-default sampling (send_temperature=false), protocol
first_live_diagnostic_v3_flash38_default_sampling. The first access attempt
`20261102_040526_flash38_probes_09b9a76b` stopped on HTTP 503 with no model
answer; the explicit retry `20261102_040700_flash38_probes_9054fea8` also stopped
on HTTP 503. These are availability failures, not model-quality evidence.
The native-route diagnostic `20261102_040821_flash38_native_access_0e0abbd4`
also returned HTTP 503 / UNAVAILABLE. No 3.8 answer has returned. Stopped after
these three access attempts; no API job or automatic retry remains running.
Next pass: retry the unchanged v3 protocol when access is available, inspect
its results, then run the matched markets. Do not infer a general provider outage
or quota exhaustion from these responses.
Model/reasoning/cap changes are recorded; this is not an isolated model-size
ablation. Save new probes and matched markets independently of the Lite batch.
User has Google Pro, but do not infer the API project's quota or billing tier
from that subscription. Keep five RPM and fail-fast provider stops until actual
quota evidence supports a change. No billing setup or upgrade is authorized.

Screenshot update (R012): user supplied AI Studio quota evidence for "Gemini
Project", Free tier. 3.8 Flash shows 5 RPM and 250000 TPM; Lite shows 15 RPM and
250000 TPM. Daily limits are not legible; 28-day peaks are not remaining quota.
The existing five-RPM / 15000-input-estimate pacing is within those ceilings.
An unchanged v3 retry `20261102_042706_flash38_probes_9982497f` again stopped on
its first HTTP 503, with no returned answer. No API job remains running.
User's next explicit single retry, `20261102_044650_flash38_probes_2b43ef3b`,
made one request and timed out at 90.223 seconds without an HTTP status/answer.
No automatic or background retry is active; see R013.

- Connect one available provider after the corrected baseline and provenance
  exist. Ask for provider/key only when actually needed; use environment settings.
- Provider checkpoint: user selected Gemini 3.8 Flash after the initial Lite
  pilot. R008's original model selection is superseded; see R009/R010. Verify
  3.8 generation access and keep the same model/settings across its A/B/C runs.
- Before a free-tier market run, add minimal shared request pacing using the
  account's actual RPM/TPM limits. Existing cumulative reservations do not enforce
  provider rate limits. Start with tiny probes; record quota failures separately
  from agent HOLD decisions. Do not enable billing or assume zero prices on a paid
  account. Keep one exact model/settings across A/B/C and record returned IDs.
- Run fixed-observation probes for arithmetic, feasible orders, input sensitivity,
  and one-trait persona differences; keep wording and scenario versions.
- Trial short sequential A/B/C runs, record costs/failures and independent repeats.
- A live comparison with the original buggy simulator is not needed for the
  thesis. A corrected A/B/C component comparison is worth preserving.

## Stage 5 - Headline experiments and credible baselines

Completed R024 (user approved continuation; UI reports 663.8K/10M used today,
resets midnight IST; this is user-reported allowance evidence, not measured RPM):
- [x] Add opt-in HTTP-503 handling, share the one-extra-attempt limit with
  transport retries, honor valid Retry-After up to 60s (otherwise stop), default
  10s wait without header. No auth/quota/client/certificate/output-cap retries.
- [x] Verify safe header parsing, budget/logging and unchanged prompts offline (150 pass).
- [x] Freeze query-first linked phase: first-seed 12 same-state decisions FIRST,
  then five missing markets, then second-seed 12 queries. No favourable selection.
  Explicitly reallocate restart allowance under SAME global 688 attempts/9M
  reservations: prior 171/2055022; each of 5 arms 80/1M; each query half 24/.5M
  gives maxima 619 attempts /8055022 reservations. Older per-arm caps are
  superseded only for this documented phase; all prior work remains counted.
- [x] Run once, stop on terminal failure, no blind phase restart; audit all
  results/limits and update R024. Model, economics, personas and A/B/C unchanged.
  Started hidden PID22644, driver runs/news_query_first_20261102.py;
  study delivery_v4_query_first. Source/config/first-query frames are frozen.
  Complete: all five missing markets plus both query halves, finalized before
  this resumption; no further API calls. Audit date2026-11-03; all hashes,
  matched resources/payouts, exact source/query inputs and global bounds pass.
  Seven transport retries recovered; no live 503 retry. User's usage reset
  requires no rerun. See R024 final entry and READOUT.md.

Next bounded scientific work (PROPOSED, not started):
- [ ] Freeze independent positive/negative/no-news confirmation across both
  balanced and constrained portfolios. Retain naturally constrained nulls;
  analyze buying/selling headroom instead of selecting only favourable states.
- [ ] Preserve the full A simple / B factual summaries / C added reflection
  question. Fixed-state A/B isolates representation; C must use actual logged
  histories/reflections, with retention and extra calls explicit. Do not invent
  reflections or assume absence of an exact old headline proves forgetting.
- [ ] Use that evidence to choose adequate independent full-market confirmation
  and horizon. Keep pre-event divergence, policy order-size differences, fills,
  market activity/dynamics and both passive returns in view. No model switch or
  broad infrastructure extension is motivated by the current mixed results.

R023 ended with partial evidence (user approved continuation after R022):
- [x] Opt-in one transport retry per request group, zero by default; each HTTP
  attempt reserved, paced, logged, unknown usage retained. No HTTP status/auth/
  quota, certificate-validation, malformed-JSON or output-cap transport retries.
  Preserve one separate JSON repair; unique group/attempt IDs and safe reason
  type/code metadata. Do not change prompts, personas or economic mechanics.
- [x] Test recovery, exhaustion, budget/pacing, JSON-repair separation and error
  redaction offline. Confirm old payloads and default financial regression.
- [x] Freeze a new linked delivery phase for ONLY five unfinished market arms
  and the 24 original probes. Combined/1441 is a fresh full arm, keeping its
  old 9-round partial separate; deduct 20 prior attempts/226543 reservations
  (remaining 60/773457). Other four arms 80/1M; probes 48/1M. Prior 142 attempts
  and 1709925 reservations remain counted; whole original bounds still apply.
- [x] Run once with shared pacing, preserve every retry/error and stop on a
  terminal failure; no further phase restart this pass. NVIDIA remains deferred.
  Started hidden PID 8832, recovery_transport_v3, driver
  runs/news_recover_20261102.py. Inspect progress/summary before any calls.
- [x] Audit all phases/partial evidence and report actual news findings/limits
  in R023, preserving A/B/C and avoiding general human-realism claims.
  Stopped as specified: HTTP 503 on round 15, no transport retry eligible;
  new partial 14 rounds stays separate from old 9-round partial. No further calls.

Historical R023 proposal (implemented in R024): opt-in server-503 retry with safe header
parsing and bounded wait/attempts, distinct from auth/quota/client errors. Keep
all attempts/unknown usage within original GLOBAL 688/9M ceilings; explicitly
document any per-arm restart allowance changes before calls. Run available
first-seed same-state pairs first, label subset, then missing frames as available.
Avoid another long run that reaches no clean headline queries. No model switch.

News pass stopped with partial evidence (R022, after its one allowed continuation):
- [x] Implement/freeze news_live_pilot_v2_matched_event_probes before calls.
  Preserve v1's eight A markets, seeds 1441/2882, 20 rounds/event 11, four cells,
  qualified Qwen profile, counterbalanced order and per-market 80 attempts/1M
  reservations. Add eight equal-slot rule counterparts (no API).
- [x] Implement the planned 24 same-state event queries: every control run's two LLM frames
  at round 11, crossed with no headline/the same forecast, three repetitions.
  Derive exact messages/state from saved records, no outcome-based frame choice.
  Extra cap 48 attempts/1M reservations, for total 688 attempts/9M reservations.
  This explicitly amends v1; its numerical market design remains unchanged.
  Remaining student quota is unknown. No billing or NVIDIA calls.
  Not generated: second seed's control is unavailable. Four available first-seed
  variants reproduce source prompts exactly and are marked prepared/not run.
- [x] Verify matching, hidden-state separation, snapshot derivation, metrics,
  failure stops and end-to-end operation offline before generation.
  Full suite 139 pass; final targeted five pass after clarifying failed-arm counts.
- [x] Freeze source/config/protocol, start bounded execution with shared pacing in a hidden
  sequential job; stop whole study on incomplete/provider/output-cap failure.
  Started once, hidden PID 26812, study runs/20261102_202946_news_pilot_786a0370.
  Frozen study SHA256 starts 0a901d2fc24f41d5. Inspect progress/process/summary;
  do not restart or modify simulator source while this job is active.
  Update: original stopped on URLError/no HTTP status, one unknown-usage call.
  Explicit continuation_1 (PID 14112) retains 9 complete markets, repeats only
  the failed zero-round arm then unstarted cases, with used budgets deducted.
  Driver runs/news_continue_20261102.py; first arm now 78/985870. No further
  restart in this pass. All simulator source/model/prompt/economic settings match.
- [x] Complete all eight live arms and 24 same-state queries (not achieved in
  R022; completed later in R024, with linked source/delivery profiles retained).
- [x] Report all available cells, missing/partial arms and pre-event differences; requested/accepted/executed
  quantities, LLM trade involvement, liquidity and both passive wealth marks.
  Preserve no-response/non-convergence cases. Twenty-round/two-seed results
  are exploratory; paired snapshot queries are not full market counterfactuals.
- [x] Audit artifacts, update R022 and review evidence before confirmation/A-B-C.

Historical R022 proposal (implemented in R023/R024; no restart of old phase):
- [x] Opt-in transport retries at request orchestration, every HTTP attempt
  logged/budgeted/paced and unknown usage retained. Zero-retry default preserved;
  no retry on auth/quota errors or output truncation; distinguish JSON repairs.
- [x] Safe underlying error reason-type diagnostics and offline failure tests.
- [x] Version/link the changed delivery profile and recover only incomplete
  arms after deducting all used budgets. Preserve old complete and partial data.
  Do not mistake the partial pilot for a confirmed news or brain-type finding.

Completed bounded live follow-up after R020 (R021):
- [x] Add only the fixed-input runner/action scoring for the saved
  matched_trait_states_v1 battery; reject input/render drift before calls.
- [x] Verify scoring, failure handling and exact-input use offline (134 tests).
- [x] Run Qwen only, 48 scheduled decisions / maximum 96 HTTP attempts /
  1000000 conservative token reservations, included student-token prices zero.
  Temperature .3, low effort, cap 4096, timeout 180; chosen 10 RPM / 60000
  input-estimate TPM, fail fast, no hidden HTTP retry/model substitution.
  Quota remaining is unknown. NVIDIA stays deferred. Freeze scoring before calls.
  Started once as hidden PID 11360, run 20261102_195440_behaviour_qwen_ee95d92d.
  Do not blindly rerun: inspect logs/process/summary first. Inputs hash begins
  67929bd362979762. Request and source snapshots are already on disk.
- [x] Preserve every choice/repair/error and matched risk/gain-loss contrasts,
  failures excluded from preference numerators but retained in reliability.
  No action/profit oracle, no assumed persona effect and no simulated fills.
- [x] Record exact metadata, limitations, useful/null findings and next decision
  in R021. Do not start the news markets before reviewing this bounded battery.
  Complete: no new wording sweep/qualification; retain Qwen. Next bounded pass
  is the v1 news feasibility pilot with matched fourteen-slot rule counterparts,
  passive accounting and explicit LLM intent/fill/volume influence. Do not count
  this 48-response synthetic diagnostic as a market A/B/C study.

R019 review checkpoint (user has since resumed): the v1 live
pilot below remains preserved, with diagnostic scope only. Its 20 rounds/two
seeds/two LLMs cannot support long-run market or human-realism conclusions.
Before expanding, balance the next bounded work across:
- [x] Limited market-background sensitivity: MM skew and last-payout valuation
  versus a past-payout average with equivalent information; preserve original
  conditions and examine liquidity/activity as well as mispricing. No tuning
  solely to pass stylized-fact thresholds or manufacture expected effects.
- [x] Minimal fresh one-trait/state checks, including gain/loss context;
  persona bundles and reasoning strings alone cannot establish behavioural bias.
- [x] Passive no-trade performance under the same payout/rate path and both
  wealth marks; equal-resource fourteen-slot rule counterpart for brain effects.
- [ ] Use the small news pilot for decisions/feasibility, then select adequate
  independent confirmation and horizon from variability. Retain A/B/C as an
  explanatory comparison without letting it displace market/behaviour research.
R020 implements the marked accounting/templates and rule sensitivity checks.
R021 completed the live trait diagnostic with contextual/null results; broader
behavioural/brain comparisons remain unverified.
Do not restart qualification or add general infrastructure in place of science.

Completed bounded response to R019 (R020):
- [x] Add selectable past-dividend averaging for fundamentalists; default one
  preserves existing decisions. Only already observed payouts, no future truth.
- [x] Add read-only passive-account evaluation with both wealth marks and a
  clear conditional-price-path interpretation; verify hand-calculated examples.
- [x] Build equal-resource fourteen-slot rule/mock templates; preserve background
  slots, rule parameters and public information. No live API integration change.
- [x] Freeze/run a rule-only 2x2 screen: skew .02/0 x dividend window 1/5,
  seeds 317/628/939, 600 no-news rounds, hidden benchmark, same fourteen slots.
  Report price, dependence, liquidity/activity, inventory and passive-relative
  outcomes together. Keep every case and default; no realism score optimization.
- [x] Prepare a small versioned matched-state trait/gain-loss battery with exact
  messages and repeats, without generation or a profitable-action oracle.
- [x] Verify, preserve source/config/run provenance and update R020. Stop at the
  evidence review; choose any live follow-up from these findings, not blindly.

Completed bounded pass (R018):
- [x] Add explicit announcement visibility independent of economic effect;
  existing events remain public by default. Hidden events may omit a headline.
- [x] Preserve a researcher-only event audit; hidden event labels/effects must
  not enter observations or reflection memory. Keep legacy announced rows in
  events.csv; its benchmark field remains researcher-only, never an agent feed.
- [x] Test config round-tripping, multiple events, timing, cashflows and prompt
  non-disclosure. Demonstrate that explicit fundamental disclosure is a separate
  information channel; keep it OFF in the four-cell information study.
- [x] Freeze a 4-cell rule-only protocol before running: actual permanent mean
  shift (no/yes) x public forecast (no/yes); 3 fresh seeds, same resources and
  exogenous draws, 600 rounds with event at 301. Keep all cases/defaults.
- [x] Verify exact announcement-only negative controls for rules, shared/scaled
  dividend innovations, prefix matching, event audit and financial conservation.
- [x] Preserve all configs, run IDs, source, results and limitations; freeze a
  bounded live-news pilot protocol for a later pass. No live API calls this pass.

- Freeze pilot choices; evaluate fresh scenarios/repetitions.
- Matched headline-only / fundamentals-only / combined / control news experiments.
  Visibility separation and private audit are now implemented and rule-verified
  (R018), superseding the previous proposal here; live effects remain untested.
  Retain the frozen capability run's source/inputs unchanged.
- Preserved v1 proposal (unrun, after fresh trait/state check): implement/freeze the news_live_pilot_proposal_v1 runner
  and exact configs before API work. Eight 20-round A markets, seeds 1441/2882,
  event 11, two LLMs, Qwen qualified 4096-cap profile, 320 planned decisions /
  640 maximum attempts / 8M conservative reservations. See permanent proposal
  for settings, counterbalanced order, metrics, failure rules and limitations.
  No new provider or NVIDIA key is needed. Preserve A/B/C for the later matched
  explanatory study; do not prematurely triple this diagnostic's API work.
- Equal-resource rule/LLM/mixed populations with common exogenous paths, rotated
  assignments, and modest rule-agent tuning on separate pilot scenarios.
- Report decision-level effects, price discovery, normalized performance,
  liquidity, failures, cost, and uncertainty across independent runs.
- Evaluate stylized facts on stable baselines; preserve zero-volume rounds and
  separate event windows. Treat GARCH/Hurst as optional diagnostics.

## Stage 6 - Optional extensions after the core evidence is solid

- Social forum or one policy experiment; choose based on the strongest open
  question, remaining time, and evidence. Retain null and negative findings.
- Defer multi-asset trading, a full LOB, fine-tuning, and large populations unless
  necessary for a concrete question.

## API and comparison decision

Real LLM access is not necessary during mechanical/economic repairs. It becomes
necessary at Stage 4, before selecting or tuning behavioural enhancements based
on apparent model behaviour. Keep the corrected simple mode available so A/B/C
can all be run later with the same model, matched scenarios, and comparable
settings. This avoids paying for a misleading buggy-versus-fixed comparison.

## Verification record

Stage 1 completed on 2026-11-02. Python 3.13.1, numpy 2.1.3, PyYAML 6.0.3.
`python -B -m unittest discover -s tests -v` (from starter_code): 28 tests passed,
including wrappers around all four original smoke tests. The initial sandboxed
attempt was blocked by temporary-directory ACLs; final verification ran outside
the sandbox with mock clients only. No package installation was necessary.

Preserved CLI demo: `starter_code/runs/20261102_010715_dev_mock_d9460de1/`.
60 rounds completed; round-30 news delivered; no negative portfolios or model
failures in this mock run. Its economic assumptions remain legacy, uncalibrated.
Both decision prompt templates were checked against commit 0f80f2c and remain
unchanged. Next coding pass starts at Stage 2; no live API integration is needed
until the diagnostic pilot at Stage 4.

Stage 2 completed on 2026-11-02. All 54 unittest checks pass, including the
Stage-1 suite and the original smoke tests. Preserved 1,000-session rule baseline
and matched permanent-shock diagnostics, plus a 100-session mock demonstration.
The paired rule runs match exactly before round 500, use identical standardized
dividend noise, and maintain cash/share/inventory invariants. Final-100-session
mean prices are 99.775 versus benchmark 100, and 120.022 versus benchmark 120.
These are single-seed engineering checks, not live-LLM or human-realism evidence.
Rule-only plots also show recurring price cycles and return autocorrelation;
investigate those in later baseline calibration rather than claiming realism.

Artifacts: starter_code/runs/stage2_diagnostics_20261102.json and
stage2_source_20261102.zip, plus run IDs recorded in diary R005. The economic
conventions are documented in starter_code/ECONOMIC_MODEL.md. Baseline prompts
now use raw_economics_v2 for accurate time units, payout rules, and small-rate
precision; this common correction is not the factual-summary treatment.
Next pass: Stage 3, selectable A/B/C modes and reproducible call provenance.

Stage 3 completed on 2026-11-02: 76 tests pass, three 30-round matched mock
examples completed (A/B 240 requests; C 280 including 40 reflections). Full
request/decision/outcome logs, source manifests, price/call controls, and safe
budget-stop semantics exist; generic replay/caching remains deferred. The source
and financial baseline were preserved: a fresh rule seed-42 regression reproduces
all six key Stage-2 financial CSVs byte for byte.

The predeclared 12-run screen suggests inventory skew affects predictability and
mispricing, with a turnover trade-off. Changing trend horizons alone had little
effect in these three seeds; no default was selected or altered. All cases and
protocols are saved in starter_code/runs/stage3_checks_20261102.json and companion
PNG/PDF. This is exploratory rule-only evidence; mock A/B/C differences are not
behavioural findings. Live-model access is now useful for the small pilot.
