# Thesis simulation and evidence

Start with the [current thesis argument](thesis/THESIS_ARGUMENT.md),
[results brief](THESIS_RESULTS.md) and [content draft](thesis/THESIS_DRAFT.md).
The [research diary](RESEARCH_DIARY.md) records completed, incomplete and
proposed work. [Offline reproduction](thesis/REPRODUCIBILITY.md) explains the
evidence checks and their limitations.

The simulator is in [starter_code](starter_code/README.md). Comparable A/B/C
conditions remain available. Read the [implemented economic model](starter_code/ECONOMIC_MODEL.md)
before interpreting a result as realistic or comparing studies with different
models, populations or horizons. Department formatting is deferred until last.

The original numbered planning documents are preserved in
[archive/early_proposals](archive/early_proposals/README.md). They describe early
ideas and anticipated experiments; they are not the current specification or
evidence of completed findings.
