# Project working notes

Read `RESEARCH_DIARY.md` at the start of work on this project. It records the
current research direction, findings, open issues, and proposal status.

Maintain that diary after meaningful implementation changes, experiments,
discoveries, or research decisions. Include the date, question, change and
rationale, evidence or run IDs, limitations, and thesis relevance. Preserve
negative and inconclusive results. Distinguish proposed, approved, implemented,
and verified work; never present a proposal as an implemented improvement.
Correct earlier entries explicitly rather than silently rewriting their history.
Routine formatting edits do not need diary entries.

For experiment results, record the code revision (and any uncommitted changes),
config, prompt/persona version, exact model, randomness settings, repetitions,
metrics, and artifact paths when available. Do not invent missing metadata,
reconstruct exact prompts from memory, or call a before/after association causal
without an appropriate controlled comparison. Do not include API keys or secrets.

The user's current priority is substantial, defensible results within the current
semester. The old semester split and prepared P1-P13 prompts are reference
material, not an obligation to implement every feature. Follow the user's latest
scope and decisions. On 2026-11-02 the user approved beneficial modifications
and requested implementation in bounded stages. Follow `WORK_PLAN.tmp.md` when
present, update its completed checks, and preserve the selectable corrected
simple-agent baseline for future component comparisons. Approval does not mean
that unimplemented proposals have already been validated experimentally.

Permanent thesis requirement: retain comparable selectable conditions A
(corrected simple agent with raw observations and recent executed outcomes),
B (A plus factual summaries), and C (B plus reflection). These modes are implemented
and tested offline; live behavioural effects remain unverified. Keep the same economic
rules, public information, personas, and constraints across modes, and preserve
their prompts/versions and matched exogenous scenarios. Live-model evidence and
independent repeats are required for behavioural conclusions; mock differences
only verify software. Do not lose this comparison when the temporary plan goes away.

Latest R029 (2026-11-03): STOPPED20:31 IST, PID8980 exited; no API job active. Linked
phase starter_code/runs/20261103_195320_sequential_next_fd0fc07c runs ONLY
original next seed5209 B/C/A,24 rounds. User "try now" authorizes one explicit
between-seed stopping amendment; C4103 remains22-round partial, not retried or
spliced. All simulator/parent sources/configs/prompts/economics unchanged;
driver runs/sequential_next_20261103.py frozen as driver_source.py. Three
run-specific offline checks pass (existing168 simulator tests unchanged).
Prior150 HTTP/2507774 reservations retained; phase270/3.3M within campaign
810/9.9M. Same Qwen8192/temp.3/reflection0/low and fatal/operational stops.
B5209 complete24; C5209 partial19 after Arjun20 double503; A5209 never started.
Six new reflections completed. Meera20 valid HOLD was delivered but no auction
or executed feedback occurred in that round. New97 HTTP/297056 known tokens/
1642566 reservations/4 unknown usages; B19 server retry and C5 reflection
transport retry recovered, C20 server retry failed. No parse/output/reflection
failure or JSON repair. Cumulative247 HTTP/753060 known tokens/4150340
reservations/6 unknown usages/1 old blocked. Within original810/9.9M.
Read starter_code/runs/sequential_next_analysis_20261103/READOUT.md/report.json.
All14 completed reflection cycles and15 attempt prompts verified, four exact
B/C initial persona pairs; 227 delivered valid choices,226 in cleared rounds.
All frozen simulator/parent/driver/config hashes and accounting pass. New
Meera C forecast buys100 accepted/13 filled; first four limits below actual
clearing prices. Secondary POST-HOC B/C observed horizons22/19 are descriptive,
never substituted for missing24-round C endpoints; mark/wealth signs differ.
Current driver refuses a stopped phase/duplicate seed; no generic resume.
Only four independent markets remain unattempted(A5209 and C/A/B6317). A next
sealed scheduling amendment may attempt those, never retry/splice either C.
At most ONE complete A/B/C scenario remains possible, not two. No financial-
result gating, prompt qualification, automatic C default or NVIDIA key needed.
Original R028 artifacts/readout remain immutable; inspect WORK_PLAN.tmp.md.

Prior R028 (2026-11-03): STOPPED19:11 IST, PID10680 exited;
first live seed4103 ONLY,
study starter_code/runs/20261103_183126_sequential_markets_bb927356. Frozen three
seeds4103/5209/6317,24-round genuine endogenous A/B/C markets/event11; order
ABC/BCA/CAB. Nine zero-API rule companions complete (24 quiet/combined and600
quiet per seed). All168 offline tests pass. This gate attempted only three live
4103 arms (144 decisions+8 reflections); other six live arms remain unrun.
Common NEW profile8192/low/temp.3/reflection0/timeout180, same Qwen/prompts/rules,
memory5/C reflect5, per-arm90 attempts/1.1M reservations (block270/3.3M).
Fatal provider/output/budget stops block; existing logged parse-HOLD/old-diary
fallback flags an operationally affected arm and stops later arms after that run.
No independent-query stop amendment enters endogenous markets. A/B complete24;
C ends22 on Meera round23 HTTP503 plus one retry(also503); all8 reflections done.
140 valid delivered choices,150 HTTP attempts/456004 reported tokens/2507774
reservations/2 unknown usages/1 blocked. Round23 never cleared; no failed or
blocked choice counted as HOLD. No output/parse/reflection failure or JSON repair.
Read starter_code/runs/sequential_analysis_20261103/READOUT.md and report.json.
All8 own-history reflection prompts and both identical initial B/C messages
verified. B Arjun HOLD vs C BUY90@110 already at1, before any reflection;
pre-event stock weights99.62/99.43/96.89% limit news attribution. Partial C
is not a24-round comparison. One later diary apparently disavows an actual
earlier fill after it leaves the five-round window: qualitative caution only.
No C retry/restart/prefix splicing, billing or NVIDIA/model swap. The frozen
runner refuses later seeds after this stopped predecessor; no continuation
implemented. A future sealed amendment may permit only the two already planned
NEW independent seeds, preserving prior failure and all campaign usage. Inspect
WORK_PLAN.tmp.md before API work; do not blindly rerun or alter frozen source.
First gate n=1;24 rounds are not stylized-fact/human validation. Fresh600-round
rules retain ACF1 .157-.251/MM share42.3-47.0%, no default tuned from outcomes.

Prior R025-R027 checkpoint (2026-11-03): ALL108 scheduled fixed-state cases
attempted:107 valid orders,1 actual4096-token reasoning/output failure retained
as missing, not HOLD or resampled. All24 genuine reflections complete. PID12952
and11356 exited; no API job active. Original34 valid cases/diaries/errors were
preserved through two explicit linked phases. R026 stopped at a cap; R027
explicitly amended only independent-batch stopping (record decision output/JSON
failure and next independent case; provider/budget/reflection failures still
stop). Same Qwen/prompts/4096 cap/economics; market error policy unchanged.
162 regression tests plus3 run-specific tail checks pass. Full final readout:
starter_code/runs/component_final_analysis_20261103/READOUT.md and report.json.
Final raw tail: runs/20261103_174525_components_tail_90002a97; driver_source.py
and plan seal the post-failure amendment. All prior phases/analyses remain intact.
Cumulative139 HTTP attempts/424042 reported tokens/1816876 reservations,7 old
unknown usages, within original264/4M.35/36 cells have three valid replies; C's
seed2882/Meera/negative has two valid and one missing. No unattempted slots.
Do not retry that capped case or rerun the whole study to select a better result.

Scientific leads: Arjun/2882 A has silent sells100/80/0 versus positive-news
HOLD/HOLD/HOLD (+60 mean signed-order contrast without a BUY). HOLD can mean
less selling, so buy frequency/headroom alone miss news response. Arjun/1441
HOLDs all27 queries, including nine negative-news cases with192 shares sellable.
Meera/2882 C positive contrasts20/20/30 versus variable A/B, but other states/
news do not establish a uniform upgrade. Reflection adds59907 reported tokens;
no general improvement or market/human-realism benefit is proven. All queries
condition on four reused A-market states; C reflects common A history, not its
own endogenous C trajectory. Preserve source/prompt/phase limitations, missing
outputs and all signs/costs. Never infer full-market profitability from queries.
Next proposed bounded scientific pass is fresh sequential matched markets,
with actual execution, baseline sizing/liquidity, news and both passive marks.
Freeze a common output/failure policy before those runs; no new qualification
sweep, automatic reflection default or NVIDIA/model switch is justified here.

Prior R025 checkpoint (2026-11-03): STOPPED with partial evidence on HTTP503
and its one retry (also503), not model-quality/quota evidence. PID15368 exited;
no API job active. Study starter_code/runs/20261103_023441_news_components_da6bdf79
has34/108 decisions and8/24 actual-history reflections, ALL only repetition1;
no complete three-repeat cell. 49 HTTP attempts/135427 reported tokens/
641213 reservations/7 unknown usages. Five503 retries recovered, sixth failed;
no JSON repairs, resource reductions or impossible accepted limits among34 choices.
158 offline tests pass; only new sim/news_components.py was added, all prior
simulator files unchanged. The conditional positive/negative/no-news x A/B/C
study uses all four designated R024 frames. C reflects actual outcomes1-5/6-10
and shares a pre-news diary within each frame/repeat, not an endogenous C path
or news-retention test. No full A/B/C effect or human-realism result established.
Do not blindly rerun the study. Read runs/component_analysis_20261103/READOUT.md,
report.json and remaining_work.json (74 choices +16 new reflection calls pending).
A future explicit linked continuation must retain49 attempts/641213 reservations,
all34 completed choices and the last block's existing diary; remaining caps
215 attempts/3358787 reservations, same model/prompts. No generic resume code
or automatic continuation is implemented. Do not mix a challenger into this
comparison; NVIDIA remains deferred. Arjun's negative-news HOLD despite feasible
selling in one frame also prevents attributing every null solely to buy headroom.

Prior checkpoint (2026-11-03 audit of 2026-11-02 runs): Stages 1-3 and
live integration are implemented; 150 offline tests pass. User selected
BharatCode student access and qwen-3.8-27b after Gemini failures (R011-R013).
API_KEY in starter_code/.env is scoped to its official HTTPS endpoint. No billing
or silent model substitution. NVIDIA_API_KEY is deferred; do not call NVIDIA or
block core research on that optional challenger.

Common prompt suite is comparable_agents_v2_disclosed_rules (R016). Qwen passed
54/54 objective numeric fields and 30/30 delivered orders in the disclosed-rule
qualification (R017); this is capability evidence, not market realism. R014's
18 probes/six tiny A/B/C markets remain exploratory. Keep Gemini/Lite, old/new
prompts, and different market populations separate; clipping alone is not an
arithmetic error.

R018 separated news visibility from economic effects, with private event audits.
R020 added selectable dividend_window (default 1 unchanged), conditional passive
accounts with both terminal marks, equal-resource fourteen-slot replacements,
and a 12-market background screen. Five-payout averaging raised persistence;
no default was selected. Retain seed-633 no-news drift and sensitivity trade-offs.
R021 completed 48 fresh trait/state replies: risk contrasts positive 10/12,
both reversals in falling contexts; 23 HOLD/1 BUY/0 SELL makes the selling test
inconclusive. Do not tune wording or switch models to manufacture expected bias.

R024 COMPLETE: the existing background job finished 2026-11-02 23:06 IST;
PID22644 exited, no API job active. All 8 rule + 8 live 20-round markets and
24 same-state headline queries completed in the linked study
starter_code/runs/20261102_202946_news_pilot_786a0370, latest phase
delivery_v4_query_first. No rerun is needed after the usage-limit reset.
Cumulative ALL phases: 402 HTTP attempts, 1122587 provider-reported tokens,
4879158 conservative reservations, 10 unknown-usage failures, 1 blocked request.
Seven transport retries recovered on identical messages; no 503 retry was
needed live. Opt-in retry_http_503 shares one extra attempt with transport,
honors safe Retry-After <=60s/default10s; both opt-ins default off. Original
688 attempts/9M reservations ceiling retained; amended phase maxima619/8055022.
Preserve old zero-, nine- and fourteen-round incomplete attempts separately.
Do not splice them into full runs or relabel linked delivery phases as a causal
before/after improvement. Prompts/policy/economics were checked unchanged.

Read starter_code/runs/news_query_first_analysis_20261102/READOUT.md and diary
R024 for final evidence: Meera's within-state news contrast positive in seed1441
but mixed (-50,-20,+40 shares) in seed2882. Arjun HOLD in both stored frames,
but both lack cash for even one executable buy; this is not proof of ignored news.
Combined real-shift/news markets had smaller post-event benchmark gaps in both
seeds, but pre-event states differ and only two short scenarios exist. Large
requested/accepted orders need not fill; equal resources do not standardize
policy order size. Keep all passive-relative gains/losses and both wealth marks.
No stable human-realism, herding, superior-LLM, or confirmed A/B/C effect follows.

Next scientific pass is PROPOSED, not started: opportunity-aware positive/negative
news confirmation, followed by the preserved A/B/C component comparison and
adequate full-market confirmation. Reflection must use actual logged histories;
do not assume raw A forgets all news when its structured window expires, since
prior order reasoning may carry beliefs. Avoid general infrastructure and repeated
qualification without a new failure. Inspect WORK_PLAN.tmp.md before API work.
Student 10M tokens/day is the stated allowance, not a verified remaining balance
or RPM limit. Do not enable billing or silently substitute another model. Preserve the wider
research objective: agent behaviour, market statistics, news/intervention
responses, and fair LLM-versus-rule comparisons. A/B/C is one explanatory study,
not a replacement for that objective. Improve consistency without forcing expected
outcomes. Keep a concise thesis-candidate index; retain raw and negative evidence
without presenting routine engineering checks as headline research results.
