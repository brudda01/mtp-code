# LLM-agent stock exchange — comparable agents and pilot foundation

Small batch-auction simulator with rule-based, mock and compatible live LLM traders. The current
implementation completes the bounded Stages 1-3: execution correctness, checked
economics, two-sided liquidity, selectable A/B/C agents, and pilot provenance.
The bounded BharatCode Qwen live pilot has also completed; results and limits
are recorded in diary R014. General performance and human realism remain unvalidated.
Original planning documents are in the parent directory;
current decisions and evidence are in `../RESEARCH_DIARY.md`.

Read [ECONOMIC_MODEL.md](ECONOMIC_MODEL.md) for the timing, valuation assumptions,
configuration rules, and output meanings. New baselines use bounded independent
dividends and permanent mean shifts. The original `dev_mock.yaml` is labelled
legacy and retains its approximate valuation. This is not yet a validated
financial-market model.

## Quickstart
From `starter_code/`:

```powershell
python -m pip install -r requirements.txt
python -B -m unittest discover -s tests -v
python -B -m sim.engine --config configs/pilot_a_mock.yaml
python -B -m sim.engine --config configs/pilot_b_mock.yaml
python -B -m sim.engine --config configs/pilot_c_mock.yaml
python -B -m sim.engine --config configs/baseline_rules.yaml
python -B -m sim.engine --config configs/diagnostic_shock.yaml
python -B -m sim.metrics runs/<the-new-run-dir>
```

The new regression suite uses standard-library `unittest` and also runs under
pytest. It exercises all four original smoke tests as well as accounting,
allocation, failure-handling, news, and reproducibility regressions. No live API
calls are made by the suite or by the supplied mock config. All dependencies in
`requirements.txt` are not needed just to run the foundation tests: numpy and
PyYAML suffice. Pytest, arch, and tqdm support later/optional workflows.

Every run gets a unique directory. `--output-root <directory>` changes its parent.
`events.csv` records announced news; `event_audit.jsonl` privately records all
scheduled events, including silent economic changes. Both are researcher logs;
only announced headline strings are passed to agents. `cashflows.csv` checks monetary accounting,
`liquidity.csv` records quotes/fills, and `initial_state.csv` saves endowments.
Account logs include cost basis and paid income. `summary.json` identifies the
random-stream scheme, economic model, and prompt version. The saved normalized
configuration can be reloaded; unsupported settings fail before creating outputs.

## Implemented execution rules

- Market buys reserve cash at the full configured upper band, including tax.
  Limits and sell quantities respect available cash and holdings.
- Initial shares use the initial reference price as acquisition cost; an agent
  group may supply `initial_cost` explicitly. Buyer tax enters acquisition cost.
- Tick rounding preserves original limits; bands restrict valid execution prices.
- Better-priced orders fill first. At equal prices, integer pro-rata allocation
  uses largest remainders, with seeded random ties. Remaining symmetric clearing
  price ties choose the lower price after volume and distance to previous close.
- Settlement checks the entire batch before changing accounts. Same-auction
  proceeds cannot finance buys. Tax is recorded separately from trader cash.
- Environment, population, personas, and auction allocation have separate seeded
  streams. Agent count and execution randomness cannot alter the dividend path.
- Malformed replies receive one corrective attempt; persistent failures and
  exhausted client requests become logged HOLDs. Repair attempts are retained.
- Market makers may return one buy and one sell order, with finite cash and a
  hard inventory cap; other agents keep the single-order interface.
- Public news arrives before orders; `announce: false` hides an event's headline
  independently of its dividend effect. Keep `reveal_fundamental: false` for
  learning-from-news experiments. The dividend draw and payouts occur after clearing.
  Interest applies to post-settlement cash, without reinvesting the new dividend.

## Live models and research comparisons

A minimal OpenAI-compatible client is present. A is the corrected simple agent,
B adds factual summaries, and C adds reflection. They are selectable and have
completed diagnostic live runs; general comparative benefits remain unverified. Read
[AGENT_EXPERIMENTS.md](AGENT_EXPERIMENTS.md) for the controls, verified memory,
request limits, cost-estimation limits, and log schema. The Qwen diagnostic is
complete; the next checkpoint is the bounded news pilot documented there.

The bounded primary pilot uses BharatCode student access and `qwen-3.8-27b`.
It reads `BHARATCODE_API_KEY` or the user's `API_KEY` alias from the environment
or `starter_code/.env` (ignored by Git), only for BharatCode's official HTTPS
base URL. Existing Gemini configurations still use `GEMINI_API_KEY`; other
compatible endpoints use `LLM_API_KEY`. Keys never enter experiment files.
Do not place credentials in YAML.

```powershell
python -B -u -m sim.pilot probes
# Inspect the resulting fixed-observation probes before running micro-markets:
python -B -u -m sim.pilot markets --probe-dir runs/<the-qwen-probes-directory>
```

The first phase makes 18 planned probes, capped at 24 attempts. The second
phase makes six four-round micro-market runs with two LLM traders, capped at
12 attempts each. Together they permit at most 96 generation attempts and
700000 byte-based token reservations. Included student tokens have zero marginal
per-token price; subscription costs and remaining daily allowance are not measured.
No billing or paid upgrade is enabled by these commands.
Each invocation creates new attempts; rerunning is another pilot, not a resume.
The Qwen pilot requests temperature 0.3 for decisions, 0 for reflections, low
reasoning effort and a 2048-token output allowance including reasoning. Earlier
Gemini/Lite attempts remain separate. Requests are paced at ten per minute with
a 180-second timeout for queuing/network/generation. These are chosen controls,
not verified provider rate/queue limits. Errors or exhausted output caps stop
the pilot; a truncated response is saved without a same-cap automatic repair.
The probe phase must complete before the market phase, and its results require
inspection. These are diagnostics, not long-run realism or profitability tests.

Every run saves a manifest, source snapshot, personas, and immediate per-request
logs. Decision failures, actual outcomes, provider usage, mock estimates, and
budget stops are distinguishable. A stopped partial decision batch never clears.

## Next bounded stages

The Qwen diagnostic and disclosed-rule capability check are complete. Independent
announcement/economic controls now pass a three-seed, four-cell rule-only check:

```powershell
# Twelve local rule-only markets; no API calls:
python -B -u -m sim.news_controls
```

R020 adds conditional passive-performance evaluation, equal-slot rule/mock
templates and a three-seed background sensitivity screen. Defaults remain
unchanged: the lowest price-gap setting also increased return persistence and
market-maker participation. R021 completed 48 fresh matched-state Qwen responses:
risk effects vary by context; gain/loss cases hardly trade, limiting the selling
test. No failures/repairs/clipping occurred in that diagnostic. The R022 news
pilot and its R023 recovery stopped on delivery errors; their partial evidence
is retained. R024's linked phase subsequently completed all eight live markets,
eight rule controls and 24 same-state queries (audited 2026-11-03). No R024 job is
active; no R024 rerun is needed after a usage reset. There are 168 passing offline
tests. Transport/temporary-503 retry is opt-in, separately logged/budgeted, and
limited to one shared extra attempt; both options default off. Seven transport
retries recovered live; the 503 path was only tested offline in this study.
The [final pilot readout](runs/news_query_first_analysis_20261102/READOUT.md)
retains mixed headline effects, constrained HOLDs, unfilled orders, pre-event
market differences and both passive-return marks. These are exploratory results,
not validated human realism or a confirmed A/B/C improvement. See
[AGENT_EXPERIMENTS.md](AGENT_EXPERIMENTS.md) for commands and limitations. The broader
programme retains personality, news, market dynamics, and brain-type comparisons.
R025-R027 complete the controlled positive/negative/no-news A/B/C query grid:
108 scheduled cases resolved,107 valid orders, one capped output retained as
missing, and24 genuine reflections. No failed case was resampled or given a
larger token budget. The [final component readout](runs/component_final_analysis_20261103/READOUT.md)
shows why HOLD can mean reduced selling after good news, and why reflection is
not a uniform upgrade across these states. These are conditional reused-state
queries, not full-market/performance or human-realism validation. Earlier partial
artifacts remain intact. No component-query job or unattempted case remains; do not rerun
the failed case to select a response. Three additional offline research-tail
checks verify the explicit independent-case stop amendment (market policy unchanged).

R028 attempted fresh sequential A/B/C markets from a common start, with genuine
own-execution reflections and nine completed zero-API rule companions. The first
seed stopped on HTTP503 and its one retry: A/B finished24 rounds; C is preserved
at22 with all8 reflections. No API job remains; no C restart or prefix splicing.
The [sequential gate readout](runs/sequential_analysis_20261103/READOUT.md) shows
actual order-to-fill filtering, pre-news exposure, both wealth marks and broader
baseline/MM concerns. Identical B/C first prompts already produced different
actions before reflection. One diary appears to confuse a recent window with
total history; it is a qualitative caution, not a demonstrated performance harm.
The other two preselected live seeds remain unrun; a linked continuation would
need an explicit stopping amendment, preserving the failed arm and prior usage.
This is partial exploratory evidence, not a confirmed component/realism upgrade.

R029 attempted the next preselected seed with unchanged scientific settings:
B finished24; C stopped19 on double503; A was not started. No API job remains.
The [linked readout](runs/sequential_next_analysis_20261103/READOUT.md) retains
the original partials and missing full-horizon comparisons. It also labels
post-hoc comparisons over jointly observed22/19-round windows separately.
One useful example: C's100 accepted forecast buys yield13 fills because its
first four limits fall below actual clearing prices. Weak executed buying
therefore need not mean ignored news. No complete A/B/C scenario or uniform
reflection benefit is established; four preplanned independent arms remain
unattempted. Neither failed C path may be rerun or spliced to select an outcome.

Resume, general replay/caching, a forum, policy experiments,
and a continuous order book remain later work. The prepared P1-P13 sequence is
reference material; follow the revised temporary plan and research diary.
