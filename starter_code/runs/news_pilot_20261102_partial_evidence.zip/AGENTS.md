# Project working notes

Read `RESEARCH_DIARY.md` at the start of work on this project. It records the
current research direction, findings, open issues, and proposal status.

Maintain that diary after meaningful implementation changes, experiments,
discoveries, or research decisions. Include the date, question, change and
rationale, evidence or run IDs, limitations, and thesis relevance. Preserve
negative and inconclusive results. Distinguish proposed, approved, implemented,
and verified work; never present a proposal as an implemented improvement.
Correct earlier entries explicitly rather than silently rewriting their history.
Routine formatting edits do not need diary entries.

For experiment results, record the code revision (and any uncommitted changes),
config, prompt/persona version, exact model, randomness settings, repetitions,
metrics, and artifact paths when available. Do not invent missing metadata,
reconstruct exact prompts from memory, or call a before/after association causal
without an appropriate controlled comparison. Do not include API keys or secrets.

The user's current priority is substantial, defensible results within the current
semester. The old semester split and prepared P1-P13 prompts are reference
material, not an obligation to implement every feature. Follow the user's latest
scope and decisions. On 2026-11-02 the user approved beneficial modifications
and requested implementation in bounded stages. Follow `WORK_PLAN.tmp.md` when
present, update its completed checks, and preserve the selectable corrected
simple-agent baseline for future component comparisons. Approval does not mean
that unimplemented proposals have already been validated experimentally.

Permanent thesis requirement: retain comparable selectable conditions A
(corrected simple agent with raw observations and recent executed outcomes),
B (A plus factual summaries), and C (B plus reflection). These modes are implemented
and tested offline; live behavioural effects remain unverified. Keep the same economic
rules, public information, personas, and constraints across modes, and preserve
their prompts/versions and matched exogenous scenarios. Live-model evidence and
independent repeats are required for behavioural conclusions; mock differences
only verify software. Do not lose this comparison when the temporary plan goes away.

Current checkpoint (2026-11-02): Stages 1-3 and the live-pilot integration are
implemented. User explicitly switched to BharatCode student access and
qwen-3.8-27b after Gemini failures (R011-R013). API_KEY in starter_code/.env is
scoped to BharatCode's official HTTPS endpoint. The Qwen integration passes
128 offline tests; 18 earlier live probes and six matched micro-markets completed (R014).
These are exploratory diagnostics, not confirmed A/B/C performance effects.
The common disclosure is now implemented as prompt suite v2 (R016); auction and
settlement did not change. Qwen completed the 42-check capability battery through
a documented timeout/tail continuation (R017): 54/54 objective fields and 30/30
delivered orders passed. User will provide NVIDIA_API_KEY later; do not call
NVIDIA yet or block core research on that optional challenger. News visibility
and economic effects are now independent, with private event provenance (R018).
Twelve rule-only four-cell markets (3 seeds x 600 rounds) verified the controls;
seed-633 price drift is retained, not tuned away. R022's live news pilot is
partially run, not complete. User resumed after R019. R020 implements conditional passive-account
evaluation, selectable dividend_window (default 1 unchanged), equal-resource
fourteen-slot rule/mock templates, and a 12-market background screen. Averaging
five payouts increased persistence; no defaults were selected/changed. Fresh
matched_trait_states_v1 completed in R021: run
20261102_195440_behaviour_qwen_ee95d92d, 48 requests/40352 reported tokens,
no errors/repairs/clipping. High-risk exposure contrasts positive 10/12, with
both reversals in falling contexts. Gain/loss replies HOLD 23/BUY 1/SELL 0:
zero sell interaction is inconclusive, not evidence of absent loss aversion.
PID 11360 exited; no API job remains. Do not rerun completed phases as resumes.
139 offline tests pass. R022 and ONE explicit continuation both stopped on
URLError/no HTTP status. Both PIDs 26812/14112 exited; NO API JOB is running.
Study starter_code/runs/20261102_202946_news_pilot_786a0370 has all 8 rule arms
but only 3/8 live arms complete (seed 1441 control/headline-only/fundamentals-only).
Combined/1441 has 9 cleared rounds; seed 2882 live arms and all 24 same-state
queries are unrun. Total 142 attempts/402899 reported tokens/2 unknown-usage
failures; all failed/unexecuted decisions remain recorded. Do not rerun blindly.
Next proposal is minimal opt-in logged/budgeted transport retries, default zero,
with safe reason diagnostics and offline verification before further generation.
It is NOT implemented. Then recover unfinished arms with prior budgets deducted;
no automatic extra continuation or model swap. Version v2 preserves v1's
8 twenty-round Qwen markets and adds 8 equal-slot rule arms plus 24 same-state
event queries, with separate budget (overall max 688 attempts/9M reservations).
Inspect both phase summaries and runs/news_analysis_20261102 before API work.
News effect is unconfirmed: pre-event live states differ; quantity-policy scaling
and target participation are additional leads, not intrinsic LLM superiority.
No additional qualification/wording sweep. News results are not yet established.
Independent
confirmation and fair equal-slot live brain comparisons remain pending. Do not
claim human realism or isolate persona traits from bundled Meera/Arjun profiles.
Avoid general infrastructure or requalification without a specific new failure.
Preserve later B/C and use both passive-relative wealth marks.
Inspect WORK_PLAN.tmp.md before restarting API work. Do not repeat old pilots
or pool the 20-rule diagnostic with the proposed 14-trader mixed population.
Do not mix old/new prompt results or mistake the capability battery for a full
A/B/C market study. Clipping alone is not an arithmetic error.
Consult WORK_PLAN.tmp.md before resuming. Keep Gemini/Lite observations separate from Qwen.
Student 10M tokens/day is the stated allowance, not a verified remaining balance
or RPM limit. Do not enable billing or silently substitute another model. Preserve the wider
research objective: agent behaviour, market statistics, news/intervention
responses, and fair LLM-versus-rule comparisons. A/B/C is one explanatory study,
not a replacement for that objective. Improve consistency without forcing expected
outcomes. Keep a concise thesis-candidate index; retain raw and negative evidence
without presenting routine engineering checks as headline research results.
