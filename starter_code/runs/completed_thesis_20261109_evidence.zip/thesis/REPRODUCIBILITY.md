# Reproducing the reported evidence offline

**Completed R058 integration:** both25-session DeepSeek market paths are now
available. [The current replication guide](DEEPSEEK_REPLICATION.md) provides
saved-evidence commands and distinguishes488actual seed31991 market-chain HTTP
attempts from383final-summary records. Older statements that no seed31991 path
exists are historical. The old recorded-replay coverage below is unchanged;
the new checks reconstruct inputs/accounts and verify existing prefix states,
not a claim of independent-machine replay.

**Permanent collection freeze:** only saved-evidence checks and credential-free,
network-blocked exact reproduction are allowed. Do not run historical live
launch commands or new scientific simulations. The final seed31991 has no
market path to replay. See [closure and offline commands](FINAL_COLLECTION.md).

**R055/R056:** The [extension guide](FINAL_EXTENSIONS.md) records source freezes,
controls, provider settings and offline analysis commands. R055 reconstructs
18 original factual paths before36 dynamic fixed-tape sensitivities; its18
removal executions contain3distinct financial paths. R056 is separately recorded
fresh provider evidence. Offline reconstruction and analysis do not turn saved
replies or repeated removal paths into independent model samples.

**R054 conditional auction influence:** The [study guide](ORDER_INFLUENCE.md)
provides offline tests and a new-output-only analysis command. The frozen
study contains216 factual auction states and432 isolated counterfactual clears;
the independent audit checks432 candidate-price/volume outcomes and6,048
cash/share settlements. These are additional mechanical calculations on saved
orders, not fresh LLM draws or adapted market trajectories. The original R043
provider requests are not repeated or recounted as fresh usage.

**R053 saved-evidence synthesis:** From `starter_code`,run
`python -B -m research.evidence_synthesis --output runs/evidence_reader_01` into
a new directory. This checks terminal accounts/marks for560account endpoints
across40existingR041/R047paths and regenerates the background evidence ledger.
It neither runs markets nor calls a model. The [argument guide](THESIS_ARGUMENT.md)
explains the identities and the transparent selection of one illustration.

**R052 partial reflection comparison:** The [design and assessment](FEEDBACK_VALIDATION_PROTOCOL.md)
links all saved messages,8delivered replies,2HTTP503attempts and40missing slots.
From `starter_code`,run `python -B -m research.feedback_validation_review --study runs/feedback_validation_20261107`
to verify frozen hashes and exact saved messages/settings. This does not call
a provider or produce fresh reflections. The stopped campaign cannot be resumed
with its single-use driver. Full-model efficacy remains unresolved.

**R050/R051 addition (2026-11-07):** This original guide remains the route for
the earlier65recorded paths. The [follow-up guide](FEEDBACK_AND_BACKGROUND_REVIEW.md)
adds retrospective feedback checks and the16fresh rule-market sensitivity.
Its separate frozen-source replay reproduced16paths/112financial CSVs locally;
these are not extra LLM samples. Source/defaults for the earlier studies remain
unchanged. Independent-reader/machine reproduction is still unperformed.

R049,2026-11-05. No API key or live endpoint is required for these operations.
They verify saved evidence and replay original replies; they do not generate
new model samples or establish independent-machine/human-market replication.

## Required materials

Keep the repository and original evidence tree at the indexed relative paths.
The [writing sources](sources.json) pins reports and thirteen experimental
archives; the [study inventory](appendix/STUDY_INVENTORY.md) maps their roles.
The writing ZIP is a manuscript/input snapshot and does not replace those
archives or the underlying study directories.

The recorded replay environment was Python3.13.1,numpy2.1.3,PyYAML6.0.3.
Exact records are in
[environment.json](../starter_code/runs/examiner_audit_20261105_v2/environment.json)
and [requirements-replay.txt](../starter_code/runs/examiner_audit_20261105_v2/requirements-replay.txt).
Use a suitable environment with those dependencies already installed. Installing
dependencies is a separate setup operation; the following replay blocks network
in its workers. The plotting/full development requirements are not necessary
for this recorded-output check. Compatibility with other versions has not been
established.

## Check claims and provenance first

From the repository root:

```text
python thesis/verify_writing.py
```

This checks draft tables against preserved reports, source/archive hashes,
bibliography records, exact selected prompts and local links. It writes
thesis/checks.json and reads prior replay receipts. It does not rerun the
simulator or contact a model. An absent or changed artifact is a reason to
restore the indexed evidence, not to generate replacement live data.

## Regenerate recorded financial paths

Use a new output-directory name each time, from the repository root:

```text
python thesis/reproduce_saved.py --output starter_code/runs/offline_reader_reproduction_01
```

The wrapper refuses an existing output directory and confines new outputs to
starter_code/runs. It invokes the existing isolated replay drivers and extracts
the frozen R047 source into a new directory with hash/path checks. Saved
messages/settings must match each request before a recorded reply is returned.
Worker socket calls are blocked, and exported API-key environment variables
are removed from the subprocess environment. Nothing starts a live campaign.

Expected coverage is42earlier paths/294financial CSVs plus23R047paths/161CSVs,
all byte-identical to their originals. The earlier replay explicitly records
the original R043 missing-helper import failure before supplementing only the
file from the previously sealed R041 source. That is a documented dependency
repair, not a silently changed original archive.

One completed R047 B continuation is intentionally not replayed because its
recovered error attempt needs exception-aware playback that the original
worker lacks. Its run and reason appear in common_prefix_report.json and
summary.json. A successful wrapper result therefore means the declared65-path
coverage and one explicit exclusion; it does not claim all66live/rule paths
have been replayed. The original raw continuation remains preserved.

New outputs include summary.json,per-stage stdout/stderr,isolated source files
and regenerated financial files. Failures retain a failed summary and logs.
No existing study,old archive or failed scientific outcome is overwritten.

## Interpret the reproduction correctly

Replay log usage fields inherited from original replies are historical metadata.
Do not add them to campaign costs or count cached prefixes as fresh choices.
The successful original campaigns and their raw reports remain the source of
behavioural evidence. Fresh provider draws could differ despite matching
settings; the model backend is not pinned or seeded.

An independent reader should record their machine,interpreter/dependencies,
selected output directory and any mismatch before calling this independently
reproduced. The project's local check alone is not that independent exercise.
No command here establishes empirical calibration or human-market realism.

## Local execution of this guide

The command was exercised in R049 with output
starter_code/runs/manuscript_reproduction_20261105. Its
[receipt](../starter_code/runs/manuscript_reproduction_20261105/summary.json)
records65verified paths,455byte-identical financial CSVs,zero worker network
attempts and the same explicit exclusion. This is a new local replay of old
evidence,not65new scientific markets or an independent reader's reproduction.
