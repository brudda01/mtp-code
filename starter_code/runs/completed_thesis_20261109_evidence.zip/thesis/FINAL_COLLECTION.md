# Final seed attempt and permanent collection closure

**Current final result (2026-11-09):** both DeepSeek seeds30841/31991 now
complete25sessions and150decisions each. [Completed replication](DEEPSEEK_REPLICATION.md)
reports all endpoints, means, Qwen context and the full continuation ledger.
Earlier partial-collection statements below are historical. Collection is closed;
the substantive draft is finalized, with institutional formatting deferred.

R057 closure of the R056 replication request, 2026-11-08. The user requested
seed31991, six DeepSeek traders, Mode B and25 sessions, followed by a permanent
data-collection freeze. **The second market path was not obtained.**

| Seed | Status | Cleared rounds | Delivered decisions | Mean reference gap |
|---|---|---:|---:|---:|
| 30841 | Completed | 25/25 | 150/150 | 16.06% |
| 31991 | Stopped: HTTP 429 | 0/25 | 1/150 | Missing |

The unchanged completed seed is described in [FINAL_EXTENSIONS.md](FINAL_EXTENSIONS.md).
No two-seed mean, paired treatment effect, stability comparison or general
replication claim follows. Even two completed seeds would only have supplied
two scenarios under matched settings, not a matched DeepSeek–Qwen comparison.

## Matched design and disclosed amendment

The original seed31991 configuration differs from seed30841 only in seed and
run name. Model `deepseek/deepseek-v4.1-flash`, endpoint, temperature0.3,
thinking disabled, output2048, six personas, Mode B five-outcome history,
cap10, eight rule accounts, initial accounts and economic rules are unchanged.
Provider draws remain unseeded. Both final launchers import the original frozen
R056 worker; no original simulation or provider-adapter source was edited.

The [first protocol](../starter_code/runs/goedel_second_seed_20261108/protocol.json)
was sealed as SHA256
`0fff4c7c1100c2afddeed15bb6288ddfa0d769082ed6cb021810e3d169d7abc0`.
The first request received HTTP429 with a two-second Retry-After hint. It
delivered no reply and cleared no auction; the worker stopped. This initial
attempt, including its no-resume receipt, remains intact.

One [explicit transport amendment](../starter_code/runs/goedel_second_seed_retry_20261108/protocol.json)
then superseded the original no-restart rule before any behavioral output had
been observed. This is a disclosed protocol deviation, not an unchanged
execution of the first protocol. The new single-use root starts from the same
initial state; it neither resumes nor splices a market history. Its SHA256 is
`53bb415a24341208bcae6ff84580f288451a793b24183754fd7f6e09a92c1583`.
Remaining budgets fell to179 HTTP attempts and2,994,480 reserved tokens,
deducting the initial request and5,520-token reservation from the original
combined180-attempt/3million-token ceilings. All behavioral settings remain
unchanged. The retry began more than the requested two seconds later.

The amended attempt delivered one valid Meera reply, then also received HTTP429.
It stopped at23:37:34IST before the first auction. No further retry, resampling,
model switch or missing-slot completion followed. The reason for the provider's
429 beyond throttling is not established by the saved metadata; daily quota,
account restrictions and provider load must not be asserted as diagnoses.

## Accounting, missingness and checks

| Attempt | HTTP attempts | Delivered replies | Cleared rounds | Known tokens | Reserved tokens | Unknown-usage errors |
|---|---:|---:|---:|---:|---:|---:|
| Original seed31991 | 1 | 0 | 0 | 0 | 5,520 | 1 |
| Amended seed31991 | 2 | 1 | 0 | 803 | 11,072 | 1 |
| Combined seed31991 | 3 | 1 | 0 | 803 | 16,592 | 2 |

Seven additional blocked actor requests in the worker logs were local blocks,
not provider HTTP attempts. The two error attempts have unknown actual token
usage;803 is a known subtotal, not complete all-attempt usage. Across the
completed seed and final attempted seed, totals are153 HTTP attempts,151 valid
replies,370,787 known tokens and1,624,094 reservations. Only150 replies belong
to an executed market; the extra reply is not an executed trade or outcome.

The [saved-evidence analysis](../starter_code/runs/final_collection_analysis_20261108/report.json)
verifies both stopped roots, exact configuration differences, all six personas
and all14 initial accounts against seed30841. The one delivered system/user
pair was reconstructed exactly from its actual opening observation and empty
history. Both attempts have empty price, accepted-order, trade, closing-state
and cashflow tables. All second-seed market metrics and two-seed summaries are
JSON null and displayed as Missing. The initialization price100 is not a
terminal market price; zero cleared rounds do not imply zero volatility,
zero return, perfect stability or zero maker-boundary frequency.

Strict absolute cash conservation at1e-7 and exact shares remained enabled.
No seed31991 settlement occurred, so there are **zero audited account-rounds**
for that seed, not new positive conservation evidence. The original completed
seed's350 audited account-rounds and150 exact prompt pairs remain unchanged.
Five offline launcher tests passed before collection: a full150-reply mock
checks matching initial accounts/personas, alongside configuration, budget and
freeze-guard checks. Mock replies are software tests, never behavioral data.

Prior writing is preserved under
[history/r056_before_second_seed](history/r056_before_second_seed/snapshot_manifest.json).
Both failed-attempt roots, the raw reply, exact requests, sanitized HTTP metadata,
frozen source ZIPs, preparation and output manifests remain available. Older
Qwen archives, R055 and the completed R056 seed are unchanged.

## Permanent freeze and offline verification

The [collection policy](../DATA_COLLECTION_FROZEN.md) and
[machine-readable marker](../DATA_COLLECTION_FROZEN.json) close collection
permanently. Both final launchers reject preparation/execution when the marker
exists. Historical frozen drivers are unchanged; the marker is not a global
operating-system network block. No live job or restart is scheduled.

From the repository root, these commands only inspect saved evidence:

```powershell
python -B thesis/verify_final_collection.py
python -B thesis/verify_writing.py
```

The numerical analysis can be reproduced into a new output directory from
`starter_code`, without creating market paths or contacting a provider:

```powershell
python -B -m research.analyze_final_collection --output runs/final_collection_offline_review_NEW
```

No seed31991 market replay is possible because no auction cleared. The next
work is saved-evidence interpretation and writing, with formatting last.
