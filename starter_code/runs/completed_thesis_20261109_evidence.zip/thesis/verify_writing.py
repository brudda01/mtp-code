"""Check the writing against preserved evidence;stdlib only,no model/network use.

Run: python thesis/verify_writing.py
Writes thesis/checks.json. It reads existing replay receipts,not fresh replays.
External experimental evidence must be present at sources.json's relative paths.
"""
import hashlib
import json
from pathlib import Path
import re
from urllib.parse import unquote


HERE = Path(__file__).resolve().parent
REPO = HERE.parent


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check():
    sources = read(HERE / "sources.json")
    for name, expected in sources["local_sha256"].items():
        assert digest(REPO / name) == expected, name
    for name, expected in sources["prior_archives"].items():
        assert digest(REPO / "starter_code/runs" / name) == expected, name
    for name, expected in sources.get("previous_writing_archives", {}).items():
        assert digest(REPO / name) == expected, name
    baseline = read(REPO / "starter_code/runs/thesis_synthesis_20261105/start_state.json")
    # The original checkpoint uses repository-relative names.
    for name, expected in baseline["sha256"].items():
        assert digest(REPO / name) == expected, name
    root = REPO / "starter_code/runs/20261105_041035_common_prefix_ca10f93d"
    protocol = read(root / "protocol.json")
    for name, expected in protocol["source_sha256"].items():
        assert digest(REPO / "starter_code" / name) == expected, name

    draft = (HERE / "THESIS_DRAFT.md").read_text(encoding="utf-8")
    previous = (HERE / "history/r046_before_common_prefix/THESIS_DRAFT.md").read_text(encoding="utf-8")
    assert all(row in draft for row in previous.splitlines() if row.startswith("|")), "Old numerical rows changed"
    report = read(REPO / "starter_code/runs/common_prefix_analysis_20261105/report.json")
    assert len(report["arms"]) == 24 and all(a["full_clean"] for a in report["arms"])
    contrasts = report["prefix_contrasts"]
    gap_section = draft.split("### 5.4", 1)[1]
    gap_rows = re.findall(r"^\| (\d+/\d+) \| ([+-]?[\d.]+) \| ([+-]?[\d.]+) \| ([+-]?[\d.]+) \|$", gap_section, re.M)
    assert len(gap_rows) == 6
    for row, item in zip(gap_rows, contrasts):
        assert row[0] == f"{item['seed']}/{item['source_repetition']}"
        expected = [item["Cmean_minus_Bmean_gap"]] + [item["same_mode"][m]["gap_branch1_minus_branch2"] for m in "BC"]
        assert all(abs(float(given) - actual * 100) <= 0.000051 for given, actual in zip(row[1:], expected))
    return_rows = re.findall(r"^\| (\d+/\d+) \| ([+-]?[\d.]+) / ([+-]?[\d.]+) \| ([+-]?[\d.]+) / ([+-]?[\d.]+) \|$", gap_section, re.M)
    assert len(return_rows) == 6
    for row, item in zip(return_rows, contrasts):
        assert row[0] == f"{item['seed']}/{item['source_repetition']}"
        expected = [item["Cmean_minus_Bmean_target_excess"][a][mark] for a in ("llm_012", "llm_013") for mark in ("auction", "regime_benchmark")]
        assert all(abs(float(given) - actual * 100) <= 0.000051 for given, actual in zip(row[1:], expected))
    totals = {m: sum(a["usage"]["provider_reported_tokens"] for a in report["arms"] if a["mode"] == m) for m in "BC"}
    assert totals == {"B": 553704, "C": 695560}
    for value in (*totals.values(), totals["C"] - totals["B"], report["summary"]["usage"]["reserved_tokens"]):
        assert f"{value:,}" in gap_section
    assert round(100 * (totals["C"] / totals["B"] - 1), 2) == 25.62
    assert report["summary"]["usage"]["unknown_usage_requests"] == 1
    for seed in report["within_seed_two_prefix_means"]:
        assert f"{100 * seed['Cmean_minus_Bmean_gap']:+.4f}" in gap_section
    gaps = [c["Cmean_minus_Bmean_gap"] for c in contrasts]
    assert [sum(v < -1e-12 for v in gaps), sum(v > 1e-12 for v in gaps), sum(abs(v) <= 1e-12 for v in gaps)] == [2, 1, 3]
    assert all(max(abs(c["same_mode"][m]["gap_branch1_minus_branch2"]) for m in "BC") >= abs(c["Cmean_minus_Bmean_gap"]) - 1e-12 for c in contrasts)

    replay = read(REPO / "starter_code/runs/common_prefix_analysis_20261105/replay_report.json")
    assert replay["verified_clean_paths"] == 23 and len(replay["not_replayed"]) == 1 and replay["network_attempts"] == 0
    assert sum(len(r["financial_files"]) for r in replay["records"]) == 161
    assert all(all(r["financial_files"].values()) for r in replay["records"])
    old = read(REPO / "starter_code/runs/examiner_audit_20261105_v2/replay_report.json")
    old_markets = [market for study in old["studies"] for market in study.get("supplemented_result", study["original_bundle_result"])["markets"]]
    assert len(old_markets) == 42
    assert all(all(m["exact_financial_files"].values()) for m in old_markets)

    appendix = read(HERE / "appendix/manifest.json")
    for name, expected in appendix["files"].items():
        assert digest(HERE / "appendix" / name) == expected, name
    for name, expected in appendix["source_files"].items():
        assert digest(REPO / name) == expected, name
    selections = read(HERE / "appendix/selected_prompts.json")["selections"]
    for item in selections:
        records = [json.loads(line) for line in (REPO / item["source"]).read_text(encoding="utf-8").splitlines()]
        matches = [r for r in records if r.get("record_type") == "model_call" and r.get("call_type") == item["kind"] and r.get("round") == item["round"] and r.get("agent_id") == item["agent_id"]]
        assert len(matches) == 1 and matches[0]["messages"] == item["messages"]
    first = {s["mode"]: s["messages"] for s in selections if s["kind"] == "decision" and s["round"] == 1}
    assert first["B"] == first["C"]
    bibliography = (HERE / "references.bib").read_text(encoding="utf-8")
    keys = re.findall(r"@\w+\{([^,]+),", bibliography)
    lit = read(HERE / "literature_sources.json")
    assert len(keys) == len(set(keys)) == 14
    assert set(keys) == {s["key"] for s in lit["sources"]}
    for item in lit["sources"]:
        assert item["primary_url"] in bibliography

    links = 0
    docs = [p for p in HERE.rglob("*.md") if "history" not in p.relative_to(HERE).parts]
    docs.append(REPO / "THESIS_RESULTS.md")
    for doc in docs:
        for target in re.findall(r"\[[^\]]*\]\(([^)]+)\)", doc.read_text(encoding="utf-8")):
            if target.startswith(("http:", "https:", "#", "mailto:")):
                continue
            path = unquote(target.split("#", 1)[0].strip("<>"))
            assert (doc.parent / path).exists(), (str(doc), path)
            links += 1
    history = HERE / "history/r046_before_common_prefix"
    for name, expected in read(history / "snapshot_manifest.json")["files"].items():
        assert digest(history / name) == expected, name
    review_history = HERE / "history/r048_before_manuscript_review"
    for name, expected in read(review_history / "snapshot_manifest.json")["files"].items():
        assert digest(review_history / name) == expected, name
    validated = sources.get("prior_saved_output_reproduction_validation")
    if validated:
        validation = read(REPO / validated)
        assert validation["status"] == "passed" and validation["new_api_requests"] == 0
        assert validation["earlier"]["paths"] == 42 and validation["common_prefix"]["paths"] == 23
        assert validation["earlier"]["network_attempts"] == validation["common_prefix"]["network_attempts"] == 0
        assert len(validation["common_prefix"]["explicit_exclusions"]) == 1
    # R050/R051 additions are separate from the original numerical cohorts.
    followup_root = REPO / "starter_code/runs/background_diversity_20261106"
    followup = read(followup_root / "report.json")
    followup_protocol = read(followup_root / "protocol.json")
    assert digest(followup_root / "protocol.json") == followup["protocol_sha256"]
    for name, expected in followup_protocol["source_sha256"].items():
        assert digest(REPO / "starter_code" / name) == expected, name
    followup_section = draft.split("### 5.6", 1)[1].split("## 6.", 1)[0]
    for item in followup["contrasts"]:
        a, b = item["no_skew_minus_skew"]["False"], item["no_skew_minus_skew"]["True"]
        row = (f"| {item['seed']} | {a['acf_returns_lag1']:+.6f} | {b['acf_returns_lag1']:+.6f} | "
               f"{item['interaction']['acf_returns_lag1']:+.6f} | {100*a['mm_boundary_fraction']:+.3f} | {100*b['mm_boundary_fraction']:+.3f} |")
        assert row in followup_section, row
    assert followup["summary"]["completed"] == 16 and followup["summary"]["network_attempts"] == 0
    audit = read(REPO / "starter_code/runs/feedback_audit_20261106/report.json")
    review = read(REPO / "starter_code/runs/feedback_audit_20261106/reflection_review.json")
    for item in audit["distinct_paths"]:
        prefix = item["prefix"].removeprefix("s").replace("_source", "/")
        row = "| " + " | ".join([prefix] + [str(item[k]) for k in ("requested", "accepted", "fills", "accounts", "price")]) + " |"
        assert row in draft
    assert len(review["annotations"]) == 48
    assert sum(x["category"] == "temporal_misattribution" for x in review["annotations"]) == 5
    assert sum(x["category"] == "unsupported_fill_guarantee" for x in review["annotations"]) == 2
    arithmetic = read(REPO / "starter_code/runs/feedback_audit_20261106/verification.json")
    assert arithmetic["status"] == "passed" and arithmetic["account_rounds_independently_reconstructed"] == 134400
    rule_replay = read(REPO / "starter_code/runs/diversity_replay_20261107/receipt.json")
    assert rule_replay["status"] == "passed" and rule_replay["verified_paths"] == 16
    assert rule_replay["byte_identical_financial_files"] == 112 and rule_replay["network_attempts"] == 0
    assert all(all(r["files"].values()) for r in rule_replay["records"])
    before = HERE / "history/r049_before_feedback_review"
    for name, expected in read(before / "snapshot_manifest.json")["files"].items():
        assert digest(before / name) == expected
    validation_root = REPO / "starter_code/runs/feedback_validation_20261107"
    validation_protocol = read(validation_root / "protocol.json")
    assert digest(validation_root / "protocol.json") == read(validation_root / "preparation.json")["protocol_sha256"]
    for name, expected in {**validation_protocol["source_sha256"], **validation_protocol["inputs_sha256"]}.items():
        assert digest(REPO / "starter_code" / name) == expected, name
    partial = read(validation_root / "summary.json")
    assert partial["status"] == "stopped" and partial["delivered"] == 8 and len(partial["missing_slots"]) == 40
    assert partial["usage"]["requests_made"] == 10 and partial["usage"]["unknown_usage_requests"] == 2
    assert partial["usage"]["provider_reported_tokens"] == 26788
    delivered = read(validation_root / "results.json")
    assert all(r["case"].startswith("s22853_") and r["repetition"] == 1 for r in delivered)
    annotations = read(REPO / "starter_code/runs/feedback_validation_review_20261107/annotations.json")
    assert annotations["status"] == "reviewed" and len(annotations["annotations"]) == 8
    assert all(a[k] == "absent" for a in annotations["annotations"] for k in ("raw_temporal", "diary_temporal", "raw_guarantee", "diary_guarantee"))
    result = read(REPO / "starter_code/runs/feedback_validation_analysis_20261107_v2/report.json")
    assert result["annotation_sha256"] == digest(REPO / "starter_code/runs/feedback_validation_review_20261107/annotations.json")
    assert all(c[f]["raw_temporal"] is None for c in result["contexts"] for f in ("original", "timed") if not c[f]["delivered"])
    assert "eight of forty-eight" in draft and "26,788" in draft and "23971/2, prevent an improvement or equivalence conclusion" in draft
    history52 = HERE / "history/r051_before_feedback_validation"
    for name, expected in read(history52 / "snapshot_manifest.json")["files"].items():
        assert digest(history52 / name) == expected
    synthesis = read(REPO / "starter_code/runs/evidence_synthesis_20261107/report.json")
    for name, expected in synthesis["inputs_sha256"].items():
        assert digest(REPO / "starter_code" / name) == expected, name
    assert len(synthesis["account_identity_checks"]) == 560 and len(synthesis["aggregate_identity_checks"]) == 40
    assert synthesis["max_identity_residual"] < 1e-10 and synthesis["max_aggregate_excess_residual"] < 1e-7
    assert len(synthesis["background_pairs"]) == 12 and len({r["seed"] for r in synthesis["background_pairs"]}) == 8
    assert all(r["delta_acf1"] < 0 and r["delta_boundary_pp"] > 0 for r in synthesis["background_pairs"])
    assert synthesis["price_account_collapse"]["cross_mode"]["account_difference_with_identical_prices"] == 11
    illustration = synthesis["illustration"]
    assert illustration["terminal_shares"] - illustration["opening_shares"] == 30
    assert abs(illustration["mark_difference_pp"] - .21) < 1e-12
    assert all(s in draft for s in ("560 account endpoints", "+0.067", "-41.933", "Units of comparison"))
    controls = read(REPO / "starter_code/runs/evidence_synthesis_20261107/controls_verification.json")
    assert controls["status"] == "passed" and controls["checked_paths"] == 16
    for record in controls["records"]:
        assert digest(REPO / "starter_code" / record["path"]) == record["sha256"]
    before53 = HERE / "history/r052_before_evidence_synthesis"
    for name, expected in read(before53 / "snapshot_manifest.json")["files"].items():
        assert digest(before53 / name) == expected
    influence_root = REPO / "starter_code/runs/order_influence_20261107"
    ip = read(influence_root / "protocol.json")
    assert digest(influence_root / "protocol.json") == read(influence_root / "preparation.json")["protocol_sha256"]
    for name, expected in {**ip["inputs_sha256"], **ip["source_sha256"]}.items():
        assert digest(REPO / "starter_code" / name) == expected, name
    for name, expected in read(influence_root / "output_manifest.json").items():
        assert digest(influence_root / name) == expected, name
    gate = read(influence_root / "factual_verification.json")
    assert gate["status"] == "passed" and gate["frames"] == 216 and gate["financial_accounts"] == 3024
    summary54 = read(influence_root / "summary.json")
    assert summary54["status"] == "completed" and summary54["completed_counterfactuals"] == 432
    assert summary54["new_model_samples"] == summary54["new_endogenous_markets"] == summary54["network_attempts"] == 0
    analysis54 = REPO / "starter_code/runs/order_influence_analysis_20261107_v2"
    for name, expected in read(analysis54 / "output_manifest.json").items():
        assert digest(analysis54 / name) == expected, name
    report54 = read(analysis54 / "report.json")
    assert report54["audit"]["account_settlements"] == 6048 and report54["audit"]["status"] == "passed"
    records54 = read(influence_root / "results.json")
    frames54 = read(influence_root / "frames.json")
    assert sum(f["targets_active"] for f in frames54) == 137
    assert len({(r["frame_index"], r["condition"]) for r in records54}) == 432
    for item in report54["aggregates"]["seed_mode_repetition_condition"]:
        rows54 = [r for r in records54 if all(r[k] == item[k] for k in ("seed", "mode", "repetition", "condition"))]
        assert len(rows54) == item["frames"] == 12
        assert sum(r["price_changed"] for r in rows54) == item["price_changes"] > 0
        assert abs(sum(r["absolute_price_impact_pct"] for r in rows54)/12 - item["mean_absolute_impact_pct"]) < 1e-12
    seed_rows54 = report54["aggregates"]["seed_condition"]
    for item in [r for r in seed_rows54 if r["condition"] == "cap10"]:
        removal = next(r for r in seed_rows54 if r["seed"] == item["seed"] and r["condition"] == "remove")
        row = (f"| {item['seed']} | {item['price_changes']}/72 | {item['mean_absolute_impact_pct']:.6f} | "
               f"{item['volume_reduction_pct']:.3f} | {removal['price_changes']}/72 |")
        assert row in draft and row in (HERE / "ORDER_INFLUENCE.md").read_text(encoding="utf-8")
    cap54, remove54 = report54["aggregates"]["condition"]
    assert (cap54["condition"], cap54["price_changes"], cap54["cap_affected"], cap54["counterfactual_volume"]) == ("cap10",49,105,4339)
    assert (remove54["price_changes"], remove54["counterfactual_volume"]) == (74,3801)
    assert (cap54["gap_improves"],cap54["gap_worsens"],cap54["gap_equal"]) == (37,12,167)
    assert (cap54["changed_fills_same_price"],remove54["changed_fills_same_price"]) == (27,44)
    example54 = next(r for r in records54 if (r['seed'],r['mode'],r['repetition'],r['round'],r['condition']) == (25087,'A',1,4,'remove'))
    assert example54['factual']['price'] == example54['result']['price'] == 111.9
    assert example54['factual']['volume'] == 60 and example54['result']['volume'] == 3
    before54 = HERE / "history/r053_before_order_influence"
    for name, expected in read(before54 / "snapshot_manifest.json")["files"].items():
        assert digest(before54 / name) == expected, name
    from verify_final_extensions import check as check_extensions
    extensions = check_extensions()
    from verify_final_collection import check as check_final_collection
    final_collection = check_final_collection()
    from verify_deepseek_replication import check as check_replication
    replication = check_replication()
    return dict(status="passed", date="2026-11-09", writing_stage="R058 completed replication and final substantive draft",
                draft_words=len(draft.split()), appendix_words=len((HERE / "appendix/SELECTED_PROMPTS.md").read_text(encoding="utf-8").split()),
                valid_local_links=links, bibliography_keys=len(keys), bibliography_key_metadata_match=True,
                actual_prompt_selections_checked=len(selections), initial_BC_messages_equal=True,
                r047_gap_table_rows_checked=6, r047_both_mark_return_rows_checked=6,
                r047_usage_and_same_mode_controls_checked=True, previous_numerical_rows_preserved=True,
                prior_archives_unchanged=len(sources["prior_archives"]), original_source_files_unchanged=len(baseline["sha256"]),
                previous_writing_archives_unchanged=len(sources.get("previous_writing_archives", {})),
                frozen_r047_source_files_unchanged=len(protocol["source_sha256"]),
                archived_replay_coverage=dict(previous_paths=42, previous_financial_csvs=294, r047_paths=23, r047_financial_csvs=161, r047_explicit_exclusions=1),
                new_api_requests=0, new_markets=0, this_command_new_replay_executions=0, fresh_model_samples=0,
                prior_saved_output_reproduction_paths=65 if validated else 0,
                prior_frozen_rule_reproduction_paths=16,
                r050_distinct_path_rows_checked=6, r050_focused_reflections=48,
                r051_primary_rows_checked=4, r051_rule_markets=16,
                r051_arithmetic_account_rounds=134400,
                r052_status="stopped", r052_delivered_reflections=8, r052_missing_reflections=40,
                r052_http_attempts=10, r052_unknown_usage_attempts=2,
                r053_account_endpoints=560, r053_saved_paths=40, r053_background_pairs=12,
                r053_distinct_background_seeds=8, r053_matched_homogeneous_configs=16,
                r054_factual_auctions=216, r054_counterfactual_clears=432, r054_seed_table_rows_checked=3,
                r054_existing_scenarios=3, r054_counterfactual_account_settlements=6048,
                **extensions, **final_collection, **replication,
                limitations="Writing/evidence verification,not a new replication;recorded replay is distinct from fresh sampling and external validation.")


if __name__ == "__main__":
    result = check()
    (HERE / "checks.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
