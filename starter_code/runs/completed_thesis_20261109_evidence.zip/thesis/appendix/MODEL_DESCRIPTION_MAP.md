# Model-description and rationale map

R049,2026-11-05. This is an implementation/source index inspired by ODD's
description structure, not a complete independently audited ODD. Experimental
variants are identified separately from the implemented economic mechanism.

| Item | Implemented description and rationale | Exact source |
|---|---|---|
| Purpose | Examine how execution,background rules and information representation change conclusions within an explicit stock-market laboratory | [Draft introduction](../THESIS_DRAFT.md#1-introduction) |
| Entities and state | One continuing stock;14accounts with cash,shares and average cost;agent-specific histories and diaries | [Engine](../../starter_code/sim/engine.py);[agent base](../../starter_code/sim/agents/base.py) |
| Scale | One batch auction/session;no calibrated daily time conversion,no spatial/social network | [Economic conventions](../../starter_code/ECONOMIC_MODEL.md) |
| Schedule | Scheduled effects/information,orders,validation,allocation,settlement,interest/dividends,actual outcomes,and reflection when due | [Engine](../../starter_code/sim/engine.py);[sequence figure](../FIGURES_AND_APPENDICES.md) |
| Individual decisions | Fixed background rules and selectable raw/factual/reflection LLM modes;generated beliefs may be wrong | [Rule agents](../../starter_code/sim/agents/rule_agents.py);[LLM agent](../../starter_code/sim/agents/llm_agent.py) |
| Interaction and emergence | Orders interact through resource constraints and allocation;prices and holdings emerge from that mechanism;no herding mechanism inferred | [Market](../../starter_code/sim/market.py) |
| Stochasticity | Seeded simulation streams and unseeded provider outputs;do not equate exogenous seeds with model seeds | [Engine](../../starter_code/sim/engine.py);[study inventory](STUDY_INVENTORY.md) |
| Initialization/input | Configured resources and prior;personas and exact actual messages preserved;news differs only in designated conditions | [Config parser](../../starter_code/sim/config.py);[actual prompts](SELECTED_PROMPTS.md);[inventory](STUDY_INVENTORY.md) |
| Income/value submodel | Bounded iid payouts within regimes;external cash injections;researcher benchmark uses stated risk-neutral assumptions | [Assets](../../starter_code/sim/assets.py);[economic conventions](../../starter_code/ECONOMIC_MODEL.md) |
| Observation/evaluation | Requested/accepted/filled orders,all account states,both conditional wealth marks,market diagnostics,cost and failures | [Evaluation](../../starter_code/sim/evaluation.py);[principal reports](STUDY_INVENTORY.md) |

Small population, single asset and short live paths make controlled comparisons
tractable. They are restrictions on inference, not empirical estimates of a
real exchange's composition. Parameter choices and the dividend/interest
timing are implemented assumptions rather than fitted facts. A hidden
benchmark field can still be inferred from disclosed assumptions; no inaccessible
fundamental-value information is asserted.

Study-specific adapters and source snapshots in the frozen protocols take
precedence over an unversioned current file when reproducing an old run.
Differences between implementations and older design prompts are documented
in the research diary. ODD documentation does not itself establish calibration,
human realism, fresh-model repeatability or an independent implementation.
