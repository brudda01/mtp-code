# Principal-study and reproduction inventory

**R055/R056 final additions:** See [the extension guide](../FINAL_EXTENSIONS.md).
R055 uses18 reconstructed R043 controls and36 dynamic rule-response paths,
with fixed LLM accepted-order tapes. Three original seeds remain;18 removal
executions collapse to3distinct paths. R056 uses a separate freshseed30841,
six DeepSeek LLMs plus8rules,25sessions and an enforcedcap10. It changes model,
population composition,cap andhorizon together;no isolated cross-model or count
effect is identified. The guide records the final provider completion/failure
status separately from this design inventory.

**R054 addition (2026-11-08 integration):** All216 R043 factual auctions
(18paths,3existing seeds) reconstructed, then432 isolated interventions: joint
cap10 and joint order suppression. No new LLM samples, provider requests or
adaptive paths. See [the study guide](../ORDER_INFLUENCE.md). Independent checks
cover432 price/volume selections and6,048 counterfactual settlements. The full
live cohort and original model/prompt provenance remain R043 evidence.

**R052 partial validation (2026-11-07):** Planned48fixed-history reflections
(12actorhistories x2formats x2draws);8delivered,40missing after twoHTTP503attempts
on slot9. Delivered sample is one draw per format for four actorhistories from
two inherited contexts of seed22853. TenHTTP attempts,26788known tokens,two
unknown-usage failures;zero newmarkets. Neither target error appeared in the
eight delivered texts;no improvement/equivalence conclusion. See the
[protocol and partial-results record](../FEEDBACK_VALIDATION_PROTOCOL.md).
Saved-request and annotation verification is re-analysis,not fresh sampling.

R048 writing inventory, 2026-11-05. Four designs support three result families;
their rows are not pooled into one independent sample size. Earlier pilots,
stopped paths and ambiguous-headline cohorts remain in the research diary and
their original archives. The table does not replace those records.

| Study | Scope and replication unit | Model requests and failures | Recorded-output verification |
|---|---|---|---|
| R039 | Four fresh exogenous seeds;original/zero inventory-skew pairs;8rule paths of600sessions | No model calls | All8paths,56financial CSVs byte-identical in examiner replay |
| R041 | Two fresh seeds x2model draws x2maker settings xvisible/silent downside;16paths of8sessions | 256valid decisions/256HTTP;no retries,unknown usage,repairs or missing paths | All16paths,112financial CSVs byte-identical in examiner replay |
| R043 | Three fresh seeds x2model draws xA/B/C;18paths of12sessions | 432decisions+24reflections,456HTTP;no errors/unknown usage/missing paths | All18paths,126financial CSVs byte-identical,with explicit archived-helper supplement |
| R047 | All6R043 B histories through5,nested in the SAME3seeds;2fresh B/2C branches each;24seven-session continuations | 336fresh decisions+48reflections;385HTTP;one recovered Berror/unknown usage;no missing continuation | 23paths,161financial CSVs byte-identical;one recovered-error path explicitly not replayed |

Recorded-output verification blocks network access and supplies saved model
replies. It is not fresh provider sampling, a new independent scenario or an
independent-machine/reimplementation replication. Reused five-session prefixes
are not independent observations. R047's cached deliveries consume no new API
usage; its cost report concerns fresh requests and retains unknown usage.

## Model, economic and prompt provenance

The live designs above use BharatCode's OpenAI-compatible endpoint and exact
model identifier `qwen-3.8-27b`, output cap8192, low reasoning effort, decision
temperature0.3, reflection temperature0 where used, and request timeout180s.
Provider draws are unseeded and no backend fingerprint is pinned. The frozen
protocols and actual request records, not this summary, are the authority for
per-call messages/settings and delivery history.

Economic resources are160000cash/1450shares across14accounts,including two LLM
targets in live paths. The baseline maker inventory skew is0.02 and the
fundamentalist dividend window is1;0skew is a designated sensitivity in R039/
R041,not a selected new default. R041 uses a clarified one-time permanent
downside mean shift; R043/R047 are quiet. Hidden recording length and honest
initial-prior research adapters are recorded separately from core A/B/C.
Personas and exact prompts are preserved,not reconstructed from explanations.

| Study | Exact metadata/results and preservation source |
|---|---|
| R039 | [Study report](../../starter_code/runs/20261104_154730_market_validation_fff53e3b/report.json);[supplement](../../starter_code/runs/20261104_154730_market_validation_fff53e3b/supplement/INTERPRETATION.md);balanced_validation_20261104_evidence.zip |
| R041 | [Report](../../starter_code/runs/downside_confirmation_analysis_20261104/report.json);[interpretation](../../starter_code/runs/downside_confirmation_analysis_20261104/INTERPRETATION.md);downside_confirmation_20261104_evidence.zip |
| R043 | [Frozen protocol](../../starter_code/runs/20261105_012335_quiet_components_5066abab/protocol.json);[report](../../starter_code/runs/quiet_components_analysis_20261105/report.json);quiet_components_20261105_evidence.zip |
| R047 | [Frozen protocol](../../starter_code/runs/20261105_041035_common_prefix_ca10f93d/protocol.json);[report](../../starter_code/runs/common_prefix_analysis_20261105/report.json);[completion receipt](../../starter_code/runs/20261105_041035_common_prefix_ca10f93d/postprocessing_summary.json);common_prefix_20261105_evidence.zip |

R039/R041/R043 replay records are in the
[examiner audit](../../starter_code/runs/examiner_audit_20261105_v2/README.md).
R047 has its own [replay report](../../starter_code/runs/common_prefix_analysis_20261105/replay_report.json).
Each archived source captures the executable revision and uncommitted changes;
the common Git parent alone does not identify what was run. Current archive
SHA256 values and writing inputs are indexed in [sources.json](../sources.json).

## Selection and limitations

All final-study contrasts are retained, including null, mixed and opposite
signs. R043's pre-reflection diagnostic and selected transfer/sizing examples
are post-hoc and labelled accordingly. R047's new endpoints and schedule were
frozen before its first fresh call. It is a conditional diary-policy test,
not an isolated reflection-content test or fresh exogenous-scenario replication.
No account of reproducibility here establishes empirical human-market validity.

For exact selected actual prompts, see [Appendix A](SELECTED_PROMPTS.md) and
its [source JSON](selected_prompts.json). For older missing/capped/failed work,
see [RESEARCH_DIARY.md](../../RESEARCH_DIARY.md); do not silently pool those
cohorts or replace unavailable terminal outcomes with HOLD.


## R050/R051 additions (2026-11-07 review)

R050: all24 existing R047 branches/48reflections/36dependent branch pairs,
and R043 background synchrony. Retrospective,0new API requests/markets.
[Source-linked report](../../starter_code/runs/feedback_audit_20261106/report.json).

R051:4fresh seeds26183/27329/28513/29671 x2background bundles x2skews x600sessions:
16new RULE markets,9600sessions,134400account-rounds. Zero API/network.
[Protocol](../../starter_code/runs/background_diversity_20261106/protocol.json),
[full results](../../starter_code/runs/background_diversity_20261106/report.json).
The sixteen paths are not sixteen independent exogenous scenarios. Prior replay
coverage65paths/455CSVs remains historical;this stage adds arithmetic checks,
not fresh model draws or an independent-machine reproduction.


## Final R056 seed31991 attempt and R057 closure

Seed30841 remains completed25rounds/150decisions. Seed31991 has0cleared rounds,
1delivered reply and149missing decisions. Its first attempt failed immediately
with HTTP429; a disclosed amendment before any behavioral reply allowed one
re-entry within the original combined180HTTP/3M ceilings. That attempt also
stopped on429 before an auction. Combined3HTTP/803known tokens/16592reservations,
2unknown-usage errors. No market metrics, second-seed mean or causal comparison.
[Complete final collection record](../FINAL_COLLECTION.md),
[availability and verification report](../../starter_code/runs/final_collection_analysis_20261108/report.json),
[permanent freeze](../../DATA_COLLECTION_FROZEN.md).


## Completed R058 supersedes earlier partial-seed status

Seed31991 now has25cleared rounds/150decisions in
[finish25](../../starter_code/runs/goedel_seed2_finish25_20261109/summary.json).
Together with30841,R056/R058has two market scenarios/300decisions/700audited
account-rounds. Six continuation stages retain allsuccessful replies in order;
488actual market-chainHTTPattempts delivered150decisions,338errorshaveunknownusage.
The finalsummary383records excludes105terminal errorrecords fromreplay;those
errorsremainarchived. No continuation is counted asanother market replication.
[Full tables/provenance](../DEEPSEEK_REPLICATION.md),
[analysis](../../starter_code/runs/deepseek_completed_analysis_20261109/report.json),
[current collection closure](../../DATA_COLLECTION_STATUS.md).
