"""Read-only verification of completed DeepSeek results, continuation provenance and thesis tables."""
import hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent
REPO=HERE.parent
BASE=REPO/'starter_code'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check():
    analysis=BASE/'runs/deepseek_completed_analysis_20261109';review=BASE/'runs/deepseek_completed_review_20261109'
    r=read(analysis/'report.json');assert r['completed_market_scenarios']==2
    for directory in (analysis,review):
        for n,h in read(directory/'output_manifest.json').items():assert digest(directory/n)==h,n
    for item in r['reports']:
        root=BASE/item['root'];p=read(root/'protocol.json');s=read(root/'summary.json')
        assert s==item['summary'] and s['status']=='completed' and s['completed_rounds']==25 and s['delivered_decisions']==150
        assert digest(root/'protocol.json')==read(root/'preparation.json')['protocol_sha256']==item['protocol_sha256']
        assert digest(root/'config.yaml')==p['config_sha256'] and digest(root/'source.zip')==p['source_zip_sha256']
        for n,h in {**p['inputs_sha256'],**p['source_sha256']}.items():assert digest(BASE/n)==h,n
        for n,h in read(root/'output_manifest.json').items():assert digest(root/n)==h,n
        assert item['audit']['account_rounds']==350 and item['complete_actual_input_pairs_checked']==150
    assert [x['seed'] for x in r['reports']]==[30841,31991]
    d=r['delivery'];assert (d['actual_archived_http_attempts'],d['actual_successful_decisions'],d['known_tokens'],d['unknown_usage_attempts'])==(488,150,361206,338)
    assert d['final_summary_record_count']==383 and d['terminal_error_records_excluded_from_replay']==105
    assert sum(x['fresh_http_attempts'] for x in d['chain'])==488 and sum(x['fresh_decisions'] for x in d['chain'])==150
    assert len(d['prefix_checks'])==5 and all(x['success_sequence_preserved'] for x in d['prefix_checks'])
    assert len(read(review/'continuation_state_checks.json')['checks'])==4
    for name,folder in [('market_table.md',analysis),('persona_table.md',analysis),('endpoint_table.md',review),('cross_study_table.md',review)]:
        table=(folder/name).read_text(encoding='utf-8').strip()
        for file in ('THESIS_DRAFT.md','DEEPSEEK_REPLICATION.md'):assert table in (HERE/file).read_text(encoding='utf-8'),file
    assert abs(r['means_descriptive_only']['price_return_sd_pct']-1.640289553895969)<1e-12
    assert abs(r['means_descriptive_only']['mean_gap_pct']-12.306)<1e-12
    assert len(r['qwen_B_context']['paths'])==6 and r['qwen_B_context']['distinct_seeds']==3
    auth=read(REPO/'DATA_COLLECTION_AUTHORIZATION.json');assert auth['status']=='closed_after_seed31991'
    root=BASE/'runs/goedel_seed2_finish25_20261109'
    assert auth['completed_protocol_sha256']==digest(root/'protocol.json') and auth['completed_output_manifest_sha256']==digest(root/'output_manifest.json')
    for folder in ('r057_before_backoff','r058_before_finalization'):
        before=HERE/'history'/folder
        for n,h in read(before/'snapshot_manifest.json')['files'].items():assert digest(before/n)==h,n
    return dict(collection_status='closed_after_completed_replication',r058_completed_market_scenarios=2,r058_completed_market_decisions=300,
        r058_account_rounds_checked=700,r058_actual_input_pairs_checked=300,r058_preserved_partial_prefixes=4,
        r058_seed31991_market_chain_http=488,r058_seed31991_known_tokens=361206,r058_seed31991_unknown_usage_attempts=338,
        r058_final_stage_fresh_http=41,r058_final_stage_fresh_decisions=34,r058_terminal_error_records_retained=105,
        r058_market_table_checked=True,r058_persona_rows_checked=12,r058_endpoint_rows_checked=12,r058_qwen_B_context_paths=6)
if __name__=='__main__':print(json.dumps(check(),indent=2))
