# Completed DeepSeek two-seed replication

2026-11-09. R056 seed30841 and R058 seed31991 each completed25sessions and150
valid decisions. The final31991 root is
[goedel_seed2_finish25_20261109](../starter_code/runs/goedel_seed2_finish25_20261109/summary.json).
Its earlier stopped continuations are retained; they are not additional markets.
Data collection is closed. Formatting remains last.

## Design and interpretation

Six library personas, eight rule traders, Mode B with five own executed outcomes,
cap10, same endowments and economic rules; DeepSeek v4.1 Flash, temperature0.3,
thinking disabled, output2048, no reflection. Seeds are30841 and31991, with
unseeded provider draws. The economic configurations differ only in seed/name;
request/reservation ceilings expanded during the authorized31991 recovery.
Initial financial states and personas match exactly. Python type labels differ
because delivery subclasses changed, with no change to economic behavior code.

| Metric | Seed 30841 | Seed 31991 | Two-seed mean |
|---|---:|---:|---:|
| Mean closing price | 116.060 | 108.552 | 112.306 |
| Mean log-price return (%) | 0.503005 | 0.307844 | 0.405424 |
| Log-price-return SD (%) | 2.141060 | 1.139519 | 1.640290 |
| Mean reference gap (%) | 16.060 | 8.552 | 12.306 |
| Maximum drawdown (%) | 7.277187 | 2.702703 | 4.989945 |
| Final auction price | 113.4 | 108.0 | 110.7 |
| Total traded shares | 557 | 457 | 507.0 |
| Shares traded per round | 22.28 | 18.28 | 20.28 |
| Shares involving an LLM | 336 | 294 | 315.0 |
| Minimum closing maker inventory | 66 | 89 | 77.5 |
| Maximum closing maker inventory | 191 | 158 | 174.5 |
| Zero-trade rounds | 0 | 0 | 0.0 |

| Trader | Seed | Executed buys | Executed sells | Passive excess, auction (pp) | Passive excess, reference (pp) |
|---|---:|---:|---:|---:|---:|
| Meera Iyer | 30841 | 0 | 0 | +0.000 | +0.000 |
| Arjun Malhotra | 30841 | 87 | 70 | +0.145 | -0.994 |
| Prakash Rao | 30841 | 0 | 51 | +1.793 | +5.210 |
| Sana Sheikh | 30841 | 63 | 0 | -0.972 | -5.193 |
| Vikram Bose | 30841 | 87 | 0 | -0.542 | -6.371 |
| Lakshmi Nair | 30841 | 19 | 0 | +0.201 | -1.072 |
| Meera Iyer | 31991 | 0 | 0 | +0.000 | +0.000 |
| Arjun Malhotra | 31991 | 93 | 0 | +0.265 | -3.455 |
| Prakash Rao | 31991 | 0 | 0 | +0.000 | +0.000 |
| Sana Sheikh | 31991 | 33 | 0 | -0.079 | -1.399 |
| Vikram Bose | 31991 | 93 | 0 | +0.276 | -3.444 |
| Lakshmi Nair | 31991 | 75 | 0 | -0.342 | -3.342 |

| Trader | Seed | Final cash | Final shares | Auction wealth | Reference wealth | Same-action transitions |
|---|---:|---:|---:|---:|---:|---:|
| Meera Iyer | 30841 | 10101.15 | 100 | 21441.15 | 20101.15 | 24/24 |
| Arjun Malhotra | 30841 | 8202.38 | 117 | 21470.18 | 19902.38 | 22/24 |
| Prakash Rao | 30841 | 16243.19 | 49 | 21799.79 | 21143.19 | 23/24 |
| Sana Sheikh | 30841 | 2762.63 | 163 | 21246.83 | 19062.63 | 24/24 |
| Vikram Bose | 30841 | 126.91 | 187 | 21332.71 | 18826.91 | 23/24 |
| Lakshmi Nair | 30841 | 7986.66 | 119 | 21481.26 | 19886.66 | 22/24 |
| Meera Iyer | 31991 | 10099.58 | 100 | 20899.58 | 20099.58 | 24/24 |
| Arjun Malhotra | 31991 | 108.58 | 193 | 20952.58 | 19408.58 | 22/24 |
| Prakash Rao | 31991 | 10099.58 | 100 | 20899.58 | 20099.58 | 24/24 |
| Sana Sheikh | 31991 | 6519.70 | 133 | 20883.70 | 19819.70 | 24/24 |
| Vikram Bose | 31991 | 110.78 | 193 | 20954.78 | 19410.78 | 23/24 |
| Lakshmi Nair | 31991 | 1931.25 | 175 | 20831.25 | 19431.25 | 24/24 |

The mean column averages path statistics; no pooled-volatility, confidence
interval or two-seed significance claim is made. Session lengths are not fitted
to calendar days. Neither maker touches0or300. All requested quantities are
within10; no mechanical cap reductions occur. This is not a cap-effect estimate.
Meera's all-HOLD and Sana's all-BUY requests persist across both seeds, but Sana's
fills differ63versus33. Prakash switches from51shares sold to no trades; Lakshmi
switches from10BUY/15HOLD to25BUY. Both terminal marks are therefore retained.

## Focused Qwen context

| Descriptive metric | DeepSeek B: two 25-round paths | Qwen B: six 12-round paths |
|---|---:|---:|
| Mean within-path return SD (%) | 1.640 | 2.257 |
| Mean reference gap (%) | 12.306 | 9.051 |
| Mean maximum drawdown (%) | 4.990 | 4.798 |
| Mean traded shares per round | 20.280 | 24.681 |

Qwen context is ONLY the six R043 B paths, three seeds/two draws,12sessions,
two LLMs plus12rules, without DeepSeek's explicit10-share cap. Its return SD
range0.696?3.256% overlaps both DeepSeek paths. Lower average DeepSeek volatility
coexists with larger average valuation gaps and slightly larger average maximum
drawdown. These jointly changing designs cannot identify a model, population,
cap or horizon effect. Qwen A/B/C/reflection and news results retain their own
comparisons. Chapter6.1 develops this interpretation and persona limitations.

## Continuation provenance and usage

Seed31991 preserves every successful response in order across six execution
stages. Exact wire payloads in all five replay prefixes were matched to original
source records. All four earlier completed partial-market prefixes have identical
prices, orders, trades, cashflows, liquidity and financial states in the final
path; only agent-type metadata labels are normalized. No successful reply was
replaced. Terminal failed attempts were omitted from continuation replay tapes
to reset exhausted retry counters, but remain in their original archives.

| Execution stage | Fresh HTTP attempts | Fresh decisions | Known tokens |
|---|---:|---:|---:|
| Initial backoff | 38 | 27 | 38,543 |
| Detached continuation | 37 | 8 | 19,427 |
| Exponential backoff | 239 | 69 | 179,319 |
| Full25 continuation | 55 | 9 | 23,751 |
| Final continuation | 78 | 3 | 8,082 |
| Finish25 continuation | 41 | 34 | 92,084 |
| Seed31991 market-chain total | 488 | 150 | 361,206 |

The338failed attempts comprise336HTTP429, oneHTTP502 and one transport error.
Their actual usage is unknown. The final worker's383summary records combine342
replayed historical records with41fresh attempts;105terminal error records are
absent from that replay tape, not absent from the scientific record. Never sum
continuation summaries as new usage. Seed30841 separately used150requests and
369,984reported tokens. The two older R057 aborted attempts used3requests,
1unexecuted reply and803known tokens, with2unknown errors. Recorded market logs
therefore total641requests and731,993known tokens across these scopes; the
unexecuted R057 reply is not part of the300completed-market decisions. These
are market-log subtotals, excluding external availability probes and any
unlogged in-flight request at the initial interruption, not provider billing.

Retry policy evolved from Retry-After+1 to+3, then exponential429backoff with
larger ceilings and502/503/504handling; the final source permits60rate-limit
retries and15server retries per logical request. A user-reported credential
change occurred during recovery. No credential values are exported. Continuity
of market state is verified; identical backend weights across wall-clock time or
accounts are not established. These amendments and interruptions are disclosed,
not described as a single uninterrupted frozen delivery campaign.

Some final protocol prose fields were inherited from earlier protocols and
still mention earlier ceilings/authorization. The final explicit limits,
configuration, executable frozen source and this stage-by-stage ledger resolve
those metadata differences; original protocols are not rewritten. The old
R057 freeze record is retained as history; current closed authorization/status
supersede its one-completed-scenario statement.

## Verification and reproduction

[Analysis](../starter_code/runs/deepseek_completed_analysis_20261109/report.json)
checks both completed paths:300exact input pairs and700account-rounds, cash
residuals below1e-7 and exact shares. This establishes implementation consistency,
not human realism or external-machine replication.
[Continuation checks](../starter_code/runs/deepseek_completed_review_20261109/continuation_state_checks.json)
verify all preserved complete prefixes. The
[two-seed figure](../starter_code/runs/deepseek_completed_analysis_20261109/two_seed_paths.pdf)
has common axes and retains both paths.

From `starter_code`, this command reads saved records only and requires a new
output directory:

```powershell
python -B -m research.analyze_completed_deepseek --output runs/deepseek_analysis_NEW
```

From the repository root, `python -B thesis/verify_writing.py` checks the current
manuscript/evidence. Do not run old live launchers. No new collection is scheduled.
