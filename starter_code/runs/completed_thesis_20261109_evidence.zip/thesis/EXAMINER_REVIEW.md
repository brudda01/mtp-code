# Examiner-style audit: substance, realism and reproducibility

R046,2026-11-05. This is a critical internal review,not external examiner
approval or a prediction of grades. No fresh model calls were made.

## Verdict

There is a defensible basis for a focused Master's simulation/methodology
thesis,with modest novelty and material claim revisions. The evidence does
not support a validated human-market simulator or a demonstrated causal benefit
from reflection. A coherent implemented laboratory and auditable experiments
are substantive;several observations are expected mechanisms or accounting
facts and should not be advertised as nine independent discoveries.

## Which findings carry scientific weight?

| Result | Assessment | Appropriate use |
|---|---|---|
| Inventory-skew trade-off across four fresh paired scenarios | Strongest controlled within-model sensitivity;inventory bounds worsening after removing inventory control is partly expected | Main result,including magnitudes,return dependence,all exceptions and scope |
| Same price path with different trades/account outcomes | Exact useful counterexample;the general possibility is familiar,not a new economic principle | Clear illustrative figure in a measurement/results chapter |
| Aggregate -3 hiding -90/+87 individual contrasts | Exact disaggregation example;closely connected to the preceding result | Supporting evidence,not an independent headline discovery |
| Downside response negative7/8 contrasts | Interesting exploratory pattern across only two exogenous scenarios;draws/backgrounds are nested | Report all cases,avoid universal response or human-bias inference |
| Accepted-versus-executed differences/sign reversal | Useful mechanism demonstration;older replay cohort and ambiguous wording retained | Supporting diagnostic,not an independently replicated market effect |
| C-B whole-path gap lower in three scenario means | Genuine descriptive numbers,but pre-reflection imbalance defeats a causal reflection claim | Exploratory component comparison,with correction below |
| Apparent C-B advantage already present before reflection in all six pairs | Useful negative-control diagnostic of the attribution problem in this sample | Main component-study interpretation,explicitly post-hoc;not a claim that reflection is ineffective |
| Additional reflection tokens | Clearly measured campaign cost;extra context requiring tokens is unsurprising | Cost-benefit discussion,not a scientific discovery by itself |
| Real-reference diagnostic mismatch | Substantive negative validation evidence;portfolio/clock differences limit transfer | Explicit result/limitation,not a universal statistical rejection |

## Critical correction: the reflection comparison

All six paired C/B markets already favoured C on mean valuation gap during
sessions1–5,before reflection could affect a decision. Two-draw scenario means:

| Seed | C-B before reflection,pp | C-B later6–12,pp |
|---|---:|---:|
| 22853 | -1.1900 | +0.1429 |
| 23971 | -1.3700 | -2.0214 |
| 25087 | -2.2300 | -5.6286 |

Consequently,the whole-run difference cannot establish that reflection improved
prices. Nor does this audit prove reflection has no effect:later outcomes
combine inherited states,model draws and feedback. The window comparison is a
post-hoc diagnostic,not a valid causal difference-in-differences estimate.
The numerical result and token/wealth records remain intact. The draft's
abstract,results and conclusion were revised to remove causal-sounding wording;
the previous draft is preserved in history/r045_before_examiner.

If reflection efficacy must be central,the most useful additional study is a
common-prefix comparison:both modes replay the SAME actual first-five-session
history,then B continues with summaries while C generates reflection on that
same history and both make fresh subsequent choices. Re-executing the prefix
can avoid new checkpoint infrastructure. Such a study needs its own frozen
schedule,repetitions,budget and failure policy;it is proposed,not implemented
or launched. Shared prefixes would not be counted as independent observations.
Even that would establish a local simulated effect,not human realism.

## Does the model disregard realism?

Valuation-mark reversals also have an accounting explanation. For passive
excess return,the difference between auction and private marks is
`(final_shares - initial_shares) * (auction_price - private_value) / initial_wealth`.
That identity makes mark sensitivity important to report,but it is not itself
a novel empirical discovery or independent evidence of behavioural realism.

The economic accounting is coherent and the institutional simplifications are
explicit. Resource constraints,partial/non-fills,priority,dividend timing and
income accounting are real considerations. A batch-auction laboratory can be
appropriate for mechanism studies. Those points do not make its population
or dynamics empirically realistic.

Material weaknesses are:

- Only fourteen accounts,two bundled LLM personas and one unseeded provider
  model. No empirical persona calibration or human reference population.
- One stock,one batch per session,no continuous-book latency or competing
  assets. These are scope choices with consequences,not a full exchange model.
- Independent bounded per-session dividends and permanent mean shifts. The
  private value mu/r is a risk-neutral stationary-regime reference,not observed
  market truth or every trader's correct subjective valuation.
- Window1 fundamentalists extrapolate one noisy payout. At baseline the proxy
  ranges80–120 around100 from the configured noise alone. Background persistence
  and the maker trade-off can depend on this heuristic;earlier smoothing
  sensitivities already showed other trade-offs,without selecting a default.
- Order-size differences matter. In R043,two LLM accounts were involved on at
  least one side of24.9%–79.6% of share volume. Per-market median positive accepted
  quantities were15–80 for LLMs versus5–9 for background orders. Equal resources
  do not isolate reasoning quality from trading intensity.
- Cash injections produce about24.31% average aggregate cash growth over the
  R039600-session paths. A stationary dividend regime does not establish a
  stationary market. Daily labels do not make one artificial round equivalent
  to a real market day for every diagnostic.
- Absolute-return dependence remains unlike the chosen empirical window.
  Long paths here contain rules,not LLMs;short live paths cannot establish
  long-run stylized facts. No general human-market validation has been achieved.

These limitations are now prominent in the draft. Further parameter tuning
to obtain expected-looking graphs would not resolve external validity.

## What has actually been reproduced?

| Meaning | Audit evidence | Status |
|---|---|---|
| Recompute recorded measurements | Tables,raw trade/price/account data and preserved sources | Checked for the reported cohorts |
| Regenerate paths with original recorded model replies | Isolated archived-source processes;network blocked;exact request/settings assertions |42/42 verification paths,all294 financial CSV matches |
| Repeat under fresh model draws | Existing R041two draws/cell and R043two draws/mode/scenario | Small-sample repeat evidence;stable magnitudes/causal reflection benefit not established |
| Independent researcher/machine reproduction | Source/dependency files and versions retained | Not independently performed |
| Generalize to humans or other real markets/models | No matched human/empirical calibration | Not demonstrated |

The replay regenerated8 R039rule paths,16 R041paths and18 R043paths:5144
financial rounds. It consumed712 recorded decision/reflection replies with
ZERO network attempts. All seven financial files per path matched byte for
byte. It did not generate712 fresh decisions or add independent observations.
The replay uses the original implementation,not an independent reimplementation.

The audit also found a source-bundle dependency defect:the original R043
prepared archive omitted `runs/sequential_next_20261103.py`,needed through a
transitive adapter import. An isolated first attempt failed before any market
replay. Supplying that file from the previously sealed R041source archive,
matching the earlier R042hash checkpoint,allowed all18replays to pass.
Original bundles and the failure are preserved;a separate dependency supplement
is provided. This is an important qualification to earlier broad reproducibility
language,not hidden as an environmental problem.

See [replay instructions and records](../starter_code/runs/examiner_audit_20261105_v2/README.md)
and [post-hoc diagnostics](../starter_code/runs/examiner_audit_20261105_v2/diagnostics.json).
Future live runs cannot be promised identical:model aliases/backends may change,
sampling is unseeded and scenario counts are small. Recorded-output reproducibility
is now demonstrated locally;general fresh behavioural replicability is open.

## Recommended scope

Continue writing the measurement/institution thesis with this correction.
Treat C/B gap differences as descriptive and human/market realism as an open
validation question. If a causal reflection result is essential,prioritize the
single common-prefix design above before another large sweep. If human realism
is essential,a suitable human task/benchmark and matched measurements are
necessary;more API calls alone cannot establish it. No new study is authorized
by an audit verdict or automatically scheduled here.
