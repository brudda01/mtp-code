# R049 scientific manuscript review

**Current final result (2026-11-09):** both DeepSeek seeds30841/31991 now
complete25sessions and150decisions each. [Completed replication](DEEPSEEK_REPLICATION.md)
reports all endpoints, means, Qwen context and the full continuation ledger.
Earlier partial-collection statements below are historical. Collection is closed;
the substantive draft is finalized, with institutional formatting deferred.

**Subsequent R050/R051 review (2026-11-07):** The
[follow-up record](FEEDBACK_AND_BACKGROUND_REVIEW.md) documents a concrete
feedback-timing limitation,an opt-in correction verified offline,all-context
execution distinctions,and16fresh rule-only background-diversity markets.
The trade-off persists in4fresh scenarios;heterogeneity also produces a severe
adverse valuation path. This expands the substantive evidence while retaining
the external-validity and behavioral-efficacy gaps. The R049 record below is
historical and is not overwritten as if these additions existed earlier.

2026-11-05. Internal review of reasoning and evidence,not supervisor/examiner
approval or a grade prediction. Department formatting is explicitly deferred
until the content and references are settled.

## Resolved in this revision

- The contribution is stated through three measured result families,with
  known mechanisms and accounting identities separated from new within-model
  observations. No collection of illustrations is sold as many independent
  discoveries.
- Classical heterogeneous expectations,empirical validation and model
  description now have targeted primary-source references. Access and reading
  limits are explicit;none supplies a reproduced numerical baseline.
- Hidden benchmark means no directly supplied current-value field,not
  necessarily uninferrable information. The initialization prior/known rate
  or visible mean shift may support inference under the stated assumptions.
- Simulation sessions have no fitted conversion to real trading days. Daily
  portfolio diagnostics remain descriptive context rather than calibrated
  single-stock validation.
- R043 remains the descriptive A/B/C comparison;R047 addresses a specific
  common-start identification gap. Their different endpoints/starting accounts
  are not pooled. Same-mode variation is not a significance/equivalence test.
- The offline guide distinguishes evidence verification,recorded-output replay,
  fresh provider sampling and external validation. The one completed but
  unreplayed recovered-error continuation remains visible.

## Still open before submission

| Issue | What is needed | Does it require another experiment by default? |
|---|---|---|
| Scope and originality | Student/supervisor assessment of the bounded within-model contribution,with broader literature judgment | No |
| Scholarly coverage | Complete publication-version/author metadata and remaining relevant references;no exhaustive-search claim | No |
| Student voice and explanation | Student reviews every claim,selected example and limitation and can explain it in a viva | No |
| External realism | A matched human/market benchmark and calibrated definitions if the thesis claims them | Such a claim needs different evidence;it is not currently made |
| General reflection efficacy | More independent histories/draws and a matched-context sham for stronger content-specific claims | Not needed for the present conditional findings |
| Independent reproduction | A separate reader/machine runs the documented offline pipeline with preserved evidence | Local reruns alone cannot satisfy this |
| Department layout | Actual template/front matter/page/citation requirements,applied last | No |

The [current draft](THESIS_DRAFT.md),[claim map](README.md#claims-and-evidence),
[literature record](LITERATURE_REVIEW.md),[model map](appendix/MODEL_DESCRIPTION_MAP.md)
and [reproduction guide](REPRODUCIBILITY.md) identify what is established and
what remains. An absence of universal positive effects is retained as evidence;
it is not a reason to tune the simulator until the preferred signs appear.
