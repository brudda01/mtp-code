# Figure captions and reproducibility appendix map

Draft captions,2026-11-05. All linked figures already exist;no new experiment
or image is generated here. Figure numbers remain provisional until formatting.

## Main-text figures

**Figure1: implemented information and settlement sequence.**
Use this code-native diagram in the methods chapter. Its arrows indicate
implemented timing,not an empirical result.

```mermaid
flowchart LR
  E[Scheduled effects and permitted public information] --> O[Opening accounts and past observations]
  O --> A[Agent requests]
  A --> V[Cash and share validation]
  V --> C[Batch clearing and actual fills]
  C --> S[Settlement]
  S --> D[Dividend and interest payments]
  D --> H[Verified outcomes and account logs]
  H --> O
  H --> R[C only: reflection when due]
  R --> O
```

**Figure2: executed news contrasts.**
[Exportable PDF](../starter_code/runs/downside_confirmation_analysis_20261104/figure_v2/executed_responses.pdf).
Visible-minus-silent executed net purchases during sessions1–3,shown for each
LLM trader and their combined flow in every designated R041 comparison.
Negative values include additional sales and avoided purchases. Comparisons
nest in two exogenous scenarios,two model draws and two maker settings;they
are not eight independent scenario replications. The figure preserves the
zero case and opposing individual signs.

**Figure3: background-market sensitivity.**
[Exportable PDF](../starter_code/runs/thesis_synthesis_20261105/background_tradeoff.pdf).
Original versus zero inventory skew in four fresh600-session rule-market
scenario pairs. Full-path lag-one price-return dependence falls in each pair,
while time at empty/full maker inventory increases. Lines connect matched
exogenous scenarios;neither setting is selected as a realistic default.

**Figure4: component market-gap and token contrasts.**
[Exportable PDF](../starter_code/runs/quiet_components_analysis_20261105/component_contrasts.pdf).
All B-A and C-B draw contrasts for whole-path mean valuation gap and reported
tokens in R043. Points are two model draws nested within each of three
exogenous scenarios;horizontal bars are within-scenario means. The accompanying
return table must retain both traders and both terminal marks,because a lower
gap does not imply better individual returns. No universal agent ranking follows.

## Supporting material and appendix selections

| Appendix item | Exact existing source | Selection rule / qualification |
|---|---|---|
| All R041 paired price paths | [Paired paths PDF](../starter_code/runs/downside_confirmation_analysis_20261104/paired_paths.pdf) | All designated pairs,not only illustrative transfer case |
| R041 transfer/opposing-response audit | [Mechanism audit](../starter_code/runs/downside_confirmation_analysis_20261104/mechanism_audit.json) | Identified post-hoc examples,with all8 first-visible Arjun cases retained |
| R039 all price/inventory paths | [Full paths PDF](../starter_code/runs/20261104_154730_market_validation_fff53e3b/supplement/price_inventory_paths.pdf) | All4 scenario pairs,including late deterioration and exceptions |
| R043 all primary contrasts | [Readout](../starter_code/runs/quiet_components_analysis_20261105/READOUT.md) | All12 prespecified contrasts;no preferred draw selection |
| R043 prompt/config/persona provenance | [Frozen protocol](../starter_code/runs/20261105_012335_quiet_components_5066abab/protocol.json) | Follow its run index to exact messages and personas;never reconstruct from memory |
| Older conditional/component evidence | [Final conditional readout](../starter_code/runs/component_final_analysis_20261103/READOUT.md) | Keep107valid/1missing and shared-A-history limitations |
| Earlier endogenous component evidence | [Sequential readout](../starter_code/runs/sequential_final_analysis_20261104/READOUT.md) | Keep two partial Cmarkets,old news/horizon settings and cancelled choice |

The [selected prompt appendix](appendix/SELECTED_PROMPTS.md) now copies the
first prespecified R043 scenario/draw's actual persona records and Meera's
initial A/B/C inputs,first Creflection and following decision. The
[exact JSON/source hashes](appendix/selected_prompts.json) preserve the strings
and confirm initial B/C equality. Later C history is its own,not a constructed
identical-state C/B comparison. Reflection text represents generated beliefs,
not verified facts. Broader prompt/persona inventory remains available in raw
artifacts rather than being duplicated in full here.

The full experimental ledger and earlier negative/incomplete work remain in
[RESEARCH_DIARY.md](../RESEARCH_DIARY.md). Routine API recovery and packaging
checks support reproducibility;they need not become headline research figures.
No human-bubble,social-herding or tax-policy chapter is implied by this map.
