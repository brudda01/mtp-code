# Targeted primary-source review (R045, 2026-11-05)

This records the coverage behind Chapter2, not an exhaustive literature review
or a claim that the cited systems were reproduced. Source statements are
paraphrased in the draft; comparisons to this repository are our inferences.
No published performance number is used as a numerical baseline for our runs.

| Reference key | Primary source and reviewed scope | Use in the thesis |
|---|---|---|
| `gode1993allocative` | [Publisher abstract/metadata](https://doi.org/10.1086/261868) | Institutions versus trader sophistication;different constraints and efficiency definition |
| `cont2001empirical` | [Publisher metadata](https://doi.org/10.1080/713665670);original paper,Sections1–3 | Multiple statistical diagnostics and time-scale/estimation qualifications |
| `li2024econagent` | [Author text v4](https://arxiv.org/html/2310.10436v4),Sections2–4,especially3.2/4.3;[ACL metadata](https://aclanthology.org/2024.acl-long.829/) | Existing memory/reflection ablation in a different economic setting |
| `zhang2024stockagent` | [Author text v1](https://arxiv.org/html/2407.18957v1),Sections3,4,5.1–5.2 | Existing personality/event/trading framework and invalid-response correction |
| `yang2025twinmarket` | [Author text v1](https://arxiv.org/html/2502.01506v1),Sections3–5 | Existing BDI/social/empirical-profile design;limits of our social-behaviour claims |
| `papadakis2025stocksim` | [Author text v1](https://arxiv.org/html/2507.09255v1),Sections2–4 | Existing execution-aware platform;engine tests separated from LLM examples |
| `frenchFactors` | [Official construction](https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/Data_Library/f-f_factors.html) | Market total return recovered by adding RF;actual sample stays the preserved R039 snapshot |

## Access and version qualifications

- Gode/Sunder: the publisher abstract and bibliographic record were accessible.
  A [19-page institutional paper copy](https://faculty.sites.iastate.edu/tesfatsi/archive/tesfatsi/ZITraders.GodeSunder.JPE1993.pdf)
  had no extractable text in the web reader. The draft relies on the abstract,
  not a claimed complete methods review. Its restriction against loss-making
  quotes must not be equated with our cash/no-short rules.
- Cont: the author-site PDF fetch failed. A Rice-hosted copy contained only
  four pages,mostly references,and was not treated as the full paper. The
  [14-page original-paper copy](https://finance.martinsewell.com/stylized-facts/distribution/Cont2001.pdf)
  supplied the relevant Sections1–3. Publisher metadata confirms the citation.
- EconAgent: ACL PDF fetch timed out;the accessible author HTMLv4 supplied
  the targeted text. This advances the earlier abstract-only review explicitly.
- StockAgentv1 is pinned;laterv5 was not reviewed. Its HTML/abstract metadata
  disagree on one coauthor's spelling. BibTeX abbreviates the author list;
  final metadata remains to check. No journal status is asserted.
- TwinMarket/StockSim: pinnedv1 preprints are cited as such. Described capability
  is a statement from the paper,not independently audited code behaviour.

## Contribution boundary

Existing work already covers economic reflection,external-event trading,social
simulation and order-level execution. The thesis contribution should be stated
through its implemented controlled comparisons and measured counterexamples.
Avoid claims of inventing memory ablation,being the first LLM exchange,or having
the most realistic execution. No direct superiority comparison was run.

The current study deliberately omits calibrated social networks,empirical
persona estimation and human behavioural replication. Those absences restrict
the claims;they are not evidence that the more elaborate cited systems fail.

Remaining coverage includes classical heterogeneous-agent stock markets,
more recent validation/methodology work,and final publication-version checks.
Broader searching may change the novelty positioning. The verified bounded
experimental findings remain available regardless of that literature judgment.
