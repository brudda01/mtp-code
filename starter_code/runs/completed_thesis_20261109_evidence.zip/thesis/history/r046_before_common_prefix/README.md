# Thesis writing workspace

**R047 controlled follow-up complete; draft integration pending:**24shared-history
B/C continuations show mixed gap/individual-return effects and substantial
same-mode variation. Known reported Ctokens exceed Bby25.62%,with one unknown
Berror-attempt usage.23paths have exact recorded-response replay;one is explicitly
excluded. Read the [manual interpretation](../starter_code/runs/common_prefix_analysis_20261105/INTERPRETATION.md).
The current draft predates this new experiment;do not treat it as integrated.

**R046 examiner correction:** The C-B gap advantage already existed in all six
pairs before reflection. Treat that comparison as descriptive,not an identified
reflection benefit. Read [EXAMINER_REVIEW.md](EXAMINER_REVIEW.md) for the critical
claim/realism ranking and demonstrated offline replay,including a dependency
packaging defect. Fresh live replicability and external validity remain open.

**Decision, 2026-11-05: start writing now.** We have a substantive body of
evidence for a focused simulation thesis. More experiments are not the default
next step. Formal submission readiness still requires a complete literature
review, department formatting and supervisor agreement on scope.

Working title: **Execution, Market Design and Information Representation in an
LLM-Agent Stock Market Simulation**. This title is provisional, not a registered
or supervisor-approved title.

Read [THESIS_DRAFT.md](THESIS_DRAFT.md) for the first substantive draft. It covers
the abstract, research questions, implemented methods, experiment designs,
three results sections, discussion and conclusion. The related-work section
now contains a targeted primary-source synthesis;wider coverage remains
unfinished. This is an editable content draft, not a
submission-ready thesis or an assumed university template.

## Claims and evidence

| Question | Current evidence | Defensible claim | Limit |
|---|---|---|---|
| What does a price-only news analysis miss? | R041:16 markets;2 exogenous scenarios;2 model draws;2 market-maker settings;visible/silent downside pairs | Price paths and aggregate flows can conceal individual execution/wealth responses | Initial truthful downside news;no human or universal news-response validation |
| Does one better market statistic establish realism? | R039:4 fresh paired600-session rule scenarios;fixed600-observation US return reference | Lower return dependence can coincide with more inventory-boundary time;empirical diagnostic gaps persist | Rule-market sensitivity;portfolio reference is not a calibrated single-stock target |
| Do summaries/reflection improve results? | R043:3 fresh scenarios;2 model draws/mode;18 complete12-session markets | C-B gap reductions recur in scenario means,but individual return/valuation/cost trade-offs remain | Endogenous histories and unseeded draws;no isolated reflection-text causality or universal upgrade |

The complete contrast tables and source paths are linked in the draft.
[sources.json](sources.json) pins the draft's local evidence/code inputs.
Old conditional A/B/C, partial markets and ambiguous-headline studies belong
in the development history/appendix; they are not pooled with the final cohorts.

## Writing checklist

- [x] Choose a claim scope supported by completed evidence.
- [x] Draft abstract, introduction, implemented methods and study designs.
- [x] Draft all three result families with negative/mixed outcomes and costs.
- [x] Draft discussion, limitations and conclusion.
- [x] Link existing exportable figures and raw-source readouts.
- [x] Targeted primary-source review of institutions,stylized facts,EconAgent,
  StockAgent,TwinMarket and StockSim,with pinned versions/access limits in
  [LITERATURE_REVIEW.md](LITERATURE_REVIEW.md).
- [x] Working [bibliography](references.bib) and
  [figure/appendix source map](FIGURES_AND_APPENDICES.md).
- [ ] Extend the classical/validation literature coverage and finalize
  author metadata/publication versions before claiming novelty or submission.
- [ ] Review the framing with the supervisor: are within-model methodological
  findings sufficient for the intended thesis, or is a specific human benchmark
  required? This is a scope discussion, not a reason to postpone drafting.
- [ ] Apply actual department title-page/template/page-limit/citation rules
  when supplied. Do not infer them from the old semester plans.
- [x] Add [selected actual prompts/personas](appendix/SELECTED_PROMPTS.md)
  with source hashes,initial B/C equality and deterministic selection.
- [ ] Complete configuration/study/failure inventory and final appendix
  arrangement, without secrets or invented missing data.
- [ ] Revise in the student's voice, review captions/equations and complete
  the final cross-reference/bibliography/layout pass.

A new experiment needs a specific missing claim, a bounded protocol and a
clear reason existing evidence cannot answer it. Do not add herding, policy,
human-bubble replication or model-provider grids just to match old outlines.

The writing decision and future meaningful revisions belong in
[RESEARCH_DIARY.md](../RESEARCH_DIARY.md). The source experimental archives and
selectable A/B/C modes stay unchanged. No new API integration is needed for
this writing stage.
