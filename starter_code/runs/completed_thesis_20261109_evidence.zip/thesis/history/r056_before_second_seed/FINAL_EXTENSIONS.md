# Final experimental extensions: dynamic response and a larger LLM cohort

R055/R056, 2026-11-08. These extensions address two different limitations.
R055 is a completed zero-API sensitivity study of dynamic rule responses to
fixed LLM order flow. R056 is a completed, separately frozen six-LLM,
25-session DeepSeek cohort with150 fresh decisions.
The [R054 writing snapshot](history/r054_before_final_extensions/THESIS_DRAFT.md)
preserves the earlier manuscript. No original Qwen study is resumed or pooled.

## R055: what can be dynamic without calling an LLM?

The branch's clearing price, cash, shares, average acquisition cost, executed
trades, income and price history now propagate through all twelve sessions.
Momentum traders use that branch's trend; fundamentalists evaluate its price
against their dividend-based estimate; the maker uses its own evolving inventory.
Rule-agent and auction random generators evolve from the same initial seeds,
and the exogenous dividend sequence is held fixed.

The two LLMs' original accepted orders supply an externally fixed tape. For
Cap10, each taped quantity is capped at ten before being revalidated against
the branch's available cash/shares. Its original side and absolute limit are
retained. For Remove, both accounts retain their endowments but submit HOLD
throughout. No cash or shares are redistributed to the background.

This is a **partly endogenous sensitivity study**: the rule background adapts,
but the LLM tape does not. Future tape orders were generated under factual
histories that may never occur in the branch, and their absolute limits can
become stale. No zero-API replay can establish how the LLM would decide after
seeing a different history. This design extends R054's fixed-book calculation
without claiming to remove that separate behavioral limitation.

The cohort includes all eighteen original R043 paths: three seeds, two model
draws and A/B/C. The uncapped tape first reproduced all 216 factual prices,
ordered trades and 3,024 closing account states. Only after every control passed
were the 36 intervention paths executed. These are twelve-session paths, not
the new 25-session DeepSeek cohort. Repeated removal runs are identical within
each seed across all seven financial CSVs: eighteen executions represent only
**three distinct removal paths**.

The [frozen protocol](../starter_code/runs/dynamic_order_tape_20261108/protocol.json)
has SHA256 `a9c86c42147feef8519614f5df4e8a5e1a1461a977b5bac778d261f6c9c2be77`.
Primary outcomes are the change in population standard deviation of twelve
log-price returns, including the first move from the initial price, and the
fraction of closing sessions with maker inventory at zero or 300. Gap, volume,
drawdown and inventory range are secondary. The protocol contains no favorable
outcome requirement. The analysis retains every path and sign.

## R055 results

| Seed | Intervention | Return SD change (pp) | Maker boundary change (pp) | Mean reference-gap change (pp) | Maximum drawdown change (pp) | Mean volume change (shares) |
|---|---|---:|---:|---:|---:|---:|
| 22853 | cap10 | -0.832777 | +0.000 | -1.134722 | -2.721087 | -51.833 |
| 22853 | remove | -0.804578 | +0.000 | -2.362500 | -2.404420 | -100.667 |
| 23971 | cap10 | -0.658983 | +0.000 | -2.718056 | +0.060722 | -47.833 |
| 23971 | remove | +0.119139 | +0.000 | +0.258333 | +3.128715 | -68.833 |
| 25087 | cap10 | -1.808569 | +0.000 | -8.997222 | -1.010613 | -137.500 |
| 25087 | remove | -1.799691 | +0.000 | -10.820833 | -0.675724 | -182.500 |

Each row averages six contrasts against their own inherited uncapped controls.
The common removal outcome within a seed is reused against six different
controls; these are not six independent removal scenarios.

Capping lowers return variability in 15 of 18 comparisons and raises it in
three. It also narrows the mean valuation gap in 15 and widens it in three,
but these are different endpoints. Maximum drawdown worsens in seven, improves
in ten and ties in one. Removal lowers return variability in twelve comparisons
and raises it in six; its seed23971 mean effects worsen variability, reference
gap and drawdown. No control or intervention reaches a maker inventory boundary.
Consequently, the primary inventory endpoint supplies **no observed improvement**,
not proof of equivalence or a guarantee against exhaustion over longer paths.

The prespecified secondary inventory range also gives mixed evidence. Cap10
changes the mean closing-inventory range by +5.33, -11.83 and -12.00 shares
in seeds22853,23971 and25087, respectively. Lower average return variability
therefore does not imply narrower inventory swings in every scenario. The
[inventory supplement](../starter_code/runs/final_extensions_review_20261108/inventory_sensitivity.json),
[all inventory paths](../starter_code/runs/final_extensions_review_20261108/dynamic_inventory_paths.pdf)
and [all price paths](../starter_code/runs/final_extensions_review_20261108/dynamic_price_paths.pdf)
retain every path. The range metric uses closing sessions; the figures also
show initial inventory150 for context.

The useful new exception is seed22853/C/draw1. In R054, all twelve isolated
caps preserved factual volume, totaling 203 shares. In the dynamic version,
total volume increases to 220 even though target-involved volume falls from97
to82. Return SD increases from1.299688% to1.349699%, mean gap from3.058333% to
3.316667%, and maximum drawdown from0 to1.1%. This is the only volume-increasing
cap path and is identified after analysis as an exception, not a representative
case. It shows why fixed-book monotonicity of executable volume does not extend
to a sequence in which the other traders change their orders.

The [full table](../starter_code/runs/dynamic_order_analysis_20261108/READOUT.md),
[report](../starter_code/runs/dynamic_order_analysis_20261108/report.json) and
[all-path figure](../starter_code/runs/dynamic_order_analysis_20261108/dynamic_contrasts.pdf)
retain the favorable and adverse comparisons. The evidence supports conditional
reductions in short-path variability, not a general stabilizing cap policy or
long-run stylized-fact validation.

## R056 design and provider settings

One fresh seed30841 supplies a 25-session quiet market with six LLM accounts
and eight rule accounts. Two ZI and two momentum slots are replaced; the maker,
three fundamentalists, two remaining ZI and two remaining momentum agents stay.
There are still fourteen accounts, 160,000 initial cash and 1,450 shares. The
six existing fictional library personas are used once each. Mode B retains
five recent verified outcomes and factual summaries, without reflection.

Both the prompt and code limit LLM accepted orders to ten shares. This avoids
relying on prompt compliance and preserves original maker quote depth10,
inventory target150 and inventory limit300. A per-order bound cannot guarantee
balanced directional demand or perpetual liquidity. Any boundary visits,
unfilled orders or adverse price paths remain outcomes, not grounds for tuning.

The original A/B/C implementations and defaults are unchanged. The research
adapter hides the recorded horizon and labels the initial dividend as a prior,
as in the earlier quiet experiments. It uses model
`deepseek/deepseek-v4.1-flash`, endpoint `https://api.goedelmachines.com/v1`,
temperature0.3, maximum output2048, five-outcome memory and180-second timeout.
Thinking is disabled using the provider's documented
`chat_template_kwargs: {thinking: false}`. JSON is requested in the prompt;
no undocumented `response_format` assumption is made. Exact request bodies,
raw replies, returned model identity, token usage and failures are saved.

The named credential is read from `GODEL_MACHINES_API_KEY` and never included
in prompts, logs or archives. The authenticated model listing confirmed the
requested model. The key prefix identifies free access. The provider states
that free/student prompts and outputs are retained and may be used for
training; this was disclosed before execution. No real personal data is in
the fictional simulation payloads. See the [official API documentation](https://inference.goedelmachines.com/docs)
and [plans and limits](https://inference.goedelmachines.com/pricing).

The [frozen protocol](../starter_code/runs/goedel_cohort_20261108/protocol.json)
has SHA256 `6306bfa9b7b99e87db5e8658c8b4b8cba90b8974c4dbcab6c7f0464edb6b0c21`.
Its ceiling is180 HTTP attempts and3million reserved tokens for150 planned
decisions, paced at10requests/minute and60,000 estimated input tokens/minute.
One existing identical transport/503 retry is allowed; JSON repairs are
separately logged. Fatal provider/output/persistent-parse failure stops the
cohort. There is no automatic restart, model substitution or increased cap.

This cohort broadens observed operation to a second provider/model and a
larger LLM population. It **does not identify a cross-model effect**: model,
population composition, cap and horizon differ together from Qwen. One seed
and six personas do not supply independent model replications or a scaling
curve. Twenty-five sessions remain short for market-realism claims.

## R056 completed results

The cohort completed all25 sessions and150 decisions at16:37:32 IST on
2026-11-08. All150 returned model IDs matched the requested DeepSeek model;
there were no provider errors, retries, JSON repairs, truncations, missing
decisions or unknown-usage requests. The provider reported369,984 tokens;
conservative reservations were1,607,502, within the frozen3million ceiling.
No monetary charge is declared for the identified free credential; token
counts are the reported computational usage, not an independently verified bill.

| Outcome | Observed value |
|---|---:|
| Completed sessions / planned | 25/25 |
| Delivered decisions / planned | 150/150 |
| Mean absolute reference gap | 16.06% |
| Log-price-return SD | 2.141060% |
| Maximum price drawdown | 7.277187% |
| Final price / private reference | 113.4 /100 |
| Maker closing inventory minimum /maximum | 66 /191 shares |
| Maker boundary fraction | 0% |
| Total executed volume | 557 shares |
| Volume involving at least one LLM | 336 shares (60.32%) |
| Sessions without trades | 0 |

The population operated without instant inventory exhaustion under the
specified cap, but absence of exhaustion is not evidence that the cap caused
stability: there is no matched uncapped DeepSeek path. All requests already
respected the ten-share ceiling, so no requested quantity needed cap reduction.
Liquidity and valuation also separate: uninterrupted trading and interior
maker inventory coexist with a substantial reference gap.

Executed outcomes differ across the six accounts. Meera requested HOLD in
all25 sessions; Sana requested BUY in all25 but executed only63 shares in
total. These are observations of this model/persona/history bundle, not
identified persona effects or validated psychological traits.

| Trader | Executed buys | Executed sells | Passive excess, auction mark (pp) | Passive excess, reference mark (pp) |
|---|---:|---:|---:|---:|
| Meera Iyer | 0 | 0 | +0.000 | +0.000 |
| Arjun Malhotra | 87 | 70 | +0.145 | -0.994 |
| Prakash Rao | 0 | 51 | +1.793 | +5.210 |
| Sana Sheikh | 63 | 0 | -0.972 | -5.193 |
| Vikram Bose | 87 | 0 | -0.542 | -6.371 |
| Lakshmi Nair | 19 | 0 | +0.201 | -1.072 |

The denominator is each account's initial20,000 auction wealth, and the
passive comparator retains its initial cash/shares with the same interest and
dividends. Meera's floating-point residual is economically zero. Arjun and
Lakshmi change excess-return sign across terminal marks, consistent with the
previous accounting identity rather than a newly discovered return mechanism.
These are six accounts in one coupled market, not six independent experiments.

The [final run summary](../starter_code/runs/goedel_cohort_20261108/summary.json),
[analysis report](../starter_code/runs/goedel_cohort_analysis_20261108/report.json)
and [price/inventory figure](../starter_code/runs/goedel_cohort_analysis_20261108/goedel_path.pdf)
retain the full result. Actual system/user inputs were reconstructed exactly
for all150 decisions, including prices, opening portfolios, factual summaries
and each trader's own five-outcome history. Independent reconstruction covers
350 account-rounds, with maximum individual cash residual7.28e-12; maximum
recorded aggregate cash residual is2.91e-11, below1e-7.

The strongest interpretation is feasibility plus a new bounded descriptive
case: six capped LLM traders can remain active in a25-session mixed market
without exhausting the maker on this scenario, while valuation and individual
passive-relative outcomes remain uneven. It supplies no causal ranking of
DeepSeek versus Qwen, no isolated population-size effect, and no long-run
validation. No additional model, seed or restart is scheduled.

## Verification and housekeeping

Both drivers enforce an absolute cash residual of at most1e-7 at settlement
and closing, alongside exact share conservation. An independent cash/share
reconstruction covers all9,072 R055 account-rounds, including controls. Three
dynamic tests check resource revalidation, removal and changed rule responses.
Four DeepSeek adapter tests include a full150-decision mocked25-session path,
cap enforcement, hidden horizon, model mismatch and credential exclusion.
Mock responses are software test data, never behavioral evidence.

From `starter_code`, use new output folders for offline analysis:

```powershell
python -B -m unittest tests.test_dynamic_order_tape tests.test_final_extensions -v
python -B -m research.analyze_final_extensions dynamic --root runs/dynamic_order_tape_20261108 --output runs/dynamic_reader_01
python -B -m research.analyze_final_extensions live --root runs/goedel_cohort_20261108 --output runs/goedel_reader_01
```

Do not run either campaign again into its completed or already-started root.
The dynamic control/intervention order and source hashes are preserved.

The ten original numbered proposal files were moved byte-for-byte to
[archive/early_proposals](../archive/early_proposals/README.md), with before/after
hashes in the move manifest. The new [root guide](../README.md) directs readers
to the implemented model and completed evidence. Original planning documents
are historical, not instructions or claims that all proposed features exist.
R052 stays closed at8/48; department formatting remains last.
