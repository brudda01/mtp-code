# The thesis argument and its evidence

R054 revision, 2026-11-08. This is a guide to the current argument and its
completed evidence, not an assessment by an external examiner.

## Central argument

Evaluating an LLM-agent market requires following decisions through execution
and accounting, checking several market diagnostics, and comparing policies
from genuinely comparable histories. A favorable price statistic or persuasive
reflection is insufficient to establish better trading or human-market realism.

The thesis makes that argument through three connected result families. The
contribution is the measured, controlled evidence within this environment.
Accounting identities, the possibility of partial fills and the existence of
inventory constraints explain the results; they are not new economic laws.

| Question | Main evidence and what it establishes | What remains unresolved |
|---|---|---|
| What can aggregate measurements miss? | R041 supplies matched news cases with opposing trader responses and transfers at unchanged prices. R050 extends the execution/account-versus-price distinction across all six shared-history contexts. | Frequency in other markets; latent beliefs; general news comprehension or human bias |
| Does improving a return statistic establish better market behavior? | R039 finds lower return dependence but more inventory-boundary time in four paired rule scenarios. R051 repeats both directions in four different scenarios under both tested backgrounds, while retaining adverse valuation paths. | Calibration, optimal settings, other policy bundles and long-run LLM market behavior |
| What does adding reflection change? | R043's apparent advantage predates reflection. R047 controls the actual starting histories and finds mixed subsequent gap and individual-return contrasts, same-mode variation and additional known token use. | A universal benefit or harm, content-versus-length effects, precise average effects across scenarios, and corrected-feedback efficacy |

R052 is an incomplete validation attempt, not a fourth success claim. Eight of
48 planned reflections were delivered before the provider stop; the known
timing-error context was not reached. Preserve its absence of detected target
errors, other arithmetic counterexample and missing coverage together.

## Which evidence deserves emphasis?

R056 adds operational breadth: a separate six-LLM DeepSeek B cohort completes
25sessions and150fresh decisions without failures or inventory exhaustion.
Its16.06%mean reference gap and mark-dependent individual excess returns show
that successful operation is not valuation validation. This is a descriptive
case,not a fourth causal claim family: model,population composition,cap and
horizon change together,and there is only one fresh scenario.

R055 extends the order intervention through dynamic rule responses while
keeping the LLM order tape fixed. Cap10 lowers short-path return variability
in fifteen of eighteen comparisons, but raises it in three and worsens maximum
drawdown in seven. No path reaches a maker boundary, leaving that primary
inventory endpoint uninformative about boundary avoidance. In one path,
dynamic cap volume rises from203to220 even though isolated static caps preserve
volume. This directly qualifies what can be inferred from fixed books. It does
not identify how LLMs would adapt to counterfactual histories. See the
[final extensions](FINAL_EXTENSIONS.md) for all comparisons and the separate
six-agent DeepSeek cohort's design/status.

R054 strengthens the first result family with an intervention on accepted
orders. Cap10 changes prices in49of105 auctions where it reduces an LLM order
(49of216 overall). A high-volume example loses57of60 traded shares when both
LLM orders are suppressed, yet retains the same price; the largest cap price
change instead worsens reference valuation. The contribution is the measured
separation of participation, influence and valuation within these books, not
the general possibility that volume and prices differ. All216 factual auctions
were reproduced before432 isolated interventions. See the
[design, results and scope assessment](ORDER_INFLUENCE.md).

This extends the three-family argument, rather than creating a broad claim of
improved realism. It is exact for the fixed simulated books but does not measure
adaptation or a permanent cap. The three original R043 seeds remain the scenario
coverage;432 calculations are not432 new independent samples.

The market-background result has the strongest replication across fresh
exogenous scenarios: two separate four-seed studies. R051 crosses its four seeds
with two backgrounds, so the combined twelve paired comparisons are not twelve
independent scenarios. Keep the two protocols separate and show their effects;
do not manufacture a pooled causal estimate or a general realism score.

A configuration check of all sixteen homogeneous paths confirms that R039 and
R051 match within each skew setting except for study name and seed; between
skew settings, only the maker's inventory-skew parameter differs. This supports
calling the homogeneous comparison a replication, while the heterogeneous
cells remain an additional sensitivity bundle.

The measurement result has a different strength. A verified matched
counterexample establishes that price equality cannot certify equality of
individual outcomes. It does not estimate the population frequency of that
failure. R050 supplies broader coverage within the six inherited contexts:
11 of 24 cross-mode branch pairs have different target-account paths despite
identical price paths. Those pairs reuse branches and are not independent.

The reflection result is strongest as an identification correction and a
conditional comparison. The R047 context-level C-minus-B gap contrasts range
from -1.3571 to +0.3286 percentage points; two improve, one worsens and three
are equal. This range describes observed contexts, not a confidence interval.
Same-mode variation makes a deterministic ranking implausible in these runs;
it is not a calibrated noise subtraction or a statistical equivalence test.

## Why both terminal marks matter

Let \(s\) be the start of the evaluated interval: session zero for R041 and the
common closing session five for R047. Passive holdings remain \(q_{i,s}\);
passive cash receives the same dividends and interest. For terminal mark \(m\),
the active-minus-passive wealth is

\[
E_i(m)=C_{i,T}-C^{\mathrm{passive}}_{i,T}
       +(q_{i,T}-q_{i,s})m.
\]

With the same initial auction wealth \(W_{i,s}\) as denominator under both marks,

\[
e_i(P_T)-e_i(F_T)
=\frac{(q_{i,T}-q_{i,s})(P_T-F_T)}{W_{i,s}}.
\]

This is an accounting identity, not another treatment effect. Changing the
terminal mark values the same holdings differently; it does not execute a sale
or change realized cash. For a policy contrast, apply the identity within each
branch and then subtract or average. Do not assume different branches share
the same terminal auction price.

For example, the first sign-changing target account under the declared
study/run-path/agent ordering is Meera in R041, seed 20611, original background,
silent condition, draw two. She finishes with 130 shares versus 100 passively,
with price 81.4 and reference 80. The mark difference is \(30(81.4-80)=42\).
Excess wealth is approximately +0.067 at the auction mark (essentially zero)
and -41.933 at the reference mark. This is a transparent illustration, not a
representative effect size or evidence of profitable investment.

The identity was checked against raw terminal accounts and the saved reported
metrics for all 560 account endpoints across the sixteen R041 paths and
twenty-four R047 continuations. Both studies retain their different starting
times and denominators. These checks are internal verification, not fresh
financial samples or independent external validation.

The arithmetic check includes the completed R047 branch excluded from recorded-
response replay because of its recovered provider exception. Reading its saved
account endpoints does not extend the earlier replay guarantee.

In the reported zero-tax, closed-share system, trades transfer cash among
accounts. Uniform cash interest and per-share dividends then give total cash
the same recurrence as the aggregate passive accounts. Consequently,
\(\sum_i E_i(m)=0\) for either common terminal mark within a market, even though
total cash grows through external income. The equivalent return statement is
\(\sum_i W_{i,s}e_i(m)=0\), not necessarily an unweighted sum of percentage
returns. Individual or target-group gains therefore do not establish aggregate
welfare gains.

## How to report uncertainty without overstating precision

- Show every seed, inherited context and draw at its actual level of replication.
  Sessions, accounts and the six pairings of four branches reuse information.
- Keep prespecified comparisons distinct from post-hoc interpretation. R050,
  the terminal-mark illustration and this synthesis do not become prospective
  tests merely because their calculations reproduce exactly.
- Report observed contrasts and their signs. Two provider draws per condition
  do not support a stable variance estimate or universal policy ranking.
- Treat stopped or unattempted conditions as missing. R052's four delivered
  original/corrected pairs are not the planned two-draw, twelve-history study.
- Keep uncertainty about model specification and human validity separate from
  numerical reproducibility. Exact replay cannot settle whether the economic
  assumptions are realistic.

The [saved-evidence ledger](../starter_code/runs/evidence_synthesis_20261107/READOUT.md)
and [machine-readable report](../starter_code/runs/evidence_synthesis_20261107/report.json)
provide the source hashes, all paired background effects, account identities
and selection rule for the illustration.

## Submission priorities

Present these three result families as one investigation of evaluation and
identification. Keep earlier failed pilots and operational checks available in
the appendix without treating the number of attempts as the contribution.
The thesis is strongest as a controlled simulation study with explicit limits.
Human-market validation, calibrated time scales and a demonstrated benefit of
the feedback correction remain open. Student/supervisor judgment about scope,
the author's own explanation of the work and final bibliography review remain
necessary before department formatting.
