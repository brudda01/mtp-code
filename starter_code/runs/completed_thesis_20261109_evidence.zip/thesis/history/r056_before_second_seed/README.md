# Thesis writing workspace

**R055/R056 final extensions (2026-11-08):** The
[extension guide](FINAL_EXTENSIONS.md) separates the completed dynamic rule
response study from the new six-LLM DeepSeek cohort. The former uses fixed
original LLM order tapes and supplies no fresh LLM behavior. R056 completed
all150 fresh decisions and25sessions, without failures;its16.06%mean reference
gap remains explicit despite no maker-boundary visits. Earlier numbered
planning documents now live in [the proposal archive](../archive/early_proposals/README.md);
the [root guide](../README.md) points to current evidence and implemented methods.

**R054 completed (2026-11-08 integration):** [Order size and immediate price influence](ORDER_INFLUENCE.md)
addresses the proposed larger LLM population by first testing the existing
two traders' economic influence. All216 actual auctions pass reconstruction;
432 isolated quantity-cap/order-suppression calculations preserve the other
orders and actual starting states. Price, volume and valuation effects differ.
The draft includes these results, all-seed table and figure. No API calls,
new adaptive market paths or default changes; R052 remains closed.

**R053 evidence synthesis (2026-11-07):** Start with the
[current argument and evidence hierarchy](THESIS_ARGUMENT.md) or the rewritten
[root results brief](../THESIS_RESULTS.md). The draft distinguishes replicated
background effects, matched measurement counterexamples and conditional policy
contrasts. A raw-account check explains terminal-mark differences across560
account endpoints;this is accounting verification,not a new empirical finding.
No new requests or markets were generated;R052 remains closed and incomplete.

**R052 attempted and stopped (2026-11-07):** The approved matched-history
reflection check delivered8of48replies before twoHTTP503attempts stopped the
campaign. All partial/missing results are retained. No evidence of correction
efficacy or equivalence follows;the known timing-error context was not reached.
Read the [frozen design and partial-results assessment](FEEDBACK_VALIDATION_PROTOCOL.md).
No restart or new market study is scheduled.

**R050/R051 completed (2026-11-07):** The draft adds the all-branch execution/feedback audit and16fresh rule-only background-diversity markets. Read [the substantive review and reproduction commands](FEEDBACK_AND_BACKGROUND_REVIEW.md). The timing-labelled A/B/C adapter is implemented and offline-tested;behavioral benefit is untested. The skew trade-off survives the specified diversity bundle in4fresh scenarios,while adverse valuation paths remain explicit. No live model calls or default changes;formatting remains last.

**R049 manuscript review:** Classical heterogeneous expectations,empirical
validation and model-description references now supplement the LLM literature.
The draft clarifies uncalibrated session time and inferable hidden benchmarks.
Read the [scientific review](MANUSCRIPT_REVIEW.md) and
[offline reproduction guide](REPRODUCIBILITY.md). Department formatting is
explicitly deferred until last;scope/voice and final scholarly review come first.

**R048 integration complete:** The draft now includes R047's shared-history
design, all six context contrasts, both traders and terminal marks, costs and
the replay exclusion. It places this result alongside execution measurement
and market-background trade-offs. Read the
[manual interpretation](../starter_code/runs/common_prefix_analysis_20261105/INTERPRETATION.md).
The pre-integration writing is preserved in history/r046_before_common_prefix.

**R046 examiner correction:** The C-B gap advantage already existed in all six
pairs before reflection. Treat that comparison as descriptive,not an identified
reflection benefit. Read [EXAMINER_REVIEW.md](EXAMINER_REVIEW.md) for the critical
claim/realism ranking and demonstrated offline replay,including a dependency
packaging defect. Fresh live replicability and external validity remain open.

**Decision, 2026-11-05: start writing now.** We have a substantive body of
evidence for a focused simulation thesis. More experiments are not the default
next step. Formal submission readiness still requires a complete literature
review, department formatting and supervisor agreement on scope.

Working title: **Execution, Market Design and Information Representation in an
LLM-Agent Stock Market Simulation**. This title is provisional, not a registered
or supervisor-approved title.

Read [THESIS_DRAFT.md](THESIS_DRAFT.md) for the first substantive draft. It covers
the abstract, research questions, implemented methods, experiment designs,
three results sections, discussion and conclusion. The related-work section
now contains a targeted primary-source synthesis;wider coverage remains
unfinished. This is an editable content draft, not a
submission-ready thesis or an assumed university template.

## Claims and evidence

| Question | Current evidence | Defensible claim | Limit |
|---|---|---|---|
| What does a price-only news analysis miss? | R041:16 markets;2 exogenous scenarios;2 model draws;2 market-maker settings;visible/silent downside pairs | Price paths and aggregate flows can conceal individual execution/wealth responses | Initial truthful downside news;no human or universal news-response validation |
| Does one better market statistic establish realism? | R039:4 fresh paired600-session rule scenarios;R051:4different scenarios crossed with2backgrounds;fixed historical return reference | The inventory trade-off persists in both studies;heterogeneity can also worsen valuation gaps severely | Separate protocols;12pairs are not12independent scenarios;no calibrated realism target |
| Do summaries/reflection improve results? | R043:18 A/B/C markets;R047:24 B/C continuations from6 actual histories within the same3 scenarios | Apparent C advantages preceded reflection;shared-history gap contrasts improve2/worsen1/equal3 contexts,with same-mode variation and mixed individual returns | Conditional short paths,2 draws/mode,no length-matched sham;no universal benefit or harm |

The complete contrast tables and source paths are linked in the draft.
[THESIS_ARGUMENT.md](THESIS_ARGUMENT.md) explains the different evidential roles,
observed ranges,terminal-mark identity and unresolved feedback correction.
[sources.json](sources.json) pins the draft's local evidence/code inputs.
Old conditional A/B/C, partial markets and ambiguous-headline studies belong
in the development history/appendix; they are not pooled with the final cohorts.

## Writing checklist

- [x] Choose a claim scope supported by completed evidence.
- [x] Draft abstract, introduction, implemented methods and study designs.
- [x] Draft all three result families with negative/mixed outcomes and costs.
- [x] Draft discussion, limitations and conclusion.
- [x] Link existing exportable figures and raw-source readouts.
- [x] Targeted primary-source review of institutions,stylized facts,EconAgent,
  StockAgent,TwinMarket and StockSim,with pinned versions/access limits in
  [LITERATURE_REVIEW.md](LITERATURE_REVIEW.md).
- [x] Working [bibliography](references.bib) and
  [figure/appendix source map](FIGURES_AND_APPENDICES.md).
- [x] Integrate controlled continuations, same-mode variation, both-mark
  returns and incomplete usage/replay reporting into the whole draft.
- [x] Credit recent replay/fixed-history precedents with explicit abstract-only
  review limits; do not claim architectural novelty.
- [x] Add targeted classical/empirical-validation/model-description references,
  model-to-code map and a concrete offline recorded-output reproduction route.
- [ ] Extend the classical/validation literature coverage and finalize
  author metadata/publication versions before claiming novelty or submission.
- [ ] Review the framing with the supervisor: are within-model methodological
  findings sufficient for the intended thesis, or is a specific human benchmark
  required? This is a scope discussion, not a reason to postpone drafting.
- [ ] Apply actual department title-page/template/page-limit/citation rules
  when supplied. Do not infer them from the old semester plans.
- [x] Add [selected actual prompts/personas](appendix/SELECTED_PROMPTS.md)
  with source hashes,initial B/C equality and deterministic selection.
- [ ] Complete final appendix arrangement and full older-pilot inventory,
  without secrets or invented missing data.
- [ ] Revise in the student's voice, review captions/equations and complete
  the final cross-reference/bibliography/layout pass.

The [principal-study inventory](appendix/STUDY_INVENTORY.md) identifies all four
designs, inherited contexts, model settings, failures, replay coverage and exact
source receipts. Final appendix ordering remains unfinished.

Run `python thesis/verify_writing.py` from the repository root to check the
new tables against preserved reports, source/archive hashes, exact selected
prompts, bibliography records and current local links. This writes checks.json
without model calls or new markets. It reads archived replay receipts rather
than rerunning those replays. The preserved experiment artifacts and archives
must be present at the indexed relative paths; the writing snapshot alone is
not a replacement for them.

A new experiment needs a specific missing claim, a bounded protocol and a
clear reason existing evidence cannot answer it. Do not add herding, policy,
human-bubble replication or model-provider grids just to match old outlines.

The writing decision and future meaningful revisions belong in
[RESEARCH_DIARY.md](../RESEARCH_DIARY.md). The source experimental archives and
selectable A/B/C modes stay unchanged. No new API integration is needed for
this writing stage.
