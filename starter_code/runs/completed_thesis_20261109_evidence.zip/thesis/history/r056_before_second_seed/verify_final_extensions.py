"""Stdlib checks of saved R055/R056 reports and proposal relocation."""
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
REPO=HERE.parent
BASE=REPO/'starter_code'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def check():
    for name in ('dynamic_order_tape_20261108','goedel_cohort_20261108'):
        root=BASE/'runs'/name;p=read(root/'protocol.json')
        assert digest(root/'protocol.json')==read(root/'preparation.json')['protocol_sha256']
        assert digest(root/'source.zip')==p['source_zip_sha256']
        for n,h in {**p['source_sha256'],**p['inputs_sha256']}.items():assert digest(BASE/n)==h,n
        for n,h in read(root/'output_manifest.json').items():assert digest(root/n)==h,n
    dynamic_root=BASE/'runs/dynamic_order_tape_20261108';live_root=BASE/'runs/goedel_cohort_20261108'
    assert read(dynamic_root/'gate_summary.json')['status']=='passed'
    assert read(dynamic_root/'summary.json')['dynamic_paths']==36
    d=read(BASE/'runs/dynamic_order_analysis_20261108/report.json')
    assert d['controls']==18 and len(d['contrasts'])==36 and d['account_rounds_rechecked']==9072
    assert d['all_maker_boundary_fractions_zero'] and d['distinct_removal_paths']==3
    assert d['signs']['cap10']['price_return_sd_pct']=={'lower':15,'higher':3}
    assert d['signs']['cap10']['max_drawdown_pct']=={'lower':10,'higher':7,'equal':1}
    guide=(HERE/'FINAL_EXTENSIONS.md').read_text(encoding='utf-8');draft=(HERE/'THESIS_DRAFT.md').read_text(encoding='utf-8')
    for r in d['seed_summaries']:
        x=r['mean_delta'];row=f"| {r['seed']} | {r['condition']} | {x['price_return_sd_pct']:+.6f} | {100*x['maker_boundary_fraction']:+.3f} | {x['mean_gap_pct']:+.6f} | {x['max_drawdown_pct']:+.6f} | {x['volume']:+.3f} |"
        assert row in guide and row in draft,row
    v=d['cap_volume_increase_examples'];assert len(v)==1 and v[0]['original']['volume']==203 and v[0]['intervention']['volume']==220
    for name in ('dynamic_order_analysis_20261108','goedel_cohort_analysis_20261108'):
        root=BASE/'runs'/name
        for n,h in read(root/'output_manifest.json').items():assert digest(root/n)==h,n
    s=read(live_root/'summary.json');r=read(BASE/'runs/goedel_cohort_analysis_20261108/report.json')
    assert s==r['summary'] and s['delivered_decisions']+s['missing_decisions']==150
    assert s['usage']['requests_made']<=180 and s['usage']['reserved_tokens']<=3000000
    assert r['own_history_messages_checked']==s['delivered_decisions']
    assert r['complete_actual_input_pairs_checked']==s['delivered_decisions']
    assert r['audit']['account_rounds']==14*s['completed_rounds']
    assert len(r['per_persona'])==6 and r['independent_scenarios']==1
    if s['status']=='completed':assert s['completed_rounds']==25 and s['delivered_decisions']==150
    for a in r['per_persona']:
        m=a['account']['marks']
        row=f"| {a['name']} | {a['bought']} | {a['sold']} | {100*m['auction']['excess_return']:+.3f} | {100*m['regime_benchmark']['excess_return']:+.3f} |"
        assert row in draft and row in guide,row
    assert r['metrics']['volume']==557 and r['metrics']['target_union_volume']==336
    assert r['metrics']['maker_min']==66 and r['metrics']['maker_max']==191
    assert abs(r['metrics']['mean_gap_pct']-16.06)<1e-10 and r['metrics']['terminal_price']==113.4
    assert s['usage']['requests_made']==150 and s['usage']['provider_reported_tokens']==369984
    assert s['usage']['unknown_usage_requests']==0 and s['usage']['reserved_tokens']==1607502
    assert 'R056' in draft and 'cross-model' in draft
    review=BASE/'runs/final_extensions_review_20261108'
    for n,h in read(review/'render_manifest.json').items():assert digest(review/n)==h,n
    inventory=read(review/'inventory_sensitivity.json')
    assert len(inventory['contrasts'])==36
    cap_inventory=[r for r in inventory['seed_summary'] if r['condition']=='cap10']
    assert [round(r['mean_closing_inventory_range_change'],2) for r in cap_inventory]==[5.33,-11.83,-12.0]
    moved=read(REPO/'archive/early_proposals/move_manifest.json');assert len(moved['files'])==10
    for f in moved['files']:
        assert not (REPO/f['source']).exists()
        assert digest(REPO/f['destination'])==f['sha256']
    before=HERE/'history/r054_before_final_extensions'
    for n,h in read(before/'snapshot_manifest.json')['files'].items():assert digest(before/n)==h,n
    return dict(r055_reconstructed_control_paths=18,r055_dynamic_executions=36,r055_unique_removal_paths=3,
        r055_account_rounds=9072,r055_seed_table_rows=6,r055_new_api_requests=0,
        r056_status=s['status'],r056_completed_rounds=s['completed_rounds'],r056_delivered_decisions=s['delivered_decisions'],
        r056_http_attempts=s['usage']['requests_made'],r056_own_history_messages=r['own_history_messages_checked'],
        r056_account_rounds=r['audit']['account_rounds'],r056_both_mark_rows_checked=6,
        early_proposal_files_moved_and_hash_verified=10)


if __name__=='__main__':print(json.dumps(check(),indent=2))
