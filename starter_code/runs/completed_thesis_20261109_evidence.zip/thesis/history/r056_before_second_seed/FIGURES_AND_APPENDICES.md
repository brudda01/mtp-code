# Figure captions and reproducibility appendix map

Draft captions,2026-11-05. All linked figures already exist;no new experiment
or image is generated here. Figure numbers remain provisional until formatting.

## Main-text figures

**Figure1: implemented information and settlement sequence.**
Use this code-native diagram in the methods chapter. Its arrows indicate
implemented timing,not an empirical result.

```mermaid
flowchart LR
  E[Scheduled effects and permitted public information] --> O[Opening accounts and past observations]
  O --> A[Agent requests]
  A --> V[Cash and share validation]
  V --> C[Batch clearing and actual fills]
  C --> S[Settlement]
  S --> D[Dividend and interest payments]
  D --> H[Verified outcomes and account logs]
  H --> O
  H --> R[C only: reflection when due]
  R --> O
```

**Figure2: executed news contrasts.**
[Exportable PDF](../starter_code/runs/downside_confirmation_analysis_20261104/figure_v2/executed_responses.pdf).
Visible-minus-silent executed net purchases during sessions1–3,shown for each
LLM trader and their combined flow in every designated R041 comparison.
Negative values include additional sales and avoided purchases. Comparisons
nest in two exogenous scenarios,two model draws and two maker settings;they
are not eight independent scenario replications. The figure preserves the
zero case and opposing individual signs.

**Figure3: background-market sensitivity.**
[Exportable PDF](../starter_code/runs/thesis_synthesis_20261105/background_tradeoff.pdf).
Original versus zero inventory skew in four fresh600-session rule-market
scenario pairs. Full-path lag-one price-return dependence falls in each pair,
while time at empty/full maker inventory increases. Lines connect matched
exogenous scenarios;neither setting is selected as a realistic default.

**Figure4: component market-gap and token contrasts.**
[Exportable PDF](../starter_code/runs/quiet_components_analysis_20261105/component_contrasts.pdf).
All B-A and C-B draw contrasts for whole-path mean valuation gap and reported
tokens in R043. Points are two model draws nested within each of three
exogenous scenarios;horizontal bars are within-scenario means. The accompanying
return table must retain both traders and both terminal marks,because a lower
gap does not imply better individual returns. No universal agent ranking follows.
This is a descriptive whole-path comparison: C's gap advantage already existed
before reflection in all six paired draws. Place the pre-reflection table and
the controlled follow-up beside it; the figure does not identify a reflection
benefit.

**Figure5: shared-history reflection contrast and same-mode variation.**
[Exportable PDF](../starter_code/runs/common_prefix_analysis_20261105/common_prefix_contrasts.pdf).
Each context is one actual five-session B history, followed by two fresh B and
two fresh C continuations. Blue points show C-mean minus B-mean valuation gap
over sessions6-12; grey crosses and orange plus signs show B1-B2 and C1-C2.
Negative blue values indicate smaller C gaps. All six contexts are retained,
nested within three exogenous scenarios. Same-mode contrasts are descriptive,
not confidence intervals or equivalence tests. Equal means need not imply equal
paths or account outcomes. Include the all-context both-mark return table and
the known-usage/failure caveat in the accompanying text.

## Supporting material and appendix selections

R056 Figure10: [Six-LLM DeepSeek price and inventory path](../starter_code/runs/goedel_cohort_analysis_20261108/goedel_path.pdf).
One separately frozen capped B cohort,25sessions. Maker inventory remains
interior while the price departs substantially from the private reference.
This is not a matched model/count comparison or validation of human realism.

R055 Figure9: [Dynamic fixed-tape contrasts](../starter_code/runs/dynamic_order_analysis_20261108/dynamic_contrasts.pdf).
All eighteen inherited paths are shown for cap10 and joint removal. Negative
values indicate lower return SD or reference gap relative to the respective
uncapped control. The eighteen removal executions are three unique paths
reused against different controls. LLM choices remain fixed; no human-market
or long-run stability inference follows. All inventory-boundary fractions are
zero, so that endpoint is reported as uninformative about boundary avoidance.

| Appendix item | Exact existing source | Selection rule / qualification |
|---|---|---|
| All R041 paired price paths | [Paired paths PDF](../starter_code/runs/downside_confirmation_analysis_20261104/paired_paths.pdf) | All designated pairs,not only illustrative transfer case |
| R041 transfer/opposing-response audit | [Mechanism audit](../starter_code/runs/downside_confirmation_analysis_20261104/mechanism_audit.json) | Identified post-hoc examples,with all8 first-visible Arjun cases retained |
| R039 all price/inventory paths | [Full paths PDF](../starter_code/runs/20261104_154730_market_validation_fff53e3b/supplement/price_inventory_paths.pdf) | All4 scenario pairs,including late deterioration and exceptions |
| R043 all primary contrasts | [Readout](../starter_code/runs/quiet_components_analysis_20261105/READOUT.md) | All12 prespecified contrasts;no preferred draw selection |
| R043 prompt/config/persona provenance | [Frozen protocol](../starter_code/runs/20261105_012335_quiet_components_5066abab/protocol.json) | Follow its run index to exact messages and personas;never reconstruct from memory |
| R047 all continuations and conditional returns | [Full report](../starter_code/runs/common_prefix_analysis_20261105/report.json) | All24branches,6inherited contexts,3scenarios;post6-12gap and common5passives,not pooled with R043whole paths |
| R047 actual prefix/request/source provenance | [Frozen protocol](../starter_code/runs/20261105_041035_common_prefix_ca10f93d/protocol.json) | Includes128source files,donor hashes,randomized schedule;240cached deliveries not fresh data |
| R047 verification and exclusion | [Replay report](../starter_code/runs/common_prefix_analysis_20261105/replay_report.json) | 23paths/161CSVmatches;one recovered-error completed path explicitly excluded |
| Principal study/missingness inventory | [Appendix inventory](appendix/STUDY_INVENTORY.md) | Distinguish live completion,recorded-response reproduction and external validity |
| Older conditional/component evidence | [Final conditional readout](../starter_code/runs/component_final_analysis_20261103/READOUT.md) | Keep107valid/1missing and shared-A-history limitations |
| Earlier endogenous component evidence | [Sequential readout](../starter_code/runs/sequential_final_analysis_20261104/READOUT.md) | Keep two partial Cmarkets,old news/horizon settings and cancelled choice |

The [selected prompt appendix](appendix/SELECTED_PROMPTS.md) now copies the
first prespecified R043 scenario/draw's actual persona records and Meera's
initial A/B/C inputs,first Creflection and following decision. The
[exact JSON/source hashes](appendix/selected_prompts.json) preserve the strings
and confirm initial B/C equality. Later C history is its own,not a constructed
identical-state C/B comparison. Reflection text represents generated beliefs,
not verified facts. Broader prompt/persona inventory remains available in raw
artifacts rather than being duplicated in full here.

The full experimental ledger and earlier negative/incomplete work remain in
[RESEARCH_DIARY.md](../RESEARCH_DIARY.md). Routine API recovery and packaging
checks support reproducibility;they need not become headline research figures.
No human-bubble,social-herding or tax-policy chapter is implied by this map.


## R050/R051 substantive additions

R054 adds Figure8: [Conditional order influence, all eighteen paths](../starter_code/runs/order_influence_analysis_20261107_v2/order_influence.pdf).
The left panel counts changed prices among each path's twelve actual auctions;
the right shows reduction in summed execution volume. Blue caps each accepted
LLM quantity at10; orange suppresses both orders. Each intervention starts
from the actual state, so these are not hypothetical market trajectories.
See [the design and interpretation](ORDER_INFLUENCE.md) for denominators,
mixed gap effects and transparently selected examples.

- Figure6: [R051 all-case contrasts](../starter_code/runs/background_diversity_20261106/review/background_diversity.pdf). Four fresh exogenous seeds;skew-removal ACF1/boundary contrasts under both backgrounds,and heterogeneity-induced gap changes under each skew. Points are paired outcomes,not confidence intervals.
- Figure7: [All16 price/inventory paths](../starter_code/runs/background_diversity_20261106/review/all_paths.pdf). Include adverse29671 heterogeneous/original-skew path;no outcome selection. Sessions have no calibrated daily interpretation.
- Appendix: [all48 reflection texts and contemporaneous contexts](../starter_code/runs/feedback_audit_20261106/reflection_ledger.json), [focused review annotations](../starter_code/runs/feedback_audit_20261106/reflection_review.json), [all36 dependent execution comparisons](../starter_code/runs/feedback_audit_20261106/report.json). No additional independent model samples.
