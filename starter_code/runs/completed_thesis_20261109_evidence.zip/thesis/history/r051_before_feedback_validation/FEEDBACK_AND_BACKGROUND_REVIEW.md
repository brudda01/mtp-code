# R050/R051: feedback semantics, execution and background diversity

Completed scientific work began2026-11-06;manuscript integration/review2026-11-07.
User authorized beneficial thesis work after the examiner-style review and then
said to carry on. Department formatting remains deferred.

## What changed and what the evidence establishes

R050 audits every existing R047 branch. Every one of the six contexts contains
different target-account trajectories with identical price trajectories. Of24
cross-mode pairs,22differ in accounts but only11in prices. These pairs share
branches and are not independent observations. In the first new auction,14
cross-mode pairs differ in requested orders but only2in price. Later states
diverge endogenously,so this is not a causal mediation estimate.

Focused AI-assisted analyst review of all48reflections identifies5temporal
misattributions in one inherited context and2unsupported fill-guarantee claims
in one other branch. This is a narrow,post-hoc review,not blinded human coding
or a general hallucination rate. All texts,negative coding decisions and exact
source lines are retained in the [ledger](../starter_code/runs/feedback_audit_20261106/reflection_ledger.json)
and [review annotations](../starter_code/runs/feedback_audit_20261106/reflection_review.json).

The central timing example is Meera23971/source2:the latest available decision5
price was103.3;clearing subsequently produced104.0. Reflection erroneously blamed
the earlier explanation for not using104.0. The later reflection repeats this
kind of self-correction. The financial records are correct;the generated
interpretation is not. No study here establishes that this wording caused the
financial C-B differences.

The new [timing-labelled adapter](../starter_code/sim/timed_feedback.py) captures
the actual pre-decision price/account before the request. It separates those
from clearing/post-settlement records,removes explanations from factual order
fields,and explicitly labels generated prose unverified. Reflection receives
the same exchange constraints,including the absence of guaranteed fills.
AllA/B/C modes use the same new factual schema. Fixed-reply tests preserve
economic outputs;the adapter rejects feedback without a corresponding decision
snapshot. This is implemented and offline-verified,not behaviorally validated.
Existing v2agents/defaults and every frozen source file remain unchanged.

R051 tests one joint background-heterogeneity bundle on4fresh exogenous seeds,
crossed with inventory skew.02/0. The16rule-only paths complete600sessions each.
The original inventory trade-off survives under both backgrounds in all4seeds:
skew removal reduces price-return ACF1 but raises inventory-boundary time.
The ACF reduction is greater under the heterogeneous bundle in all4.

The bundle is not a general improvement. With original skew,the heterogeneous
gap is worse in all4scenarios. In29671 it reaches21.003% versus6.690% in the
homogeneous market,and the price ends217.5 versus a constant100benchmark.
The final200-session block has gap54.866% despite near-zero return ACF1.0022.
All4fundamentalist accounts have zero shares by450 and cannot short. This
sequence is consistent with constrained corrective trading,not an isolated
causal test of inventory depletion. No parameter default is changed.

The intervention changes F3thresholds.03/.03/.03 to.02/.03/.04 and M4lookbacks
5/5/5/5 to3/4/6/7. It retains mean settings,not realized trading intensity.
It neither isolates one component of heterogeneity nor calibrates human
behavior. Initial accounts,agent RNG positions and dividend paths match within
seed. Both marks,all accounts and three nested time blocks remain in the
[full report](../starter_code/runs/background_diversity_20261106/report.json).

## Verification and reproduction

The complete offline regression suite passed176tests in30.809seconds,including
6new feedback tests and2new diversity-design tests. Initial restricted-runner
attempts exposed Python3.13Windows temporary-directory ACL restrictions;the
full suite passed under normal permissions. A new adapter test initially
compared class labels as financial data;the corrected check verifies unchanged
financial fields while retaining the explicitly different adapter class label.
These development failures did not alter or rerun scientific outcomes.

Independent arithmetic reconstruction checked134400new account-rounds against
initial resources,trades,payouts and interest,maxcash discrepancy5.60e-10.
The [verification receipt](../starter_code/runs/feedback_audit_20261106/verification.json)
also checks source/config/output hashes,48original reflection records and that
account-path distinctions survive cash rounding to5decimal places.

From `starter_code`,read-only numerical verification:

```text
python -B -m research.verify_followup
```

To regenerate the retrospective audit into a NEW directory:

```text
python -B -m research.feedback_audit --output runs/feedback_reader_01
```

This generates all-case tables and original-text ledger. The focused manual
annotations are separately retained;they are not produced by an automatic
error classifier. The source hashes in report.json pin the inputs.

To reproduce the deterministic rule study into a NEW directory:

```text
python -B -m research.background_diversity prepare --study runs/diversity_reader_01
python -B -m research.background_diversity run --study runs/diversity_reader_01
```

For an exact frozen-source replay with byte comparisons:

```text
python -B -m research.replay_diversity --output runs/diversity_reader_replay_01
```

This command was actually executed locally into runs/diversity_replay_20261107:
16paths and112financial CSVs matched byte for byte,with zero worker network
attempts. The [receipt](../starter_code/runs/diversity_replay_20261107/receipt.json)
distinguishes this local reproduction from fresh scenarios and independent-machine
reproduction. The replay extracts the pinned archive and removes exported
credential variables before launching its isolated worker.

The original [protocol](../starter_code/runs/background_diversity_20261106/protocol.json)
and source.zip pin the executed implementation. These commands block network
and live-client access and retain failures. A rerun regenerates these same
deterministic scenarios;it does not add independent scientific evidence.
Do not run into the completed original directory. This stage has not claimed
an independent-machine reproduction or additional replay coverage for older
LLM studies.

Opt-in use of corrected feedback in a NEW study:

```python
from sim import engine
from sim.timed_feedback import timed_feedback

with timed_feedback():
    engine.run("new_study_config.yaml", output_root="runs")
```

This example follows the config's provider;use a mock config for offline work.
Any future live comparison needs its own frozen protocol and budget. The adapter
can wrap an existing common disclosure adapter;it does not itself alter news,
horizon disclosure,initial priors or sampling. Do not nest concurrent studies
inside this process-wide adapter. Class identity differs but economics do not.

## Thesis interpretation and next decision

The draft now integrates the execution distinctions,timing problem and diversity
results. Human-market positioning also adds Henning etal.,arXiv2502.15800v3;
Sections3-4 were reviewed and no external implementation/data were reproduced.
The original R049writing snapshot is in history/r049_before_feedback_review.

The most useful next live question,if pursued,is whether explicit feedback
timing reduces these particular false self-corrections on matched saved
histories. It should first be a bounded representation check,not a large
profitability sweep. That live validation remains unperformed and no automatic
campaign is scheduled. Human-realism validation,order-size sensitivity and
independent-reader reproduction remain separate open work. The present stage
adds genuine bounded evidence without choosing a favorable-looking default.
