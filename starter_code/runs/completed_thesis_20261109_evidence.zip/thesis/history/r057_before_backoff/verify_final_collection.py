"""Standard-library verification of closed data and missing second-seed outcomes."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent
BASE = REPO / 'starter_code'


def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def check():
    frozen = read(REPO / 'DATA_COLLECTION_FROZEN.json')
    assert frozen['status'] == 'permanently_frozen'
    assert frozen['completed_deepseek_scenarios'] == 1
    root = BASE / 'runs/final_collection_analysis_20261108'
    for name, expected in read(root / 'output_manifest.json').items():assert digest(root / name) == expected, name
    report = read(root / 'report.json')
    assert report['completed_scenarios'] == 1 and report['attempted_scenarios'] == 2
    assert report['seed31991_market_metrics'] is report['two_seed_mean'] is report['two_seed_contrast'] is None
    assert report['seed31991_delivered_decisions'] == 1 and report['seed31991_missing_decisions'] == 149
    totals = dict(requests_made=0, reserved_tokens=0, provider_reported_tokens=0, unknown_usage_requests=0)
    for index, item in enumerate(report['attempts']):
        path = BASE / item['root'];protocol = read(path / 'protocol.json')
        assert digest(path / 'protocol.json') == read(path / 'preparation.json')['protocol_sha256'] == item['protocol_sha256']
        assert digest(path / 'source.zip') == protocol['source_zip_sha256']
        assert digest(path / 'config.yaml') == protocol['config_sha256']
        for n,h in {**protocol['source_sha256'], **protocol['inputs_sha256']}.items():assert digest(BASE / n) == h, n
        for n,h in read(path / 'output_manifest.json').items():assert digest(path / n) == h, n
        assert read(path / 'summary.json') == item['summary']
        pin = next(x for x in frozen['studies'] if x['root'] == path.relative_to(REPO).as_posix())
        assert pin['protocol_sha256'] == item['protocol_sha256']
        assert pin['output_manifest_sha256'] == digest(path / 'output_manifest.json')
        if index:
            assert item['summary']['status'] == 'stopped' and item['summary']['completed_rounds'] == 0
            assert item['audit']['account_rounds'] == 0 and item['market_metrics'] is None
            assert item['http_errors'][0]['http_status'] == 429
            for key in totals:totals[key] += item['summary']['usage'][key]
        assert item['complete_actual_input_pairs_checked'] == item['summary']['delivered_decisions']
    assert totals == dict(requests_made=3,reserved_tokens=16592,provider_reported_tokens=803,unknown_usage_requests=2)
    for key, value in totals.items():assert report['seed31991_usage'][key] == value
    table = (root / 'availability_table.md').read_text(encoding='utf-8').strip()
    for name in ('THESIS_DRAFT.md', 'FINAL_COLLECTION.md'):
        assert table in (HERE / name).read_text(encoding='utf-8'), name
    draft = (HERE / 'THESIS_DRAFT.md').read_text(encoding='utf-8')
    assert 'one completed market scenario' in draft and 'permanently frozen' in draft
    before = HERE / 'history/r056_before_second_seed'
    for name, expected in read(before / 'snapshot_manifest.json')['files'].items():assert digest(before / name) == expected, name
    # The production entry points, not just documentation, must retain the guard.
    for name in ('goedel_second_seed.py', 'goedel_seed2_transport_amendment.py'):
        text = (BASE / 'research' / name).read_text(encoding='utf-8')
        assert 'DATA_COLLECTION_FROZEN.json' in text and 'permanently frozen' in text
    guards = read(BASE / 'runs/final_collection_verification_20261108/guard_checks.json')
    assert guards['status'] == 'passed' and len(guards['checks']) == 2
    assert guards['new_provider_calls'] == guards['new_market_paths'] == 0
    assert guards['freeze_sha256'] == digest(REPO / 'DATA_COLLECTION_FROZEN.json')
    assert all(x['result'] == 'blocked_by_permanent_freeze_before_worker' and x['output_manifest_unchanged'] for x in guards['checks'])
    return dict(collection_status='permanently_frozen', r056_completed_scenarios=1,
        final_seed31991_status='stopped_before_first_auction', final_seed31991_decisions=1,
        final_seed31991_missing_decisions=149, final_seed31991_completed_rounds=0,
        final_seed31991_http_attempts=3, final_seed31991_known_tokens=803,
        final_seed31991_unknown_usage_errors=2, final_seed31991_actual_input_pairs_checked=1,
        final_seed31991_market_metrics_missing=True, final_seed31991_protocol_amendment_disclosed=True)


if __name__ == '__main__':print(json.dumps(check(), indent=2))
