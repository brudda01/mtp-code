# Thesis results: current evidence and argument

**Final closure, 2026-11-08:** the requested R056 seed31991 supplied no market
path. An original first-request HTTP429 and one disclosed re-entry yielded
one valid reply, zero cleared rounds and149 missing decisions. R056 remains
one completed scenario, seed30841. Data collection is permanently frozen.
[Full attempt accounting and missing results](thesis/FINAL_COLLECTION.md).

Updated 2026-11-08 (R057 final collection closure; R055/R056 results retained). This brief replaces the older accumulating summary;
its previous version is preserved in
[the R052 writing snapshot](thesis/history/r052_before_evidence_synthesis/root_THESIS_RESULTS.md).
R054 adds432 conditional auction calculations from saved orders; no new
adaptive market paths or model requests. The pre-extension brief is preserved
in [the R053 writing snapshot](thesis/history/r053_before_order_influence/root_THESIS_RESULTS.md).

The working thesis is **Execution, Market Design and Information Representation
in an LLM-Agent Stock Market Simulation**. Its central question is how the
market mechanism, measurement choices and policy comparisons affect conclusions
about LLM agents. The contribution is a set of controlled simulation findings,
with explicit limits; human-market realism and universal LLM superiority have
not been established.

Read the [thesis argument](thesis/THESIS_ARGUMENT.md) for the evidence hierarchy,
replication units and accounting interpretation, or the
[full draft](thesis/THESIS_DRAFT.md) for methods, results and literature.

The final requested extensions are complete. R055 adds36 dynamic fixed-tape
intervention executions after18 factual controls. R056 separately completes
six DeepSeek traders over25sessions:150fresh decisions/150HTTP,369,984reported
tokens,zero failures/retries/repairs/missing. It trades557shares,with336involving
LLMs;maker inventory stays66-191,but mean reference gap is16.06% andfinal
price113.4 against100. Its single scenario changes model,population,cap and
horizon together,so no isolated model/scaling effect follows. The original
numbered root proposals now live in [the historical archive](archive/early_proposals/README.md).

## 1. Prices and aggregate flow can hide individual responses

R055 now propagates branch state through twelve sessions while rule bots adapt
and the original LLM order tape remains fixed. Capping reduces return SD in15
of18 comparisons and raises it in3;maximum drawdown worsens in7. All maker
boundary fractions are zero, so no boundary-avoidance improvement is observed.
One path's volume rises203to220 dynamically although static caps preserve its
volume. The18 removal executions are only3unique financial paths. This is
conditional rule-response evidence,not adaptive LLM behavior. The
[extension guide](thesis/FINAL_EXTENSIONS.md) also records the separately frozen
six-LLM,25-session DeepSeek cohort;it is not pooled with the Qwen comparisons.

R054 extends this result family by reducing the two LLMs' accepted quantities
in all216 R043 auctions. Cap10 changes prices in49of105 affected auctions
(49of216 overall). Joint order suppression changes74of216 prices, while
reducing summed executed volume25.73%. One case loses57of60 traded shares
but keeps exactly the same price; another cap moves price from98.6to90.1,
worsening the gap to the100reference. All eighteen paths have a price-changing
cap intervention. These results distinguish economic participation, immediate
price influence and valuation quality. They do not estimate permanent-cap
adaptation or the effect of increasing LLM count. Read the
[design, results and assessment of the suggested extensions](thesis/ORDER_INFLUENCE.md).

R041 completed sixteen downside-news markets: two exogenous scenarios, two
model draws, two market-maker settings and visible/silent pairs. Both members
of each pair experienced the same permanent dividend-mean reduction; only the
visible condition received the bulletin. The early combined executed-flow
contrast was negative in seven of eight paired comparisons and zero in one.
These are comparisons nested within two scenarios, not eight independent seeds.

The more informative observations are at the individual level:

- In seed 21727, draw two, original background, Meera's contrast was -90 shares
  and Arjun's +87. The combined -3 conceals their opposing responses.
- In seed 20611, draw two, no-skew background, visible and silent closing-price
  and payout paths matched. The silent market nevertheless included a 50-share
  transfer from Arjun to Meera at 92.8. Individual passive-relative wealth
  changed in opposite directions while non-target accounts matched.

R050 then inspected all twenty-four R047 branches. Every one of its six
inherited contexts contains distinct target-account paths with identical price
paths. Eleven of the twenty-four cross-mode pairs show that combination. Pair
comparisons share branches and are not independent observations or a causal
mediation estimate.

The useful finding is the documented measurement failure in these experiments,
not discovery of the general possibility of transfers at unchanged prices.
Requested orders, accepted orders, fills, counterparties and account outcomes
are needed to interpret what an agent actually changed. HOLD can represent
avoiding a transaction, and an accepted market order can remain partly unfilled.

Sources: [R041 interpretation](starter_code/runs/downside_confirmation_analysis_20261104/INTERPRETATION.md),
[R050 full audit](starter_code/runs/feedback_audit_20261106/report.json),
[R053 source-checked synthesis](starter_code/runs/evidence_synthesis_20261107/report.json).

## 2. A better return statistic can coexist with worse market behavior

R039 removed market-maker inventory skew in four paired 600-session rule
scenarios. Return autocorrelation fell in all four, while time at empty/full
maker inventory increased in all four. Turnover and valuation outcomes had
exceptions, and three nested time-block contrasts reversed the whole-path
correlation direction. No-skew was retained as a sensitivity, not a better default.

R051 repeated the skew comparison on four different exogenous seeds, under both
homogeneous and less synchronized background rules. Both directions persisted
in all four seeds under each background. This strengthens the specified
trade-off. It is two separate four-seed studies, with the second crossing
backgrounds; the resulting twelve pairs are not twelve independent scenarios.
The [all-seed ledger](starter_code/runs/evidence_synthesis_20261107/READOUT.md)
keeps the studies and settings separate rather than pooling their effects.

Heterogeneity itself did not ensure improvement. At original skew, it worsened
the mean valuation gap in all four R051 scenarios. The adverse seed 29671 path
ended at 217.5 against a benchmark of 100; its last 200 sessions had a 54.866%
mean gap despite return autocorrelation of about 0.0022. All four fundamentalists
held zero shares from session 450 onward. Constrained corrective selling is a
plausible interpretation, not an isolated causal mechanism test.

The fixed historical US portfolio reference also showed a mismatch in
absolute-return persistence. It is descriptive context, not a calibrated target
for one small simulated stock or an empirically validated session-to-day mapping.
The rule-only studies do not establish long-run LLM market behavior.

Sources: [R039 interpretation](starter_code/runs/20261104_154730_market_validation_fff53e3b/supplement/INTERPRETATION.md),
[R051 all-path review](starter_code/runs/background_diversity_20261106/review/INTERPRETATION.md),
[all R051 prices and maker inventories](starter_code/runs/background_diversity_20261106/review/all_paths.pdf).

## 3. Comparable histories change the reflection conclusion

The selectable conditions remain A (raw observations and executed outcomes),
B (A plus factual summaries) and C (B plus reflection). R043 completed eighteen
quiet markets across three scenarios and two model draws per mode. C had
smaller scenario-average valuation gaps than B, but all six matched C/B paths
already favored C before reflection occurred. The whole-run advantage cannot
be attributed to reflection.

R047 therefore branched B and C from the same six actual five-session histories,
with two fresh branches per mode. Across the six contexts, C-minus-B mean
post-prefix gaps improved in two, worsened in one and were equal in three.
Observed contrasts ranged from -1.3571 to +0.3286 percentage points. This is an
observed range, not a confidence interval. At least one same-mode branch
contrast was as large in absolute value as the between-mode mean contrast in
every context. Individual return differences remained mixed across traders and
terminal marks.

C used 25.62% more known reported tokens. One recovered B attempt has unknown
usage, so an exact all-attempt cost premium is unavailable. The treatment is
the diary policy plus its additional context, with no length-matched sham.
These findings establish neither universal benefit nor harm, and same-mode
variation is not a significance or equivalence test.

Sources: [R047 full interpretation](starter_code/runs/common_prefix_analysis_20261105/INTERPRETATION.md),
[all-context contrasts](starter_code/runs/common_prefix_analysis_20261105/READOUT.md).
Older conditional and incomplete sequential studies remain development history;
they are not pooled with the controlled continuation results.

## Feedback fidelity: a limitation, with an unresolved correction

R050's focused review of all 48 saved reflections identified five temporal
misattributions within one inherited context and two unsupported fill guarantees
in another branch. These are nested examples, not a general hallucination rate
or independent human coding. An optional adapter now distinguishes information
available when deciding from subsequent clearing and marks generated explanations
as unverified. Offline tests check its implementation; original defaults remain.

R052 attempted a frozen original-versus-corrected comparison on twelve actor
histories with two draws per format. It stopped after 8 of 48 planned replies
following two HTTP 503 attempts on slot nine. The delivered sample covers one
original seed only, and the known timing-error context was never reached.
Neither targeted error appeared in the eight delivered replies; that establishes
neither improvement nor equivalence. A corrected reply also confused a 5.6%
stock-price rise with roughly 2.897% portfolio growth. The 40 missing replies
remain missing. No restart or replacement study is scheduled.

See [the frozen design and partial assessment](thesis/FEEDBACK_VALIDATION_PROTOCOL.md).

## What the reported returns mean

Both terminal marks value the same actual portfolio. Their difference in
passive-relative returns equals the change in shares from the passive starting
position, multiplied by the terminal price-minus-reference gap, divided by the
same starting auction wealth. Changing the mark changes valuation, not realized
cash or execution. R053 checks that identity for all 560 account endpoints in
R041/R047, retaining their different initial-zero/common-five starting points.

Under the reported zero-tax, closed-share rules, aggregate active-minus-passive
wealth is zero even though external income grows total cash. Thus individual
or target-group excess wealth does not demonstrate aggregate welfare creation.
These are accounting properties that explain results, not new empirical findings.
The [argument guide](thesis/THESIS_ARGUMENT.md) gives the derivation and a
transparently selected actual example.

## Scope, reproducibility and remaining priorities

The model remains a one-stock batch-auction laboratory with two LLM accounts
among fourteen, uncalibrated fictional personas, no shorting and no estimated
real-world time scale. Price-gap accuracy is relative to a specified risk-neutral
benchmark. Equal initial resources do not imply equal trading intensity.
Correct accounting cannot resolve those realism limitations.

Local frozen-source/saved-response reproduction supports internal reproducibility:
65 earlier paths and 455 financial CSVs matched, with one explicit recovered-error
exclusion; a separate R051 replay matched 16 rule paths and 112 CSVs. These are
not fresh model samples, new scientific scenarios or independent-machine validation.

The immediate thesis priority is a clear account of these three result families,
complete source and failure appendices, and student/supervisor review of scope
and interpretation. Corrected-feedback efficacy, human calibration and general
policy superiority remain open rather than promised outcomes. Broader literature
and final scholarly metadata review precede department formatting, which remains last.

[Reproduction guide](thesis/REPRODUCIBILITY.md) ?
[Study inventory](thesis/appendix/STUDY_INVENTORY.md) ?
[Literature scope](thesis/LITERATURE_REVIEW.md) ?
[Research diary](RESEARCH_DIARY.md)
