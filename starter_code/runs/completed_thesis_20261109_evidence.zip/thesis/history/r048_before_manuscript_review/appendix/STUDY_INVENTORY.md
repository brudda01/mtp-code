# Principal-study and reproduction inventory

R048 writing inventory, 2026-11-05. Four designs support three result families;
their rows are not pooled into one independent sample size. Earlier pilots,
stopped paths and ambiguous-headline cohorts remain in the research diary and
their original archives. The table does not replace those records.

| Study | Scope and replication unit | Model requests and failures | Recorded-output verification |
|---|---|---|---|
| R039 | Four fresh exogenous seeds;original/zero inventory-skew pairs;8rule paths of600sessions | No model calls | All8paths,56financial CSVs byte-identical in examiner replay |
| R041 | Two fresh seeds x2model draws x2maker settings xvisible/silent downside;16paths of8sessions | 256valid decisions/256HTTP;no retries,unknown usage,repairs or missing paths | All16paths,112financial CSVs byte-identical in examiner replay |
| R043 | Three fresh seeds x2model draws xA/B/C;18paths of12sessions | 432decisions+24reflections,456HTTP;no errors/unknown usage/missing paths | All18paths,126financial CSVs byte-identical,with explicit archived-helper supplement |
| R047 | All6R043 B histories through5,nested in the SAME3seeds;2fresh B/2C branches each;24seven-session continuations | 336fresh decisions+48reflections;385HTTP;one recovered Berror/unknown usage;no missing continuation | 23paths,161financial CSVs byte-identical;one recovered-error path explicitly not replayed |

Recorded-output verification blocks network access and supplies saved model
replies. It is not fresh provider sampling, a new independent scenario or an
independent-machine/reimplementation replication. Reused five-session prefixes
are not independent observations. R047's cached deliveries consume no new API
usage; its cost report concerns fresh requests and retains unknown usage.

## Model, economic and prompt provenance

The live designs above use BharatCode's OpenAI-compatible endpoint and exact
model identifier `qwen-3.8-27b`, output cap8192, low reasoning effort, decision
temperature0.3, reflection temperature0 where used, and request timeout180s.
Provider draws are unseeded and no backend fingerprint is pinned. The frozen
protocols and actual request records, not this summary, are the authority for
per-call messages/settings and delivery history.

Economic resources are160000cash/1450shares across14accounts,including two LLM
targets in live paths. The baseline maker inventory skew is0.02 and the
fundamentalist dividend window is1;0skew is a designated sensitivity in R039/
R041,not a selected new default. R041 uses a clarified one-time permanent
downside mean shift; R043/R047 are quiet. Hidden recording length and honest
initial-prior research adapters are recorded separately from core A/B/C.
Personas and exact prompts are preserved,not reconstructed from explanations.

| Study | Exact metadata/results and preservation source |
|---|---|
| R039 | [Study report](../../starter_code/runs/20261104_154730_market_validation_fff53e3b/report.json);[supplement](../../starter_code/runs/20261104_154730_market_validation_fff53e3b/supplement/INTERPRETATION.md);balanced_validation_20261104_evidence.zip |
| R041 | [Report](../../starter_code/runs/downside_confirmation_analysis_20261104/report.json);[interpretation](../../starter_code/runs/downside_confirmation_analysis_20261104/INTERPRETATION.md);downside_confirmation_20261104_evidence.zip |
| R043 | [Frozen protocol](../../starter_code/runs/20261105_012335_quiet_components_5066abab/protocol.json);[report](../../starter_code/runs/quiet_components_analysis_20261105/report.json);quiet_components_20261105_evidence.zip |
| R047 | [Frozen protocol](../../starter_code/runs/20261105_041035_common_prefix_ca10f93d/protocol.json);[report](../../starter_code/runs/common_prefix_analysis_20261105/report.json);[completion receipt](../../starter_code/runs/20261105_041035_common_prefix_ca10f93d/postprocessing_summary.json);common_prefix_20261105_evidence.zip |

R039/R041/R043 replay records are in the
[examiner audit](../../starter_code/runs/examiner_audit_20261105_v2/README.md).
R047 has its own [replay report](../../starter_code/runs/common_prefix_analysis_20261105/replay_report.json).
Each archived source captures the executable revision and uncommitted changes;
the common Git parent alone does not identify what was run. Current archive
SHA256 values and writing inputs are indexed in [sources.json](../sources.json).

## Selection and limitations

All final-study contrasts are retained, including null, mixed and opposite
signs. R043's pre-reflection diagnostic and selected transfer/sizing examples
are post-hoc and labelled accordingly. R047's new endpoints and schedule were
frozen before its first fresh call. It is a conditional diary-policy test,
not an isolated reflection-content test or fresh exogenous-scenario replication.
No account of reproducibility here establishes empirical human-market validity.

For exact selected actual prompts, see [Appendix A](SELECTED_PROMPTS.md) and
its [source JSON](selected_prompts.json). For older missing/capped/failed work,
see [RESEARCH_DIARY.md](../../RESEARCH_DIARY.md); do not silently pool those
cohorts or replace unavailable terminal outcomes with HOLD.
