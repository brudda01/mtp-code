# Execution, Market Design and Information Representation in an LLM-Agent Stock Market Simulation

Revised content draft, 2026-11-05 (R045). Title and chapter arrangement are provisional.
This document is based on completed experiments; it is not a submission-ready
thesis. Department front matter, wider literature coverage, final citation
style and appendix selection remain unfinished. Local evidence references point
to preserved reports and exportable figures rather than hypothetical experiments.

## Abstract

Large language models provide a flexible way to specify agents that respond to
text and market history. However, interpreting their simulated behaviour requires
attention to the market institution, feasible trading opportunities and the
measurements used to evaluate outcomes. This study develops a single-stock
batch-auction environment and examines these issues through matched experiments.
Trading decisions pass through resource validation, auction allocation and
settlement, with explicit dividends, interest and account histories. Three
selectable conditions provide raw observations, additional factual summaries,
and additional reflection on the agent's own executed history.

Three result families are reported. In sixteen short downside-news markets,
aggregate prices and order totals sometimes concealed opposing individual
responses and wealth transfers. In four fresh pairs of 600-session rule markets,
removing market-maker inventory skew reduced full-path return autocorrelation
but increased time at inventory bounds. In eighteen quiet component-comparison
markets, reflection produced smaller scenario-average valuation gaps than
factual summaries in all three exogenous scenarios, while individual returns
remained mixed and reported token use increased by 16.5%. Comparison with a
fixed historical total-return reference also exposed remaining diagnostic gaps.
The findings support evaluating agent markets across execution, market-level
statistics, valuation conventions and computational cost. They do not establish
human-behaviour validation, a universal benefit of reflection or superiority of
LLM traders over rule-based traders.

## 1. Introduction

Agent-based stock-market simulation links individual trading decisions to
aggregate prices, activity and portfolio outcomes. Replacing a rule-based
decision procedure with a language model introduces a different way to represent
information and trader characteristics. A model can receive a persona, read a
headline and explain an intended trade in natural language. These capabilities
also create an interpretation problem: an explanation or requested order does
not, by itself, establish what the trader could execute or what its action
changed in the market.

This thesis investigates that problem using a controlled simulated exchange.
The central question is: **how do execution constraints, market design and
information representation affect the conclusions drawn from an LLM-agent
stock market?** The aim is to identify interpretable effects and limitations
within an explicit environment, rather than assume that plausible language or
one favourable statistic demonstrates a realistic human market.

Three research questions organize the experiments. First, what can price-only
or aggregate-order measurements miss when agents receive market news? Second,
how does a change in background liquidity provision affect several market
diagnostics simultaneously? Third, do factual summaries and own-history
reflection show repeatable differences in market outcomes, individual returns
and computational cost?

The contribution has an implementation component and an empirical simulation
component. The implementation separates requested orders, resource-feasible
orders, fills and realized feedback, while retaining comparable agent modes and
experiment provenance. The simulation studies then demonstrate specific cases
in which different measurements support different interpretations. The results
include a repeated market-background trade-off and a small replicated component
comparison with mixed financial outcomes. Software consistency checks support
these measurements; they are not counted as behavioural findings.

The scope is deliberately bounded. The live populations contain two LLM traders
alongside rule traders, rather than an entirely LLM-driven economy. The asset,
auction institution and dividend process are specified laboratory mechanisms.
Personas are bundled descriptions, not experimentally isolated human traits.
The experiments therefore support conditional statements about these policies
and environments. Claims about human biases, herding, real investment performance
or universal model quality require different evidence.

## 2. Background and literature positioning

### 2.1 Market institutions and statistical validation

Gode and Sunder examine double-auction markets populated by random traders and
report that restrictions against loss-making bids/offers can support high
allocative efficiency. Their result motivates separating the institution's
contribution from the trader's sophistication. Their induced private costs and
values differ from the cash/share feasibility constraints used here, and their
surplus-based allocative efficiency is not this thesis's valuation-gap metric.
The present market-background comparison is therefore a related institutional
question, rather than a replication of their experiment.
[Gode and Sunder, 1993](https://doi.org/10.1086/261868).

Cont distinguishes weak linear return dependence from persistent dependence
in measures of volatility, while discussing time-scale and statistical-estimation
issues. This supports examining several diagnostics rather than interpreting a
single smaller correlation as sufficient validation. The current study uses
price/total-return correlations and absolute-return dependence as limited
diagnostics; it does not test the entire set of stylized facts or infer a
universal numeric threshold from that review.
[Cont, 2001](https://doi.org/10.1080/713665670).

### 2.2 Economic memory and financial-agent simulations

EconAgent combines perception and memory with periodic reflection in a
work-and-consumption macroeconomic simulation. Its ablation study removes
perception or reflection and reports changes in inflation and unemployment
dynamics. Memory ablation is thus an existing research approach, not a novel
feature introduced by this thesis. Our A/B/C study instead measures trading
execution, passive-relative returns under two terminal marks, valuation gaps
and token usage in a different institution. Its outcomes cannot confirm or
refute EconAgent's macroeconomic results directly.
[Li et al., 2024; author text v4, Sections 3.2 and 4.3](https://arxiv.org/html/2310.10436v4).

StockAgent combines investor personalities, a transaction mechanism and a
bulletin board, and examines how external conditions affect trading and
profitability. It also describes correction of invalid agent responses.
These features overlap with broad motivations for financial-agent simulation
and feasible actions. Our narrower comparison fixes economic rules and examines
how requested, accepted and executed orders support different conclusions.
It does not reproduce StockAgent's market, event scenarios or model comparison.
[Zhang et al., 2024; v1, Sections 3 and 5.2](https://arxiv.org/html/2407.18957v1).

TwinMarket structures investor behaviour through a belief-desire-intention
framework and combines trading with social information propagation. It uses
empirical profiles and market information and reports market-statistic and
group-behaviour analyses. The current experiment does not contain that social
interaction design or comparable empirical persona calibration. Different
responses from two personas consequently do not demonstrate herding, contagion
or replicated human biases. Its relevance is to clarify the additional evidence
and mechanisms those broader claims would require.
[Yang et al., 2025; v1, Sections 3–5](https://arxiv.org/html/2502.01506v1).

StockSim describes both order-level and candlestick execution modes, with
execution details and portfolio evaluation separated from agent decisions.
Its evaluation distinguishes deterministic-engine tests from illustrative LLM
trading examples. Execution-aware LLM evaluation and reusable infrastructure
therefore already have direct precedents. The present batch-auction experiment
adds specific matched-case evidence about hidden transfers, aggregate versus
individual responses, and market-gap/return/cost trade-offs within its own
environment. It does not establish greater execution fidelity than StockSim.
[Papadakis et al., 2025; v1, Sections 3–4](https://arxiv.org/html/2507.09255v1).

### 2.3 Position and empirical reference of the present study

Together, these works motivate attention to institutions, information and
evaluation. The present contribution is the implemented controlled instrument
and its documented empirical cases: matched news visibility, one background
sensitivity, and selectable raw/factual/reflection policies. These comparisons
make the measurement problem concrete without asserting that the general
problem or agent architecture is new. No first-of-its-kind claim follows from
this targeted review. The platforms described above were not independently
reproduced or benchmarked against this implementation.

The diagnostic historical reference uses Kenneth French's daily factors. The
official market factor is a value-weighted US market return minus the risk-free
return; adding RF recovers the total market return used here. This supplies
context for return diagnostics, not a human reference population or matched
single-stock calibration.
[Kenneth French, factor construction](https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/Data_Library/f-f_factors.html).

The [review record](LITERATURE_REVIEW.md) specifies versions, sections read,
access limitations and the distinction between source statements and our
inferences. The [working bibliography](references.bib) records checked identifiers;
preprint author lists are abbreviated where noted. Wider classical financial
ABM coverage, final publication-version checks and bibliography formatting
remain writing tasks. This is a targeted review, not an exhaustive search.

## 3. Implemented market and evaluation methods

### 3.1 Population and information

The final live studies use fourteen trading accounts. Twelve background accounts
comprise one market maker, four zero-intelligence traders, three fundamentalists
and four momentum traders. The remaining two accounts are LLM traders with
distinct personas, referred to as Meera and Arjun. Each LLM trader starts with
10,000 currency units and 100 shares. The market maker starts with 30,000 currency
units and 150 shares; the other background accounts each start with 10,000 and
100 shares. Aggregate resources are therefore 160,000 currency units and 1,450
shares. Rule-only companions replace the two target slots with one fundamentalist
and one momentum trader while preserving these resources.

Agents receive permitted public observations and their own account information.
The final live studies keep the current regime valuation benchmark hidden.
Researcher-only event audits and future dividend draws are excluded from agent
inputs. In the final news study, visibility of the headline varies separately
from the actual dividend-mean change. In the final component study there is no
news or scheduled mean change.

The common research adapter hides the total recorded episode length and labels
the first supplied dividend value as an initialization prior, rather than a
previous payment. The asset continues beyond the recording window; shares do
not expire. This adapter changes research communication, not the economic
mechanism. Its use is not itself evidence of improved human realism or a causal
before/after prompting benefit.

### 3.2 Asset, timing and accounting

The main model pays independent, bounded, nonnegative dividends within each
stationary regime:

\[
d_t=\mu_t(1+u_t),\qquad u_t\sim U[-h,h].
\]

The baseline mean is \(\mu=0.02\), relative noise is \(h=0.2\), the per-session
cash interest rate is \(r=0.0002\), and the initial price is 100. Scheduled
permanent mean shifts change \(\mu_t\) once from the specified event session.
A stationary-regime risk-neutral reference is

\[
F_t=\frac{\mu_t}{r}.
\]

This reference assumes a constant expected future dividend, no risk premium
and no anticipation of future unannounced changes. It is a model benchmark,
not an assertion that every risk-averse trader should value or trade at it.

Each session begins with scheduled event effects and public information, then
collects and clears orders. Trades settle before the dividend is drawn. Closing
shareholders receive that session's dividend, and post-settlement cash earns
interest. For account \(i\), let \(\widetilde C_{i,t}\) be cash after trade
settlement and \(q_{i,t}\) be post-trade shares. Closing cash is

\[
C_{i,t}=\widetilde C_{i,t}(1+r)+q_{i,t}d_t.
\]

The new dividend does not earn interest until the following session. Recorded
auction prices precede these cash payments; there is no additional ex-dividend
auction. Portfolio wealth already includes income through cash, so income must
not be added to wealth a second time. Dividends and interest inject cash from
outside the trading accounts. Total shares are fixed, while aggregate cash need
not remain constant. All reported study cohorts use zero transaction tax.

### 3.3 Orders, clearing and execution

Orders specify BUY, SELL or HOLD, an integer quantity, and an optional limit
price. Borrowing and short selling are prohibited. Cash and shares are reserved
from opening holdings; sale proceeds and incoming dividends cannot finance
other orders in the same auction. A market buy is conservatively constrained
using the upper price band. A reduced order is not automatically a numerical
reasoning failure.

The auction has a tick of 0.1 and a price band of 20% around the preceding
price. Buy limits round downward to a tick and sell limits upward, preserving
willingness to trade. The implementation evaluates its candidate prices and
selects the one maximizing executable volume; ties favour the price closest
to the previous price, then the lower price. The candidate set includes the
band endpoints, the bounded previous-price tick and in-band submitted limits.
With no feasible matched volume, the previous price is retained.

Market orders receive allocation priority, followed by more competitive limit
orders. At an oversubscribed equal-priority tier, integer pro-rata allocation
uses largest remainders with seeded random tie resolution. Settlement checks
resource feasibility and prohibits self-trades. Consequently, three different
quantities must be distinguished: the requested order, the accepted feasible
order and the executed trade. An accepted limit order may receive no fill.

The market maker posts buy and sell quotes subject to cash, shares and an
inventory cap of 300 shares. Its inventory target is 150, quote size is ten
shares per side and half-spread is 0.005. Inventory skew is 0.02 in the baseline
and zero in the designated sensitivity condition. Liquidity provision is
bounded, not a guarantee that an LLM order can trade.

These details follow the implemented
[market code](../starter_code/sim/market.py),
[asset code](../starter_code/sim/assets.py) and
[economic conventions](../starter_code/ECONOMIC_MODEL.md), rather than the old
design specification.

### 3.4 Comparable LLM modes

Mode A supplies raw observations and recent verified outcomes. Mode B adds
computed factual summaries derived from the same permitted information.
Mode C adds reflection on its own verified outcomes and previous diary.
All modes retain identical economic rules, public information access, personas
and initial resources within the matched comparison. Summaries change the
representation of information; reflection adds a model-generated interpretation
that may contain incorrect beliefs.

In the final component study, the explicit outcome window is five sessions.
C reflects after sessions five and ten, with the resulting diaries available
from sessions six and eleven. An outcome distinguishes requested and accepted
orders from actual fills, account changes and income. A's retained order
reasoning can carry beliefs forward; an expired explicit news window does not
prove that the agent has forgotten the news.

The final live profile is BharatCode's exact `qwen-3.8-27b`, with low reasoning
effort, a maximum output allowance of 8,192 tokens, decision temperature 0.3,
reflection temperature zero and a 180-second request timeout. Provider draws
are unseeded and no backend fingerprint is pinned. Simulation seeds control
exogenous and allocation streams, not the provider's language-model sampling.
Actual prompts, personas, settings and raw replies are retained. The older
4,096-token conditional cohort remains distinct.

### 3.5 Measurements and passive accounts

The market valuation-gap statistic is

\[
G=\frac{1}{T}\sum_{t=1}^{T}\left|\frac{P_t}{F_t}-1\right|.
\]

Other measurements include signed and gross fills, order reduction, trading
opportunity, turnover, market-maker participation and inventory boundaries.
Price returns \(\log(P_t/P_{t-1})\) are distinguished from total returns
\(\log((P_t+d_t)/P_{t-1})\). The latter is the diagnostic return on a share
held through the session's dividend; it is not a complete account return.

For each account, a conditional passive comparison holds initial shares fixed
and receives the same realized dividends and cash interest. Passive cash obeys

\[
C^{\mathrm{passive}}_{i,t}=C^{\mathrm{passive}}_{i,t-1}(1+r)+q_{i,0}d_t.
\]

Active and passive wealth are marked using both the final auction price and
the regime benchmark. The active-minus-passive difference is divided by the
same initial market wealth under both marks. This is accounting conditional
on the realized price path, not a new equilibrium simulation in which all
accounts cease trading, nor a risk-adjusted alpha estimate. In the closed-share,
zero-tax environment, counterpart excess wealth cancels in aggregate. Individual
differences therefore cannot automatically be interpreted as aggregate welfare.

### 3.6 Reliability and missing outcomes

Matched configurations preserve initial resources, personas and exogenous
dividend paths. Separate streams prevent changes in agent-population sampling
from changing the environment's draws. Preserved manifests record code revision,
uncommitted status, source/config hashes, prompt versions, settings and outputs.
The shared Git revision is not by itself a complete code description because
the working tree contains uncommitted implementation work; source snapshots
and hashes identify the actual executable materials.

Live protocols freeze budgets, ordering and failure policies before execution.
The final studies allow one shared identical-message extra transport/eligible
HTTP503 attempt under the existing policy. Operationally affected paths remain
visible and do not become clean terminal outcomes. Older partial markets,
unknown usage and one capped conditional reply remain recorded; they are not
converted to HOLD or rerun until a preferred answer appears. None of the final
R041 or R043 calls required a retry or repair.

## 4. Experiment designs

The three principal study families answer different questions and are reported
separately. Their numbers are not pooled into a single sample size.

| Study | Population/design | Exogenous scenarios | Repeated observations | Main comparison |
|---|---|---:|---|---|
| R039 | Quiet rule markets;original vs zero market-maker skew | 4 | 2 settings x600 sessions per scenario | Market-background sensitivity |
| R041 | Two LLM traders;initial true downside shift;visible/silent bulletin;two maker settings | 2 | 2 model draws x2 settings x2 visibility conditions;8 sessions each | Visible-minus-silent early executed flow |
| R043 | Quiet A/B/C markets;common initial state/information | 3 | 2 model draws x3 modes;12 sessions each | B-A and C-B gap,returns and token cost |

R039 uses fresh seeds 16253, 17341, 18433 and 19531. Its primary statistic is
the full-path lag-one log-price-return autocorrelation difference between
no-skew and original-skew markets. Three 200-session blocks per path provide
secondary diagnostics; they are nested segments, not independent replications.

R041 uses seeds 20611 and 21727. In each visible/silent pair, the actual dividend
mean changes permanently from 0.02 to 0.016 before the initial auction. Only
the visible condition receives the bulletin. The corrected wording explicitly
describes a one-time expected-level reduction with uncertain realized payments.
A preceding explicit reading check delivered twelve numeric replies and all
36 requested level fields correctly. That gate is evidence of performance on
the reading task, not proof of natural-trading comprehension in every call.
The primary endpoint is visible-minus-silent signed executed target flow over
sessions one through three. Sixteen live markets and eight rule companions
were retained; visible/silent rule companions duplicate financial paths and
are not eight independent rule histories.

R043 uses seeds 22853, 23971 and 25087. Each scenario has two fresh model draws
per mode, with a fixed rotated mode schedule. C produces four reflections per
market across its two traders. Eighteen markets therefore require 432 decisions
and 24 reflection calls. The prespecified descriptive comparisons are B-A and
C-B for whole-path gap, each trader's full-horizon passive excess under both
marks, and token usage. Repeat averages are computed within scenario, leaving
three exogenous scenarios rather than six independent seed replications.

Earlier pilots, conditional probes and incomplete sequential comparisons inform
the development history. They are not substitutes for these fresh cohorts.
In particular, earlier news wording admitted a repeated-growth interpretation
and some older prompts disclosed the total recording length. Those cohorts
cannot establish a causal old/new wording or horizon improvement.

## 5. Results

### 5.1 News responses depend on the level of measurement

All sixteen R041 live markets completed eight sessions and all 256 decisions
were valid. Combined signed executed-flow contrasts over the first three
sessions were negative in seven cases and zero in one.

| Scenario | Draw | Original skew: visible minus silent | No skew: visible minus silent |
|---|---:|---:|---:|
| 20611 | 1 | -2 shares | -156 shares |
| 20611 | 2 | -122 shares | 0 shares |
| 21727 | 1 | -106 shares | -106 shares |
| 21727 | 2 | -3 shares | -128 shares |

A negative contrast can mean more selling, less buying or both. The results
therefore cannot be summarized by BUY frequency alone. The no-skew-minus-original
differences in response were -154, +122, 0 and -125 shares, so the background
change did not consistently strengthen the news response.

Disaggregating the flows changes the interpretation of a near-zero aggregate.
In scenario 21727, draw two, original background, Meera's contrast was -90
shares while Arjun's was +87. The combined -3 concealed opposing individual
responses. An aggregate close to zero did not mean that both traders ignored
the bulletin.

A second case shows that identical prices can conceal a financial difference.
In scenario 20611, draw two, no-skew background, every closing price, dividend
and private-value benchmark matched across the visible and silent markets.
All non-target account paths also matched. Nevertheless, the silent market
contained a session-five sale of 50 shares from Arjun to Meera at 92.8 that
did not occur in the visible market. Session-five volume was 72 rather than
22 shares. Relative to the silent market, Meera's terminal passive excess was
higher by 580.54 currency units at the auction mark and 640.54 at the private
mark; Arjun had the opposite differences. The price-path comparison alone
would miss this redistribution. Zero passive excess from not trading should
also not be confused with zero absolute loss on initial stock holdings.

Finally, identical first-visible inputs and generation settings for Arjun
yielded two BUY, one SELL and five HOLD replies across eight calls. This is
evidence of variation across provider calls before histories diverge, not a
causal estimate of temperature effects or a validation of human risk attitudes.

The complete contrasts, account audit and inspected figure are available in
the [R041 interpretation](../starter_code/runs/downside_confirmation_analysis_20261104/INTERPRETATION.md)
and [all-case response figure](../starter_code/runs/downside_confirmation_analysis_20261104/figure_v2/executed_responses.pdf).

### 5.2 A background change improves one statistic and worsens another

All eight R039 rule paths completed 600 sessions. Removing inventory skew
lowered full-path price-return lag-one autocorrelation in all four paired
scenarios. The paired differences were approximately -0.0499, -0.0955, -0.0496
and -0.0390. Empty/full market-maker inventory time increased in all four.

| Measurement;mean across four scenarios | Original skew | No skew |
|---|---:|---:|
| Lag-one log-price-return autocorrelation | 0.1745 | 0.1160 |
| Sessions at maker inventory 0 or300 | 0.875% | 4.458% |
| Shares traded per session / total shares | 1.311% | 1.216% |
| Mean absolute relative valuation gap | 6.394% | 4.878% |

The average gap and turnover conceal exceptions. Turnover fell in three pairs,
while one whole-path gap worsened. In scenario 17341, the no-skew last-block
gap reached 16.321%, compared with 7.233% in the original setting. Three of
twelve nested block autocorrelation contrasts also reversed the corresponding
full-path direction. The no-skew setting was retained as a sensitivity, not
selected as a realistic default.

The empirical diagnostic used the last 600 available observations on or before
2025-12-31, fixed before inspecting the results. The selected period was
2023-08-11 to 2025-12-31; six rounded zero returns were retained. Raw data and
download metadata preserve the 202609 CRSP snapshot used. For comparable total
log returns, lag-one autocorrelation was -0.0387 in the US reference, versus
0.1754 and 0.1170 in the original/no-skew simulations. Autocorrelation of
absolute total log returns was +0.2079 in the reference but -0.0043 and -0.0032
in the simulations.

This comparison exposes a remaining diagnostic mismatch. It does not define a
universal target: the empirical series is a diversified US portfolio observed
in a particular regime, while the simulation is one small stock with a quiet
specified environment. The long paths contain rule traders; short LLM paths
have not established long-run stylized facts. A lower value gap or reduced
price-return dependence is therefore insufficient to establish market realism.

The [paired trade-off figure](../starter_code/runs/thesis_synthesis_20261105/background_tradeoff.pdf)
and [all-path background interpretation](../starter_code/runs/20261104_154730_market_validation_fff53e3b/supplement/INTERPRETATION.md)
retain all scenarios and qualifications.

### 5.3 Information representation produces a gap/return/cost trade-off

All eighteen R043 markets completed twelve sessions, with 432 valid decisions,
24 genuine own-history reflections and no missing, failed or repaired calls.
The primary gap contrasts below average the two prespecified model draws within
each scenario. Negative values indicate a smaller gap. C-A is the transparent
sum of the two primary contrasts, included as descriptive context rather than
a new predeclared primary test.

| Scenario | B-A mean gap,pp | C-B mean gap,pp | C-A mean gap,pp |
|---|---:|---:|---:|
| 22853 | -0.5875 | -0.4125 | -1.0000 |
| 23971 | +0.4625 | -1.7500 | -1.2875 |
| 25087 | +7.0125 | -4.2125 | +2.8000 |

C had a smaller scenario-average gap than B in all three scenarios and in
five of six individual draw contrasts. The exception was scenario 22853,
draw two, where C-B was +0.1167 percentage points. This is a repeated bounded
policy-level pattern. It does not establish a uniform advantage over the raw
baseline: C-A worsened the average gap in scenario 25087. B-A itself had mixed
signs across scenarios and draws.

Individual passive excess did not follow a uniform market-gap ranking.

| Scenario | Meera C-B,auction/private pp | Arjun C-B,auction/private pp |
|---|---:|---:|
| 22853 | -0.450 / -0.442 | +4.771 / -0.156 |
| 23971 | +0.105 / -0.116 | -2.043 / +0.613 |
| 25087 | -0.341 / -1.304 | +0.128 / +3.056 |

Meera's private-value passive excess was lower under C in all three scenario
averages, despite the lower market gap relative to B. Arjun's sign reversed
between the two terminal marks in scenarios 22853 and 23971. These results
show why market-level valuation accuracy and individual trading outcomes must
be reported separately.

Known provider-reported token totals were 359,233 for A, 394,446 for B and
459,390 for C, across six equal-length markets per mode. C used 64,944 more
tokens than B, or 16.4646% in this campaign. Reflections accounted for 61,342
tokens; the decision-only difference was 3,602. One individual C-B contrast
cost 304 fewer tokens, while the other five cost more. There is no universal
per-decision price or cost multiplier implied by these campaign totals.

B and C initially receive identical messages, and the first reflection occurs
only after session five. Nevertheless, four of twelve first requested-order
pairs differed in side, quantity or limit price, all for Arjun. This post-hoc
all-case diagnostic illustrates model variation before reflection. C later
reflects on its own diverged history. The study therefore compares specified
endogenous policies on matched exogenous scenarios; it does not isolate a
particular reflection sentence while holding later states fixed.

The [R043 interpretation and full tables](../starter_code/runs/quiet_components_analysis_20261105/INTERPRETATION.md),
[all-draw gap/cost figure](../starter_code/runs/quiet_components_analysis_20261105/component_contrasts.pdf)
and [raw-source numerical report](../starter_code/runs/quiet_components_analysis_20261105/report.json)
preserve both model draws, all account groups, exposure and executed-flow windows.

## 6. Discussion and limitations

The studies support a common methodological conclusion: evaluation depends on
which level of the market is measured and what the comparison holds fixed.
The news study demonstrates that unchanged prices need not imply unchanged
trading or individual outcomes. The background study shows that one diagnostic
can improve alongside a deterioration in liquidity-provider inventory behaviour.
The component study shows that smaller market-level gaps can coexist with
mixed individual returns and higher computational usage. No single outcome
provides a sufficient ranking of agent realism or policy quality.

Execution opportunities are central to interpretation. A trader may choose
not to buy, avoid a planned sale, encounter a binding resource constraint or
submit an eligible order that loses price priority. BUY/HOLD/SELL counts and
accepted quantities alone do not distinguish these possibilities. Actual fills,
opening resources and counterpart accounts provide the additional information.
Generated explanations are useful qualitative records but are not direct
observations of latent beliefs or human cognition.

Internal consistency is stronger than external validation. In R043, 456
actual-history request checks and 24 reflection-chain checks passed, while
independent financial reconstruction covered 3,528 account-rounds with maximum
cash error approximately 2.91e-11. R041 likewise checked actual histories and
accounts. Such audits support confidence that the recorded mechanism operated
as specified. They do not validate the dividend process, personas or market
statistics against human behaviour.

Several limits restrict generalization. Only one live model, two bundled
personas and a small mixed population are studied. Provider randomness is
unseeded; common exogenous scenarios do not create paired language-model draws.
The news study contains two scenarios and initial truthful downside bulletins,
without established trends or false-news conditions. The component study has
three exogenous scenarios and short quiet horizons. It does not establish
general reflection benefits or long-run LLM market properties. The empirical
reference is useful context but differs in diversification and institutional
structure from the simulated stock.

The development history also matters. Earlier studies include retained capped
outputs, provider failures and partial markets. Some used ambiguous bulletin
wording or disclosed episode length. They should appear in the appendix and
methods history with their exact settings, not be merged with later cohorts or
presented as causal before/after improvements. A local archive-packaging error
after R043 was corrected by normalizing paths; no experimental or numerical
analysis rerun was required. Routine delivery and packaging fixes belong in
reproducibility documentation rather than the headline result narrative.

Further work should follow a specific claim rather than an unrestricted feature
list. Human-behaviour validation would need a suitable human reference and
matched operational definitions. Long-run LLM stylized-fact claims would need
longer live paths and appropriate independent replication. Isolating a
reflection mechanism would require additional controls over histories and model
variation. None of those claims is necessary to report the bounded findings
established in the current experiments.

## 7. Conclusion

This thesis develops and examines a controlled LLM-agent stock-market
simulation with explicit execution, accounting and comparable information
representations. Its experiments show that price-only and aggregate measurements
can conceal individual responses, that background-market changes involve
diagnostic trade-offs, and that adding reflection can reduce valuation gaps
relative to factual summaries without consistently improving individual returns
or computational efficiency. The contribution is an auditable account of these
conditional effects and their limitations. It does not depend on claiming that
the simulator reproduces human markets or that a more elaborate agent is
universally better.

## Appendix sources and selected actual inputs

[Appendix A](appendix/SELECTED_PROMPTS.md) contains exact saved persona records
and five deterministically selected Meera prompt examples from the first R043
scenario/draw:initial A/B/C decisions,C's first reflection and the following
decision. Its [JSON provenance](appendix/selected_prompts.json) records source
hashes,versions and exact messages. Initial B/C inputs match;later C history
is its own. Generated reflection beliefs are not labelled verified facts.

The remaining appendix assembly should include
normalized study configurations and source/model versions; all primary
contrasts; resource/accounting checks; both terminal valuation definitions;
retained partial/missing/failed outcomes from earlier cohorts; and the run,
figure and evidence-archive inventory. Select examples transparently and retain
links to the full raw evidence. Credentials and `.env` files are excluded.

Primary evidence records:

- [R039 full report](../starter_code/runs/20261104_154730_market_validation_fff53e3b/report.json).
- [R041 full report](../starter_code/runs/downside_confirmation_analysis_20261104/report.json).
- [R043 protocol and exact design](../starter_code/runs/20261105_012335_quiet_components_5066abab/protocol.json).
- [R043 all-case interpretation checks](../starter_code/runs/quiet_components_analysis_20261105/interpretation_checks.json).
- [Durable research diary](../RESEARCH_DIARY.md).

These local links identify experimental evidence. The working scholarly
bibliography is [references.bib](references.bib);final metadata,publication
versions,citation style and formal document cross-references remain on the
writing checklist. [FIGURES_AND_APPENDICES.md](FIGURES_AND_APPENDICES.md) gives
draft captions and exact appendix sources.
