# Execution, Market Design and Information Representation in an LLM-Agent Stock Market Simulation

Revised content draft, 2026-11-08 (R054 conditional auction influence; retains R053 synthesis and R052's incomplete feedback validation). Title and chapter arrangement are provisional.
This document is based on completed experiments; it is not a submission-ready
thesis. Department front matter, wider literature coverage, final citation
style and appendix selection remain unfinished. Local evidence references point
to preserved reports and exportable figures rather than hypothetical experiments.

## Abstract

Large language models provide a flexible way to specify agents that respond to
text and market history. However, interpreting their simulated behaviour requires
attention to the market institution, feasible trading opportunities and the
measurements used to evaluate outcomes. This study develops a single-stock
batch-auction environment and examines these issues through matched experiments.
Trading decisions pass through resource validation, auction allocation and
settlement, with explicit dividends, interest and account histories. Three
selectable conditions provide raw observations, additional factual summaries,
and additional reflection on the agent's own executed history.

Three result families are reported. In sixteen short downside-news markets,
aggregate prices and order totals sometimes concealed opposing individual
responses and wealth transfers. An intervention on all 216 saved quiet auctions
capped each LLM order at ten shares: prices changed in 49 of 105 auctions where
the cap reduced an order. Large volume participation did not reliably identify
price influence, and the cap sometimes worsened valuation accuracy. These are
immediate effects with other orders fixed, not adapted market paths under
permanent caps. In four fresh pairs of 600-session rule markets,
removing market-maker inventory skew reduced full-path return autocorrelation
but increased time at inventory bounds. In eighteen quiet component-comparison
markets, paths assigned to the reflection condition had smaller scenario-average
valuation gaps than factual-summary paths in all three exogenous scenarios.
However, gap advantages were already present before reflection, preventing
attribution of the whole-run difference to reflection itself. A subsequent
shared-history experiment produced twenty-four conditional continuations:
reflection narrowed the gap in two of six inherited contexts, widened it in
one and left it unchanged in three. Same-policy repeats also varied, and
individual returns remained mixed. Reflection used 25.6% more known reported
tokens in this follow-up, with one failed request's usage unknown. Comparison with a
fixed historical total-return reference also exposed remaining diagnostic gaps.
An all-branch retrospective audit further found different executed-account paths
hidden by identical price paths, and reflections that mistook later auction
prices for information available at decision time. A separate sixteen-market
rule-only experiment retained the inventory-skew trade-off under one less
synchronized background-policy bundle. Heterogeneity did not ensure better
valuation accuracy; one adverse path ended at 217.5 against a benchmark of 100.
The findings support evaluating agent markets across execution, market-level
statistics, valuation conventions and computational cost. They do not establish
human-behaviour validation, a universal benefit of reflection or superiority of
LLM traders over rule-based traders.

## 1. Introduction

Agent-based stock-market simulation links individual trading decisions to
aggregate prices, activity and portfolio outcomes. Replacing a rule-based
decision procedure with a language model introduces a different way to represent
information and trader characteristics. A model can receive a persona, read a
headline and explain an intended trade in natural language. These capabilities
also create an interpretation problem: an explanation or requested order does
not, by itself, establish what the trader could execute or what its action
changed in the market.

This thesis investigates that problem using a controlled simulated exchange.
The central question is: **how do execution constraints, market design and
information representation affect the conclusions drawn from an LLM-agent
stock market?** The aim is to identify interpretable effects and limitations
within an explicit environment, rather than assume that plausible language or
one favourable statistic demonstrates a realistic human market.

Three research questions organize the experiments. First, what can price-only
or aggregate-order measurements miss when agents receive market news? Second,
how does a change in background liquidity provision affect several market
diagnostics simultaneously? Third, do factual summaries and own-history
reflection show repeatable differences in market outcomes, individual returns
and computational cost?

The contribution has an implementation component and an empirical simulation
component. The implementation separates requested orders, resource-feasible
orders, fills and realized feedback, while retaining comparable agent modes and
experiment provenance. The simulation studies then demonstrate specific cases
in which different measurements support different interpretations. The results
include a repeated market-background trade-off, execution/wealth counterexamples
and a shared-history component comparison with mixed financial outcomes. The
component investigation explicitly distinguishes pre-intervention differences
from subsequent policy contrasts and reports variation between same-policy
repeats. Software consistency checks support
these measurements; they are not counted as behavioural findings.

These result families have different evidential roles. The background trade-off
has repeated across two separate four-seed studies. Matched execution examples
establish that price equality need not identify individual outcomes, without
estimating how often that occurs in real markets. The component studies address
the comparability of starting histories and the consequences of a specific diary
policy. Their mixed results do not establish that reflection has no effect.
This distinction guides the interpretation of the results rather than ranking
all studies by their number of calls or recorded sessions.

The scope is deliberately bounded. The live populations contain two LLM traders
alongside rule traders, rather than an entirely LLM-driven economy. The asset,
auction institution and dividend process are specified laboratory mechanisms.
Personas are bundled descriptions, not experimentally isolated human traits.
The experiments therefore support conditional statements about these policies
and environments. Claims about human biases, herding, real investment performance
or universal model quality require different evidence.

## 2. Background and literature positioning

### 2.1 Market institutions and statistical validation

Gode and Sunder examine double-auction markets populated by random traders and
report that restrictions against loss-making bids/offers can support high
allocative efficiency. Their result motivates separating the institution's
contribution from the trader's sophistication. Their induced private costs and
values differ from the cash/share feasibility constraints used here, and their
surplus-based allocative efficiency is not this thesis's valuation-gap metric.
The present market-background comparison is therefore a related institutional
question, rather than a replication of their experiment.
[Gode and Sunder, 1993](https://doi.org/10.1086/261868).

Cont distinguishes weak linear return dependence from persistent dependence
in measures of volatility, while discussing time-scale and statistical-estimation
issues. This supports examining several diagnostics rather than interpreting a
single smaller correlation as sufficient validation. The current study uses
price/total-return correlations and absolute-return dependence as limited
diagnostics; it does not test the entire set of stylized facts or infer a
universal numeric threshold from that review.
[Cont, 2001](https://doi.org/10.1080/713665670).

### 2.2 Economic memory and financial-agent simulations

Price influence should also be distinguished from trading volume. Cont,
Kukanov and Stoikov's study of fifty US stocks reports a more robust short-term
price relationship with order-flow imbalance than with trade volume
([Cont et al., 2014; abstract and metadata](https://arxiv.org/abs/1011.6402v3),
`cont2014impact`). This motivates examining the actual auction book rather
than equating an agent's volume share with its price contribution. The present
batch-auction interventions do not replicate their continuous-market estimates.

Heterogeneous expectations predate LLM traders. Brock and Hommes study an
asset-pricing model in which agents switch predictors according to past
performance. Their endogenous belief selection differs from this experiment's
fixed population and generated diaries. Our implementation neither reproduces
their dynamics nor establishes a new general theory of heterogeneous beliefs.
This comparison relies on the publisher abstract and bibliographic record;
the attempted university-hosted full-text fetch timed out.
[Brock and Hommes, 1998](https://doi.org/10.1016/S0165-1889(98)00011-6).

EconAgent combines perception and memory with periodic reflection in a
work-and-consumption macroeconomic simulation. Its ablation study removes
perception or reflection and reports changes in inflation and unemployment
dynamics. Memory ablation is thus an existing research approach, not a novel
feature introduced by this thesis. Our A/B/C study instead measures trading
execution, passive-relative returns under two terminal marks, valuation gaps
and token usage in a different institution. Its outcomes cannot confirm or
refute EconAgent's macroeconomic results directly.
[Li et al., 2024; author text v4, Sections 3.2 and 4.3](https://arxiv.org/html/2310.10436v4).

StockAgent combines investor personalities, a transaction mechanism and a
bulletin board, and examines how external conditions affect trading and
profitability. It also describes correction of invalid agent responses.
These features overlap with broad motivations for financial-agent simulation
and feasible actions. Our narrower comparison fixes economic rules and examines
how requested, accepted and executed orders support different conclusions.
It does not reproduce StockAgent's market, event scenarios or model comparison.
[Zhang et al., 2024; v1, Sections 3 and 5.2](https://arxiv.org/html/2407.18957v1).

TwinMarket structures investor behaviour through a belief-desire-intention
framework and combines trading with social information propagation. It uses
empirical profiles and market information and reports market-statistic and
group-behaviour analyses. The current experiment does not contain that social
interaction design or comparable empirical persona calibration. Different
responses from two personas consequently do not demonstrate herding, contagion
or replicated human biases. Its relevance is to clarify the additional evidence
and mechanisms those broader claims would require.
[Yang et al., 2025; v1, Sections 3–5](https://arxiv.org/html/2502.01506v1).

StockSim describes both order-level and candlestick execution modes, with
execution details and portfolio evaluation separated from agent decisions.
Its evaluation distinguishes deterministic-engine tests from illustrative LLM
trading examples. Execution-aware LLM evaluation and reusable infrastructure
therefore already have direct precedents. The present batch-auction experiment
adds specific matched-case evidence about hidden transfers, aggregate versus
individual responses, and market-gap/return/cost trade-offs within its own
environment. It does not establish greater execution fidelity than StockSim.
[Papadakis et al., 2025; v1, Sections 3–4](https://arxiv.org/html/2507.09255v1).

Henning and colleagues compare LLM agents with human traders in an experimental
asset market and distinguish fundamental-value accuracy from human resemblance.
Their version-three study reports nineteen human markets, an explicit redemption
value and a task shared across human and model conditions. This provides a more
direct validation precedent than comparing our single simulated stock with a
broad historical portfolio. Our market differs in population, institution,
parameters and terminal treatment; it has not reproduced their human comparison.
We use their study to delimit the evidence required for human-realism claims,
not as a transferable numerical benchmark or a blanket verdict on all LLM agents.
[Henning et al., 2025; v3, Sections 3–4](https://arxiv.org/html/2502.15800v3).

### 2.3 Replay and fixed-history precedents

Replay assurance and controlled-history diagnostics also have precedents.
Khatchadourian's framework separates configuration, preserved execution records
and the level of comparison for financial agents. Our use of saved-response
playback applies that general concern to auction/accounting outputs; it is
not an invention of replay-based evaluation. This comparison uses the
paper's abstract and metadata, rather than a full methods review.
[Khatchadourian, 2026; v4](https://arxiv.org/abs/2601.15322v4).

Xie, Zhao and Wilson distinguish interactive performance from diagnostic
evaluation using fixed histories and controlled information in repeated
hide-and-seek. The present shared-history intervention addresses a related
evaluation concern in a market: different prior trades can obscure a component
comparison. The tasks and outcomes differ; our experiment does not measure
opponent-belief accuracy. This positioning is likewise based on the abstract.
[Xie et al., 2026; v1](https://arxiv.org/abs/2610.17310v1).

### 2.4 Validation and model-description standards

Windrum, Fagiolo and Moneta distinguish validation approaches and emphasize
sensitivity to initial conditions, parameters and stochastic variation.
Their discussion supports separating within-model sensitivity from empirical
validation. Our limited background comparison and uncalibrated historical
reference do not implement their broader validation procedures.
[Windrum et al., 2007; Sections 3 and 4](https://www.jasss.org/10/2/8.html).

Grimm and colleagues' updated ODD protocol connects model purpose, description,
design rationale and evaluation. It motivates making scheduling, initialization
and submodels explicit here. The accompanying documentation maps those items
to implementation and evidence; it is not a certified full ODD or a substitute
for external validation.
[Grimm et al., 2020; Table 1 and guidance on purpose/code links](https://www.jasss.org/23/2/7.html).

### 2.5 Position and empirical reference of the present study

Together, these works motivate attention to institutions, information and
evaluation. The present contribution is the implemented controlled instrument
and its documented empirical cases: matched news visibility, one background
sensitivity, selectable raw/factual/reflection policies, and repeated
continuations from actual shared market histories. These comparisons
make the measurement problem concrete without asserting that the general
problem or agent architecture is new. No first-of-its-kind claim follows from
this targeted review. The platforms described above were not independently
reproduced or benchmarked against this implementation.

The diagnostic historical reference uses Kenneth French's daily factors. The
official market factor is a value-weighted US market return minus the risk-free
return; adding RF recovers the total market return used here. This supplies
context for return diagnostics, not a human reference population or matched
single-stock calibration.
[Kenneth French, factor construction](https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/Data_Library/f-f_factors.html).

The [review record](LITERATURE_REVIEW.md) specifies versions, sections read,
access limitations and the distinction between source statements and our
inferences. The [working bibliography](references.bib) records checked identifiers;
preprint author lists are abbreviated where noted. The review now includes
a classical heterogeneous-expectations model and empirical-validation and
description standards. Wider financial ABM coverage, final publication-version
checks and bibliography formatting remain writing tasks. This is a targeted
review, not an exhaustive search.

## 3. Implemented market and evaluation methods

### 3.1 Population and information

The final live studies use fourteen trading accounts. Twelve background accounts
comprise one market maker, four zero-intelligence traders, three fundamentalists
and four momentum traders. The remaining two accounts are LLM traders with
distinct personas, referred to as Meera and Arjun. Each LLM trader starts with
10,000 currency units and 100 shares. The market maker starts with 30,000 currency
units and 150 shares; the other background accounts each start with 10,000 and
100 shares. Aggregate resources are therefore 160,000 currency units and 1,450
shares. Rule-only companions replace the two target slots with one fundamentalist
and one momentum trader while preserving these resources.

Agents receive permitted public observations and their own account information.
The final live studies keep the current regime valuation benchmark hidden.
Researcher-only event audits and future dividend draws are excluded from agent
inputs. In the final news study, visibility of the headline varies separately
from the actual dividend-mean change. In the final component study there is no
news or scheduled mean change.

Hidden here means that the current benchmark is not supplied directly as a
field; it does not mean that its value is impossible to infer. The disclosed
initial prior and interest rule, or a visible mean-shift bulletin, can support
a benchmark calculation under the model's valuation assumptions. No claim of
an inaccessible fundamental-value signal follows from withholding the field.

The common research adapter hides the total recorded episode length and labels
the first supplied dividend value as an initialization prior, rather than a
previous payment. The asset continues beyond the recording window; shares do
not expire. This adapter changes research communication, not the economic
mechanism. Its use is not itself evidence of improved human realism or a causal
before/after prompting benefit.

### 3.2 Asset, timing and accounting

The main model pays independent, bounded, nonnegative dividends within each
stationary regime:

\[
d_t=\mu_t(1+u_t),\qquad u_t\sim U[-h,h].
\]

The baseline mean is \(\mu=0.02\), relative noise is \(h=0.2\), the per-session
cash interest rate is \(r=0.0002\), and the initial price is 100. Scheduled
permanent mean shifts change \(\mu_t\) once from the specified event session.
A stationary-regime risk-neutral reference is

\[
F_t=\frac{\mu_t}{r}.
\]

This reference assumes a constant expected future dividend, no risk premium
and no anticipation of future unannounced changes. It is a model benchmark,
not an assertion that every risk-averse trader should value or trade at it.

A trading session is the model's time step, with no estimated conversion to
a real trading day. The per-session income and interest rates are laboratory
parameters. Comparing simulated returns with a daily portfolio series therefore
provides descriptive context across different institutions and time scales,
rather than a calibrated daily-market validation.

Each session begins with scheduled event effects and public information, then
collects and clears orders. Trades settle before the dividend is drawn. Closing
shareholders receive that session's dividend, and post-settlement cash earns
interest. For account \(i\), let \(\widetilde C_{i,t}\) be cash after trade
settlement and \(q_{i,t}\) be post-trade shares. Closing cash is

\[
C_{i,t}=\widetilde C_{i,t}(1+r)+q_{i,t}d_t.
\]

The new dividend does not earn interest until the following session. Recorded
auction prices precede these cash payments; there is no additional ex-dividend
auction. Portfolio wealth already includes income through cash, so income must
not be added to wealth a second time. Dividends and interest inject cash from
outside the trading accounts. Total shares are fixed, while aggregate cash need
not remain constant. All reported study cohorts use zero transaction tax.

### 3.3 Orders, clearing and execution

Orders specify BUY, SELL or HOLD, an integer quantity, and an optional limit
price. Borrowing and short selling are prohibited. Cash and shares are reserved
from opening holdings; sale proceeds and incoming dividends cannot finance
other orders in the same auction. A market buy is conservatively constrained
using the upper price band. A reduced order is not automatically a numerical
reasoning failure.

The auction has a tick of 0.1 and a price band of 20% around the preceding
price. Buy limits round downward to a tick and sell limits upward, preserving
willingness to trade. The implementation evaluates its candidate prices and
selects the one maximizing executable volume; ties favour the price closest
to the previous price, then the lower price. The candidate set includes the
band endpoints, the bounded previous-price tick and in-band submitted limits.
With no feasible matched volume, the previous price is retained.

Market orders receive allocation priority, followed by more competitive limit
orders. At an oversubscribed equal-priority tier, integer pro-rata allocation
uses largest remainders with seeded random tie resolution. Settlement checks
resource feasibility and prohibits self-trades. Consequently, three different
quantities must be distinguished: the requested order, the accepted feasible
order and the executed trade. An accepted limit order may receive no fill.

The market maker posts buy and sell quotes subject to cash, shares and an
inventory cap of 300 shares. Its inventory target is 150, quote size is ten
shares per side and half-spread is 0.005. Inventory skew is 0.02 in the baseline
and zero in the designated sensitivity condition. Liquidity provision is
bounded, not a guarantee that an LLM order can trade.

These details follow the implemented
[market code](../starter_code/sim/market.py),
[asset code](../starter_code/sim/assets.py) and
[economic conventions](../starter_code/ECONOMIC_MODEL.md), rather than the old
design specification.

### 3.4 Comparable LLM modes

Mode A supplies raw observations and recent verified outcomes. Mode B adds
computed factual summaries derived from the same permitted information.
Mode C adds reflection on its own verified outcomes and previous diary.
All modes retain identical economic rules, public information access, personas
and initial resources within the matched comparison. Summaries change the
representation of information; reflection adds a model-generated interpretation
that may contain incorrect beliefs.

In the final component study, the explicit outcome window is five sessions.
C reflects after sessions five and ten, with the resulting diaries available
from sessions six and eleven. An outcome distinguishes requested and accepted
orders from actual fills, account changes and income. A's retained order
reasoning can carry beliefs forward; an expired explicit news window does not
prove that the agent has forgotten the news.

The final live profile is BharatCode's exact `qwen-3.8-27b`, with low reasoning
effort, a maximum output allowance of 8,192 tokens, decision temperature 0.3,
reflection temperature zero and a 180-second request timeout. Provider draws
are unseeded and no backend fingerprint is pinned. Simulation seeds control
exogenous and allocation streams, not the provider's language-model sampling.
Actual prompts, personas, settings and raw replies are retained. The older
4,096-token conditional cohort remains distinct.

### 3.5 Measurements and passive accounts

The market valuation-gap statistic is

\[
G=\frac{1}{T}\sum_{t=1}^{T}\left|\frac{P_t}{F_t}-1\right|.
\]

Other measurements include signed and gross fills, order reduction, trading
opportunity, turnover, market-maker participation and inventory boundaries.
Price returns \(\log(P_t/P_{t-1})\) are distinguished from total returns
\(\log((P_t+d_t)/P_{t-1})\). The latter is the diagnostic return on a share
held through the session's dividend; it is not a complete account return.

For each account, a conditional passive comparison holds initial shares fixed
and receives the same realized dividends and cash interest. Passive cash obeys

\[
C^{\mathrm{passive}}_{i,t}=C^{\mathrm{passive}}_{i,t-1}(1+r)+q_{i,0}d_t.
\]

Active and passive wealth are marked using both the final auction price and
the regime benchmark. The active-minus-passive difference is divided by the
same initial market wealth under both marks. This is accounting conditional
on the realized price path, not a new equilibrium simulation in which all
accounts cease trading, nor a risk-adjusted alpha estimate. In the closed-share,
zero-tax environment, counterpart excess wealth cancels in aggregate. Individual
differences therefore cannot automatically be interpreted as aggregate welfare.

R047 applies the same accounting from the common closing-session-five state:
passive cash and shares are initialized to that account's actual balances at
five, and both marks use its closing-five auction wealth as denominator. Its
gap averages only sessions six through twelve. These conditional continuation
metrics are not pooled with the initial-zero, whole-path metrics of R043.

The relation between the two marks can be stated exactly. Let \(s\) denote the
start of the evaluated interval and \(m\) its terminal mark. Then

\[
E_i(m)=C_{i,T}-C^{\mathrm{passive}}_{i,T}+(q_{i,T}-q_{i,s})m,
\qquad
e_i(P_T)-e_i(F_T)
=\frac{(q_{i,T}-q_{i,s})(P_T-F_T)}{W_{i,s}}.
\]

Here \(e_i=E_i/W_{i,s}\), and \(W_{i,s}\) is the same starting auction wealth
under both marks. The difference is the valuation of changed stock exposure,
not another trade, cash receipt or policy intervention. For comparisons between
branches, the identity applies within each branch before averaging; their final
prices need not match.

A saved-data check confirms this identity for all 560 account endpoints across
the sixteen R041 paths and twenty-four R047 continuations. For a transparent
illustration, the first sign-changing target account in study/run-path/agent
order is Meera in R041, seed 20611, original background, silent draw two. She
ends with 130 shares versus 100 passively, at auction price 81.4 and reference
80. The mark difference is \(30(81.4-80)=42\): excess wealth is approximately
+0.067 under the auction mark, effectively zero, and -41.933 under the reference
mark. This illustrates a metric property, not representative profitability.
The [evidence and accounting guide](THESIS_ARGUMENT.md) retains the selection
rule, complete source checks and aggregate derivation.

Aggregate cancellation concerns wealth amounts:
\(\sum_i E_i(m)=\sum_i W_{i,s}e_i(m)=0\) under the reported zero-tax, closed-share
rules with uniform interest and per-share dividends. It need not hold for an
unweighted mean of percentage excess returns, because starting wealth differs
across accounts. External income can grow total cash while this passive-relative
identity still holds.

### 3.6 Reliability and missing outcomes

Matched configurations preserve initial resources, personas and exogenous
dividend paths. Separate streams prevent changes in agent-population sampling
from changing the environment's draws. Preserved manifests record code revision,
uncommitted status, source/config hashes, prompt versions, settings and outputs.
The shared Git revision is not by itself a complete code description because
the working tree contains uncommitted implementation work; source snapshots
and hashes identify the actual executable materials.

Live protocols freeze budgets, ordering and failure policies before execution.
The final studies allow one shared identical-message extra transport/eligible
HTTP503 attempt under the existing policy. Operationally affected paths remain
visible and do not become clean terminal outcomes. Older partial markets,
unknown usage and one capped conditional reply remain recorded; they are not
converted to HOLD or rerun until a preferred answer appears. None of the final
R041 or R043 calls required a retry or repair.

R047 had one recovered request error under that existing identical-message
retry policy. The continuation completed; the failed attempt's usage remains
unknown. It is retained in cost/failure reporting. Its saved-response replay
is explicitly excluded because the replay worker does not reproduce recovered
exception attempts; this does not turn it into a missing live market.

## 4. Experiment designs

The three principal study families answer different questions and are reported
separately. Their numbers are not pooled into a single sample size.

| Study | Population/design | Exogenous scenarios | Repeated observations | Main comparison |
|---|---|---:|---|---|
| R039 | Quiet rule markets;original vs zero market-maker skew | 4 | 2 settings x600 sessions per scenario | Market-background sensitivity |
| R041 | Two LLM traders;initial true downside shift;visible/silent bulletin;two maker settings | 2 | 2 model draws x2 settings x2 visibility conditions;8 sessions each | Visible-minus-silent early executed flow |
| R043 | Quiet A/B/C markets;common initial state/information | 3 | 2 model draws x3 modes;12 sessions each | B-A and C-B gap,returns and token cost |
| R047 | Quiet B/C continuations from six actual B histories through session5 | Same3 scenarios;2 inherited contexts each | 2 fresh branches per mode/context;7 new sessions each;24 continuations | Post-prefix C-mean minus B-mean;both-mark passive excess;cost and same-mode variation |
| R050 | Retrospective feedback/execution audit | Existing R047 contexts and R043 scenarios | All48 R047 reflections;36 dependent branch pairs;R043 background orders | Timing fidelity and distinctions between order,fill,account and price paths;no new model samples |
| R051 | Rule-only homogeneous/heterogeneous background x maker skew .02/0 | 4 fresh scenarios | 16 markets x600 sessions | Skew-removal ACF1 contrast under each background and their interaction;inventory/gap/activity trade-offs |
| R054 | Conditional one-auction interventions on all R043 accepted books | Same3 R043 scenarios | 216 factual auctions x2 interventions;432 hypothetical clears | Cap each LLM accepted quantity at10;secondary joint order suppression;price influence,volume,fills and gap |

R039 uses fresh seeds 16253, 17341, 18433 and 19531. Its primary statistic is
the full-path lag-one log-price-return autocorrelation difference between
no-skew and original-skew markets. Three 200-session blocks per path provide
secondary diagnostics; they are nested segments, not independent replications.

R041 uses seeds 20611 and 21727. In each visible/silent pair, the actual dividend
mean changes permanently from 0.02 to 0.016 before the initial auction. Only
the visible condition receives the bulletin. The corrected wording explicitly
describes a one-time expected-level reduction with uncertain realized payments.
A preceding explicit reading check delivered twelve numeric replies and all
36 requested level fields correctly. That gate is evidence of performance on
the reading task, not proof of natural-trading comprehension in every call.
The primary endpoint is visible-minus-silent signed executed target flow over
sessions one through three. Sixteen live markets and eight rule companions
were retained; visible/silent rule companions duplicate financial paths and
are not eight independent rule histories.

R043 uses seeds 22853, 23971 and 25087. Each scenario has two fresh model draws
per mode, with a fixed rotated mode schedule. C produces four reflections per
market across its two traders. Eighteen markets therefore require 432 decisions
and 24 reflection calls. The prespecified descriptive comparisons are B-A and
C-B for whole-path gap, each trader's full-horizon passive excess under both
marks, and token usage. Repeat averages are computed within scenario, leaving
three exogenous scenarios rather than six independent seed replications.

R047 addresses the pre-reflection imbalance found in R043. All six existing
B histories through session five are included without response or resource
screening. Recorded first-five-session decisions reproduce the actual auction
outcomes and all fourteen accounts' cash, shares and average costs before any
new model request. From each prefix, two B and two C branches continue through
session twelve. C first reflects after five on the shared actual history and
again after ten on its own continuation; B never reflects. Both modes retain
the same factual summaries. Later states may diverge as consequences of fresh
choices and their execution; they are not artificially held fixed.

The schedule is shuffled once using a fixed predeclared seed. Model settings
remain Qwen `qwen-3.8-27b`, 8,192 output tokens, low reasoning, decision
temperature 0.3 and reflection temperature zero. The 24 continuations require
336 new decisions and 48 reflections. The 240 cached prefix deliveries are
historical playback, not fresh samples or provider usage. Technical gates
reproduce twelve B/C prefix-only paths and 84 financial CSVs without HTTP.

Primary contrasts average the two C branches minus the two B branches within
each prefix for the post-prefix gap, individual common-start passive excess
under both marks, and fresh cost. B1-B2 and C1-C2 contrasts describe same-mode
variation; two draws are not a variance calibration or significance test.
The six contexts nest in three exogenous scenarios already used in R043.
They do not create six fresh scenarios or twenty-four independent market
replications. The treatment is the generated reflection-diary policy, including
extra context length; a length-matched sham diary is absent. Resources,
personas, exogenous paths, background rules and original selectable A/B/C modes
remain unchanged. Failure rules and budget ceilings were frozen before calls.

Earlier pilots, conditional probes and incomplete sequential comparisons inform
the development history. They are not substitutes for these fresh cohorts.
In particular, earlier news wording admitted a repeated-growth interpretation
and some older prompts disclosed the total recording length. Those cohorts
cannot establish a causal old/new wording or horizon improvement.

R050 is explicitly post-hoc. It compares all six unordered branch pairs within
each R047 context, including both within-mode pairs and all four cross-mode
pairs. These 36 comparisons reuse the same 24 branches. Only the first new
auction has a common pre-decision state; later comparisons include endogenous
history differences. A focused AI-assisted analyst review covers all 48 saved
reflections for temporal misattribution and claims of guaranteed fills. It is
neither blinded human coding nor an overall factual-accuracy score.

R051 freezes seeds 26183, 27329, 28513 and 29671 before outcomes. The homogeneous
background retains the original rules. The heterogeneous bundle replaces the
three background fundamentalist thresholds of .03 with .02/.03/.04, and the
four momentum lookbacks of five with 3/4/6/7. Mean parameter settings remain
the same, but realized trading intensity need not. The fundamentalists' payout
window remains one, and the two target replacement F/M slots remain unchanged.
Each background is crossed with inventory skew .02 and zero. All fourteen
opening accounts, agent random-stream positions and dividend paths are matched
within seed. The primary endpoint is the difference between the backgrounds'
no-skew-minus-skew price-return ACF1 contrasts. Inventory boundaries, gaps,
activity, all-account passive excess under both marks and nested 200-session
blocks are secondary. This tests one joint heterogeneity bundle; it does not
isolate its individual components or calibrate a human population.

### 4.1 Units of comparison and the scope of uncertainty

R054 addresses the order-size confound in the existing two-LLM population.
Before any hypothetical clearing, all 216 actual auction prices, ordered trades
and 3,024 closing account states were reconstructed from the original accepted
orders and allocation-generator sequence. The frozen primary intervention caps
each LLM's accepted quantity at ten, retaining its side and limit; a secondary
intervention suppresses both target orders while preserving their accounts.
Ten shares is the existing zero-intelligence maximum order and maker quote
size, not a calibrated or optimized bound. Each intervention holds the actual
opening accounts, previous price, background orders and pre-auction allocation
state fixed. No hypothetical state is propagated to another session. Primary
endpoints are exact price-change frequency and mean absolute price change
divided by the preceding actual price, reported by market and seed, over all
auctions and the subset where a cap reduces an order.

The [R054 protocol and assessment](ORDER_INFLUENCE.md) explain controls and
provenance. The design was frozen before calculating the new outcomes, but was
motivated by prior sizing diagnostics in the same cohort. It is not a held-out
or externally preregistered study. Its 216 nested frames remain observations
from three existing scenarios, not 216 new independent markets. Conditional
mechanical effects do not establish adaptation to a permanent cap or a causal
effect of increasing the number of LLM accounts.

The replication unit depends on the claim. R039 has four exogenous scenario
pairs. R051 has four different scenarios crossed with two backgrounds; these
produce eight pairs within that study, not eight independent scenarios. R041's
eight headline contrasts nest within two exogenous scenarios. R047 reuses six
actual histories from three R043 scenarios; its twenty-four branches and R050's
thirty-six overlapping pair comparisons do not create new exogenous scenarios.

Matched simulator histories control the observed starting state. They do not
pair the provider's random draws: requests are fresh, unseeded and may differ
even under identical inputs. The study reports all observed contrasts and
same-mode differences without treating their spread as a confidence interval,
subtracting it as known noise or interpreting equality as statistical equivalence.
Short endogenous paths, few provider draws and shared histories restrict the
precision and generality of conclusions. Longer paths can improve a within-path
diagnostic while leaving the number of independent scenarios unchanged.

Verification, interpretation and prospective evidence also remain distinct.
R050 and the terminal-mark synthesis are post-hoc saved-data analyses. R052
specified its comparison before new calls but delivered only eight replies;
its unobserved histories and second draws remain missing. Exact arithmetic and
local replay support the integrity of measurements, not the realism of their
economic assumptions or the generality of model behavior.

## 5. Results

### 5.1 News responses depend on the level of measurement

All sixteen R041 live markets completed eight sessions and all 256 decisions
were valid. Combined signed executed-flow contrasts over the first three
sessions were negative in seven cases and zero in one.

| Scenario | Draw | Original skew: visible minus silent | No skew: visible minus silent |
|---|---:|---:|---:|
| 20611 | 1 | -2 shares | -156 shares |
| 20611 | 2 | -122 shares | 0 shares |
| 21727 | 1 | -106 shares | -106 shares |
| 21727 | 2 | -3 shares | -128 shares |

A negative contrast can mean more selling, less buying or both. The results
therefore cannot be summarized by BUY frequency alone. The no-skew-minus-original
differences in response were -154, +122, 0 and -125 shares, so the background
change did not consistently strengthen the news response.

Disaggregating the flows changes the interpretation of a near-zero aggregate.
In scenario 21727, draw two, original background, Meera's contrast was -90
shares while Arjun's was +87. The combined -3 concealed opposing individual
responses. An aggregate close to zero did not mean that both traders ignored
the bulletin.

A second case shows that identical prices can conceal a financial difference.
In scenario 20611, draw two, no-skew background, every closing price, dividend
and private-value benchmark matched across the visible and silent markets.
All non-target account paths also matched. Nevertheless, the silent market
contained a session-five sale of 50 shares from Arjun to Meera at 92.8 that
did not occur in the visible market. Session-five volume was 72 rather than
22 shares. Relative to the silent market, Meera's terminal passive excess was
higher by 580.54 currency units at the auction mark and 640.54 at the private
mark; Arjun had the opposite differences. The price-path comparison alone
would miss this redistribution. Zero passive excess from not trading should
also not be confused with zero absolute loss on initial stock holdings.

Finally, identical first-visible inputs and generation settings for Arjun
yielded two BUY, one SELL and five HOLD replies across eight calls. This is
evidence of variation across provider calls before histories diverge, not a
causal estimate of temperature effects or a validation of human risk attitudes.

The complete contrasts, account audit and inspected figure are available in
the [R041 interpretation](../starter_code/runs/downside_confirmation_analysis_20261104/INTERPRETATION.md)
and [all-case response figure](../starter_code/runs/downside_confirmation_analysis_20261104/figure_v2/executed_responses.pdf).

### 5.2 A background change improves one statistic and worsens another

All eight R039 rule paths completed 600 sessions. Removing inventory skew
lowered full-path price-return lag-one autocorrelation in all four paired
scenarios. The paired differences were approximately -0.0499, -0.0955, -0.0496
and -0.0390. Empty/full market-maker inventory time increased in all four.

| Measurement;mean across four scenarios | Original skew | No skew |
|---|---:|---:|
| Lag-one log-price-return autocorrelation | 0.1745 | 0.1160 |
| Sessions at maker inventory 0 or300 | 0.875% | 4.458% |
| Shares traded per session / total shares | 1.311% | 1.216% |
| Mean absolute relative valuation gap | 6.394% | 4.878% |

The average gap and turnover conceal exceptions. Turnover fell in three pairs,
while one whole-path gap worsened. In scenario 17341, the no-skew last-block
gap reached 16.321%, compared with 7.233% in the original setting. Three of
twelve nested block autocorrelation contrasts also reversed the corresponding
full-path direction. The no-skew setting was retained as a sensitivity, not
selected as a realistic default.

The empirical diagnostic used the last 600 available observations on or before
2025-12-31, fixed before inspecting the results. The selected period was
2023-08-11 to 2025-12-31; six rounded zero returns were retained. Raw data and
download metadata preserve the 202609 CRSP snapshot used. For comparable total
log returns, lag-one autocorrelation was -0.0387 in the US reference, versus
0.1754 and 0.1170 in the original/no-skew simulations. Autocorrelation of
absolute total log returns was +0.2079 in the reference but -0.0043 and -0.0032
in the simulations.

This comparison exposes a remaining diagnostic mismatch. It does not define a
universal target: the empirical series is a diversified US portfolio observed
in a particular regime, while the simulation is one small stock with a quiet
specified environment. The long paths contain rule traders; short LLM paths
have not established long-run stylized facts. A lower value gap or reduced
price-return dependence is therefore insufficient to establish market realism.

The [paired trade-off figure](../starter_code/runs/thesis_synthesis_20261105/background_tradeoff.pdf)
and [all-path background interpretation](../starter_code/runs/20261104_154730_market_validation_fff53e3b/supplement/INTERPRETATION.md)
retain all scenarios and qualifications.

### 5.3 Apparent component advantages can precede the component

All eighteen R043 markets completed twelve sessions, with 432 valid decisions,
24 genuine own-history reflections and no missing, failed or repaired calls.
The primary gap contrasts below average the two prespecified model draws within
each scenario. Negative values indicate a smaller gap. C-A is the transparent
sum of the two primary contrasts, included as descriptive context rather than
a new predeclared primary test.

| Scenario | B-A mean gap,pp | C-B mean gap,pp | C-A mean gap,pp |
|---|---:|---:|---:|
| 22853 | -0.5875 | -0.4125 | -1.0000 |
| 23971 | +0.4625 | -1.7500 | -1.2875 |
| 25087 | +7.0125 | -4.2125 | +2.8000 |

C had a smaller scenario-average gap than B in all three scenarios and in
five of six individual draw contrasts. The exception was scenario 22853,
draw two, where C-B was +0.1167 percentage points. This is a repeated bounded
policy-level pattern. It does not establish a uniform advantage over the raw
baseline: C-A worsened the average gap in scenario 25087. B-A itself had mixed
signs across scenarios and draws.

Individual passive excess did not follow a uniform market-gap ranking.

| Scenario | Meera C-B,auction/private pp | Arjun C-B,auction/private pp |
|---|---:|---:|
| 22853 | -0.450 / -0.442 | +4.771 / -0.156 |
| 23971 | +0.105 / -0.116 | -2.043 / +0.613 |
| 25087 | -0.341 / -1.304 | +0.128 / +3.056 |

Meera's private-value passive excess was lower under C in all three scenario
averages, despite the lower market gap relative to B. Arjun's sign reversed
between the two terminal marks in scenarios 22853 and 23971. These results
show why market-level valuation accuracy and individual trading outcomes must
be reported separately.

Known provider-reported token totals were 359,233 for A, 394,446 for B and
459,390 for C, across six equal-length markets per mode. C used 64,944 more
tokens than B, or 16.4646% in this campaign. Reflections accounted for 61,342
tokens; the decision-only difference was 3,602. One individual C-B contrast
cost 304 fewer tokens, while the other five cost more. There is no universal
per-decision price or cost multiplier implied by these campaign totals.

B and C initially receive identical messages, and the first reflection occurs
only after session five. Nevertheless, four of twelve first requested-order
pairs differed in side, quantity or limit price, all for Arjun. This post-hoc
all-case diagnostic illustrates model variation before reflection. C later
reflects on its own diverged history. The study therefore compares specified
endogenous policies on matched exogenous scenarios; it does not isolate a
particular reflection sentence while holding later states fixed.

An examiner-stage post-hoc audit found a more consequential baseline imbalance:
C's gap was already smaller than B's in all six paired runs during sessions1–5,
before the first reflection was used. Scenario-mean contrasts were:

| Scenario | C-B gap before reflection,1–5 pp | C-B gap later,6–12 pp |
|---|---:|---:|
| 22853 | -1.1900 | +0.1429 |
| 23971 | -1.3700 | -2.0214 |
| 25087 | -2.2300 | -5.6286 |

The whole-path advantage is therefore not evidence that reflection caused
better valuation accuracy. Later differences also include inherited states and
feedback. Subtracting these windows is not a validated difference-in-differences
estimate: no parallel-trends argument or matched later state was established.
The gap comparison remains descriptive;the cost and accounting observations
remain measured results. This diagnostic was added after the study and is not
retrospectively described as a prespecified primary endpoint.

The [R043 interpretation and full tables](../starter_code/runs/quiet_components_analysis_20261105/INTERPRETATION.md),
[all-draw gap/cost figure](../starter_code/runs/quiet_components_analysis_20261105/component_contrasts.pdf)
and [raw-source numerical report](../starter_code/runs/quiet_components_analysis_20261105/report.json)
preserve both model draws, all account groups, exposure and executed-flow windows.

### 5.4 Shared-history continuations show mixed reflection effects

All twenty-four R047 continuations completed their seven new sessions. All
accounts matched their donor's closing-five state before the first fresh call.
This removes the observed pre-treatment state imbalance from this comparison.
The following table shows all contexts; negative gap contrasts favour C.

| Scenario/context | C mean minus B mean gap,pp | B1-B2 gap,pp | C1-C2 gap,pp |
|---|---:|---:|---:|
| 22853/1 | -1.3571 | -5.9429 | -3.2286 |
| 22853/2 | 0.0000 | +1.2714 | +1.2714 |
| 23971/1 | 0.0000 | -1.1286 | -1.1286 |
| 23971/2 | +0.3286 | -0.6571 | 0.0000 |
| 25087/1 | 0.0000 | 0.0000 | 0.0000 |
| 25087/2 | -0.2286 | 0.0000 | +0.4571 |

Reflection narrowed the gap in two contexts, widened it in one and left the
mean gap unchanged in three. Equal means need not imply equal paths or wealth.
Averaging the two contexts within each scenario gives -0.6786, +0.1643 and
-0.1143 percentage points for scenarios 22853, 23971 and 25087 respectively.
There is no uniform directional improvement across these scenario means.

In every context, at least one of the absolute same-mode branch contrasts is
as large as the absolute between-mode mean contrast. This includes a context
where all three gap contrasts are zero. The comparison is descriptive: it
does not establish statistical equivalence, attribute every difference to
randomness, or prove reflection ineffective. It shows why a single run per
mode would provide an incomplete view of variability in this environment.

The individual return contrasts also depend on the trader and terminal mark.
Both marks use the same common-start denominator in each context.

| Scenario/context | Meera C-B,auction/private pp | Arjun C-B,auction/private pp |
|---|---:|---:|
| 22853/1 | -0.1519 / -2.1079 | -0.8483 / +5.2387 |
| 22853/2 | -0.0000 / -0.3888 | +0.0000 / +0.3854 |
| 23971/1 | 0.0000 / 0.0000 | +0.0179 / +0.0145 |
| 23971/2 | +0.0292 / -0.0480 | -0.2595 / -0.0100 |
| 25087/1 | -0.1391 / -2.3757 | +0.0086 / +0.1828 |
| 25087/2 | +0.1548 / +1.3167 | -0.1194 / +1.2922 |

Signed zeros are rounded nonzero contrasts where indicated; the unrounded
values remain in the report. In context 22853/1, Arjun's auction-mark contrast
is negative while its private-mark contrast exceeds five percentage points.
Even a smaller market gap consequently does not establish better individual
returns under both marks.

B used 553,704 known reported tokens and C used 695,560, a difference of
141,856 or 25.62% relative to B. There were 385 HTTP attempts for 384 successful
fresh calls, with one recovered B error attempt of unknown token usage. The
percentage therefore compares known reported usage, not exact all-attempt
cost. Reservations totalled 6,765,217 within the frozen 9.6M ceiling. No branch
is missing; no JSON repair, output truncation or reflection failure was recorded.

Audits reconstructed 4,032 account-round records, checked 385 fresh-attempt
histories and eighteen initial background-book comparisons. Saved-response
playback reproduced twenty-three paths and all 161 corresponding financial
CSVs byte for byte with network blocked. The completed B branch containing
the recovered error was explicitly not replayed, because exception-aware
playback is not implemented. Its raw evidence remains preserved. These checks
verify recorded execution; fresh provider reproducibility and external validity
are distinct questions.

R047 does not measure how much of the earlier R043 whole-path pattern arose
from baseline imbalance. It asks a new conditional question from six B-history
states using fresh requests and a different starting-account normalization.
Together, the studies support reporting pre-component diagnostics and same-mode
variation when interpreting an endogenous component comparison. Neither a
universal reflection benefit nor a universal absence of benefit follows.

The [all-context contrast figure](../starter_code/runs/common_prefix_analysis_20261105/common_prefix_contrasts.pdf),
[manual interpretation](../starter_code/runs/common_prefix_analysis_20261105/INTERPRETATION.md),
[numerical report](../starter_code/runs/common_prefix_analysis_20261105/report.json)
and [replay exclusions](../starter_code/runs/common_prefix_analysis_20261105/replay_report.json)
retain all branches, both traders and marks, cost and failure information.

### 5.5 Feedback timing and the loss of information in aggregate prices

The R050 audit counts distinct seven-session trajectories among the four
branches in each R047 context. Fill paths include quantities and transaction
values; target-account paths include cash and shares of both LLM traders.

| Context | Requested-order paths | Accepted-order paths | Fill paths | Target-account paths | Price paths |
|---|---:|---:|---:|---:|---:|
| 22853/1 | 4 | 4 | 4 | 4 | 3 |
| 22853/2 | 3 | 3 | 3 | 3 | 2 |
| 23971/1 | 3 | 3 | 3 | 3 | 2 |
| 23971/2 | 4 | 4 | 4 | 4 | 2 |
| 25087/1 | 4 | 4 | 4 | 4 | 1 |
| 25087/2 | 4 | 4 | 4 | 4 | 2 |

Thus, different executed-account paths coexist with identical price paths in
every context. In 25087/1 all four price trajectories coincide despite four
distinct order, fill and account trajectories. Of the 24 cross-mode branch
pairs, 22 differ in their account trajectories but only 11 differ in prices.
Account distinctness survives rounding cash to five decimal places. These are
dependent descriptive comparisons, not 24 independent tests or causal mediation
estimates. In the shared-state first auction, cross-mode requested orders differ
in 14 comparisons while prices differ in only two. This identifies why a zero
price-gap contrast cannot by itself establish behavioral or distributional
equivalence.

The reflection review identifies five temporal-misattribution examples, all
within context 23971/2 across two branches. For instance, Meera correctly used
the latest available price of 103.3 for her session-five decision. After that
auction cleared at 104.0, her reflection described the earlier number as a
reading mistake. Both branches later repeated related self-corrections despite
correct decision-time price references. One Arjun example also substitutes a
later clearing decline for the previously observed direction; its earlier
explanation separately exaggerates the number of rising closes. Two reflections
in one other Arjun branch claim that market orders guarantee fills, although
their own history includes partial execution. These seven flagged texts are
nested observations, not independent error replications or an estimate of all
reflection inaccuracies.

The old feedback presents a generic price alongside earlier order reasoning
inside a block labelled verified outcomes. The numerical records remain correct,
but their interpretation can confuse timing and the status of generated prose.
A new opt-in adapter records the last price available when deciding separately
from subsequent clearing and post-settlement accounts, and labels the earlier
explanation as unverified. It applies the same factual representation to A/B/C.
Offline checks show economic invariance under identical replies and correct
information timing. No fresh model comparison establishes that this correction
reduces errors or improves financial outcomes. Original studies and defaults
retain their original version. The [audit and correction record](FEEDBACK_AND_BACKGROUND_REVIEW.md)
links all source texts, annotations and executable checks.

A subsequent fixed-history comparison, R052, froze all twelve first-reflection
actor histories from the six inherited contexts, with two fresh responses per
original/corrected format. It stopped after eight of forty-eight planned replies
when the ninth slot received HTTP 503 twice, including the permitted identical-
message retry. The delivered replies cover both personas in two histories of
seed 22853, with one draw per format. Focused, nonblinded review identified
neither targeted timing errors nor unsupported full-fill guarantees in these
eight replies. Forty missing slots, including the known timing-error context
23971/2, prevent an improvement or equivalence conclusion. A corrected-format
reply nevertheless confused a 5.6% stock-price rise with portfolio wealth growth,
which was about 2.897%. This is an ancillary arithmetic example, not the
prespecified timing-error outcome. The attempt used 26,788 known reported tokens
over ten HTTP attempts; two failed attempts have unknown usage. The
[frozen protocol and partial assessment](FEEDBACK_VALIDATION_PROTOCOL.md)
retain all missing cases and distinguish reflection content from subsequent
trading performance. No market continuation or restart was performed.

### 5.6 The inventory trade-off survives one less synchronized background

R050 found identical within-group orders from the three background fundamentalists
and four momentum traders in all 216 R043 market-sessions for each group. R051
therefore tests whether the earlier skew result depends on that synchronization.
All sixteen new rule-only markets completed, with zero provider or network
requests. The following are no-skew-minus-skew contrasts; the interaction is
the heterogeneous contrast minus the homogeneous contrast.

| Seed | Homogeneous ACF1 delta | Heterogeneous ACF1 delta | Interaction | Homogeneous boundary delta,pp | Heterogeneous boundary delta,pp |
|---|---:|---:|---:|---:|---:|
| 26183 | -0.006428 | -0.102209 | -0.095781 | +1.167 | +1.667 |
| 27329 | -0.074986 | -0.097649 | -0.022663 | +5.333 | +5.667 |
| 28513 | -0.159922 | -0.255097 | -0.095175 | +0.500 | +2.833 |
| 29671 | -0.084808 | -0.092784 | -0.007977 | +9.167 | +1.833 |

Removing inventory skew reduces full-path return dependence and increases
inventory-boundary time under both backgrounds in all four fresh scenarios.
The ACF1 reduction is larger under this heterogeneous bundle in all four.
These are four scenarios with nested settings, not eight independent confirmations.
Momentum-order synchronization falls substantially in the heterogeneous runs,
but this change does not isolate synchronization from the altered trading rules.

Heterogeneity is not a uniform improvement. With the original skew, mean gaps
are higher under the heterogeneous bundle in all four scenarios. In scenario
29671 the gap rises from 6.690% to 21.003%; the heterogeneous path ends at 217.5
against the unchanged benchmark of 100. Its last 200-session gap is 54.866%,
although that block's return ACF1 is only 0.0022. All four fundamentalist
accounts hold zero shares by session450 and remain unable to sell short.
This observed sequence is consistent with constrained corrective trading,
but does not independently identify inventory exhaustion as the cause of the
run-up. With no skew, the heterogeneity-induced gap changes have mixed signs.
No heterogeneous or no-skew setting is selected as a new default.

The [all-case contrasts](../starter_code/runs/background_diversity_20261106/review/background_diversity.pdf)
and [all sixteen price/inventory paths](../starter_code/runs/background_diversity_20261106/review/all_paths.pdf)
retain this adverse case. Independent arithmetic reconstruction checks all
134,400 account-rounds, with maximum cash discrepancy about 5.60e-10. These
checks establish internally consistent execution, not external realism or
independent-machine reproduction. The new result strengthens the bounded
background trade-off while exposing another reason that a favorable correlation
statistic cannot establish good valuation behavior.

### 5.7 Large trading presence does not uniquely determine price influence

All 432 R054 conditional interventions completed with no model calls. Cap10
changes accepted quantities in 105 of 216 auctions and changes prices in 49:
22.7% of all auctions, or 46.7% of the affected subset. Mean absolute price change
is 0.711% of the preceding actual price over all auctions and 1.462% over the
affected subset. The 111 unchanged-input auctions remain explicit controls.
Every one of the eighteen inherited paths contains at least one price-changing
cap intervention. Counts by mode are 17/72 in A, 17/72 in B and 15/72 in C; these
different inherited books do not identify mode effects.

| Seed | Cap price changes /72 | Mean absolute cap effect (% previous price) | Cap volume reduction (%) | Removal price changes /72 |
|---|---:|---:|---:|---:|
| 22853 | 18/72 | 0.699430 | 17.576 | 33/72 |
| 23971 | 20/72 | 0.524646 | 14.403 | 23/72 |
| 25087 | 11/72 | 0.907597 | 13.987 | 18/72 |

Summed over these isolated auctions, cap10 reduces executed volume from 5,118
to 4,339 shares (15.22%); joint suppression reduces it to 3,801 (25.73%). Reducing
orders cannot increase maximum executable volume in this mechanism, so the
direction alone is not a novel finding. The extent and associated price effects
matter. Suppression changes prices in 74/216 auctions, or 74/137 with an active
target order. Target fills change at an unchanged price in 27 cap cases and 44
suppression cases. The
[all-path figure](../starter_code/runs/order_influence_analysis_20261107_v2/order_influence.pdf)
and [full table](../starter_code/runs/order_influence_analysis_20261107_v2/READOUT.md)
retain both interventions and all eighteen paths.

An extreme example makes the distinction tangible. In seed 25087, A, draw 1,
session 4, the LLMs participate in 59 of 60 executed shares. Capping them reduces
volume to 13; suppressing both orders reduces it to 3, yet all three prices
equal 111.9. The residual background bid still crosses the maker's ask at that
price. This example was selected after analysis as the largest volume reduction
without a price change, not as a representative market. Conversely, the twelve
cap interventions in seed 22853, C, draw 1 preserve every factual auction volume
(203 shares in total), while three change the clearing price. Large participation,
volume loss and price influence are therefore distinct in this cohort.

Influence is not uniformly harmful. The largest absolute cap price change,
selected by its stated post-analysis extreme rule, occurs in seed 22853, B,
draw 1, session 10. A 15-share bid at 91 and a 141-share market buy become two
ten-share orders. Price/volume move from 98.6/48 to 90.1/28. Against the fixed 100
reference, the absolute gap widens from 1.4% to 9.9%; the original large orders
support a price closer to the reference. Across all 216 frames, the cap narrows
the gap 37 times, widens it 12 times and leaves it unchanged 167 times. Suppression
gives 45/29/142, respectively, and worsens the average gap in seed 23971. These
counts are descriptive and nested; they do not establish a superior cap policy.

The result establishes immediate mechanical influence conditional on each
observed book. It neither treats the known distinction between volume and
impact as a new economic law nor measures separate additive contributions of
the two LLMs. Fixed background responses, inherited endogenous histories and
no subsequent adaptation limit the inference. An independent price-selection
and cash/share calculation verified all 432 outputs and 6,048 settlements;
this supports internal consistency, not human-market validity.

## 6. Discussion and limitations

The scientific contribution is clearest when separating measured results from
established mechanisms and proposed generalizations.

| Result family | Contribution supported by these experiments | Boundary |
|---|---|---|
| Execution and measurement | Preserved matched cases quantify individual execution/wealth changes hidden by price or aggregate flow | The general possibility of transfers at unchanged prices is established accounting,not an invented economic mechanism |
| Market background | Two separate four-seed studies retain the return-dependence/inventory trade-off;the second also crosses two backgrounds and exposes adverse valuation paths | The twelve background pairs are not twelve independent scenarios;inventory control has an expected role and no empirically selected optimum follows |
| Information components | Pre-component diagnostics and shared-history continuations expose mixed effects,cost and same-mode variation in this market | No new theory of reflection,proof of no effect,or isolated content-versus-length mechanism |

These are conditional empirical cases and an auditable evaluation procedure.
Their value does not require claiming that each observation is a new economic
law. More elaborate memory and a lower valuation gap are candidate properties
to examine, not definitions of a better human-market simulator.

The studies support a common methodological conclusion: evaluation depends on
which level of the market is measured and what the comparison holds fixed.
The news study demonstrates that unchanged prices need not imply unchanged
trading or individual outcomes. The background study shows that one diagnostic
can improve alongside a deterioration in liquidity-provider inventory behaviour.
The component studies show that an apparent advantage can precede reflection;
after matching actual prior histories, the conditional results remain mixed
alongside same-mode variation and higher known reported usage. Smaller
market-level gaps can also coexist with mixed individual returns. No single outcome
provides a sufficient ranking of agent realism or policy quality.

Execution opportunities are central to interpretation. A trader may choose
not to buy, avoid a planned sale, encounter a binding resource constraint or
submit an eligible order that loses price priority. BUY/HOLD/SELL counts and
accepted quantities alone do not distinguish these possibilities. Actual fills,
opening resources and counterpart accounts provide the additional information.
Generated explanations are useful qualitative records but are not direct
observations of latent beliefs or human cognition.

R050 adds a concrete representation limitation: an authentic decision record
can become a false lesson when a reflection evaluates it against information
that arrived later. The observed misattributions motivate explicit timing
labels, but their financial impact and the correction's behavioral efficacy
remain unmeasured. R051 separately shows that one inventory trade-off survives
a less synchronized background, while heterogeneity can worsen valuation gaps.
Neither richer prose nor greater parameter diversity is an automatic realism
improvement.

Evidence for internal consistency is stronger than evidence for external
validity. In R043, 456
actual-history request checks and 24 reflection-chain checks passed, while
independent financial reconstruction covered 3,528 account-rounds with maximum
cash error approximately 2.91e-11. R041 likewise checked actual histories and
accounts. Such audits support confidence that the recorded mechanism operated
as specified. They do not validate the dividend process, personas or market
statistics against human behaviour.

The examiner audit reproduced all eight R039 rule paths, sixteen R041 paths
and eighteen R043 paths from archived executable sources and recorded replies:
42 paths and 294 byte-identical financial CSVs. R047 adds 23 verified paths
and 161 CSVs, with its one exception stated above. These saved-response replays
do not constitute new model samples or independent replications. The R043
archive omitted a transitive helper; an explicit supplement from a prior sealed
archive enabled replay, leaving the original archive unchanged. R047 captured
the full helper set before its live calls. The archive receipts document this
packaging history rather than silently presenting the original bundle as
self-contained.

Several limits restrict generalization. Only one live model, two bundled
personas and a small mixed population are studied. Provider randomness is
unseeded; common exogenous scenarios do not create paired language-model draws.
The news study contains two scenarios and initial truthful downside bulletins,
without established trends or false-news conditions. The component study has
three exogenous scenarios and short quiet horizons. The shared-history study
reuses six B contexts within those same scenarios; its seven-session
continuations and two fresh draws per mode do not provide broad precision.
The diary intervention changes both content and context length. It does not establish
general reflection benefits or long-run LLM market properties. The empirical
reference is useful context but differs in diversification and institutional
structure from the simulated stock.

The development history also matters. Earlier studies include retained capped
outputs, provider failures and partial markets. Some used ambiguous bulletin
wording or disclosed episode length. They should appear in the appendix and
methods history with their exact settings, not be merged with later cohorts or
presented as causal before/after improvements. A local archive-packaging error
after R043 was corrected by normalizing paths; no experimental or numerical
analysis rerun was required. Routine delivery and packaging fixes belong in
reproducibility documentation rather than the headline result narrative.

Several modelling choices materially affect realism. Hidden-value
fundamentalists extrapolate the latest paid dividend at window1;in the baseline
this produces a value proxy between80 and120 around a fixed100 benchmark from
dividend noise alone. This is a deliberately simple heuristic,not a calibrated
belief process. Dividend payments occur every session,mean changes are permanent,
and there is no continuous order-book latency or empirically estimated social
network. These choices make a tractable laboratory rather than a replica of a
particular exchange. A single batch per session does not represent continuous
intraday trading.

Equal endowments also do not imply equal trading intensity. In the eighteen
R043markets,the two LLM accounts appeared on at least one side of approximately
24.9%–79.6% of traded share volume. Their per-market median positive accepted
order sizes ranged from15 to80shares,versus5–9 for background orders. These are
post-hoc sizing diagnostics,not realism targets. They limit interpretation of
population comparisons as an effect of decision intelligence alone.

R054 moves this diagnostic beyond order-size description. Reducing target
quantities changes prices within all eighteen existing paths, while some
large-volume interventions leave price unchanged. Other interventions move
price farther from the valuation reference. A population comparison should
therefore distinguish account count, resources, order aggressiveness and
actual price influence. These results do not tell us how background traders
would adapt if six or ten LLMs replaced them, or if a cap were announced and
enforced throughout a live market.

The underlying dividend regime is stationary between shocks,but market wealth
is not fixed:dividends and cash interest are external injections. R039 aggregate
cash grew about24.31% on average over600sessions. Statistical stationarity of
the resulting market cannot be assumed from the dividend specification. Finally,
price-gap convergence to a researcher-defined,risk-neutral perpetuity reference
is not proof that agents have rational or human-like valuations. The observed
absolute-return diagnostic mismatch remains a substantive validation gap.

Further work should follow a specific claim rather than an unrestricted feature
list. Human-behaviour validation would need a suitable human reference and
matched operational definitions. Long-run LLM stylized-fact claims would need
longer live paths and appropriate independent replication. Isolating reflection
content from added context would require a matched sham condition; wider
repeatability claims would require additional independent histories and draws.
R047 controls actual starting histories and displays same-mode variation, but
does not supply those further controls. None of those broader claims is
necessary to report the bounded findings
established in the current experiments.

The [review record](MANUSCRIPT_REVIEW.md) separates issues resolved in this
revision from remaining judgments about scope and originality. The
[reproduction guide](REPRODUCIBILITY.md) identifies offline checks, preserved
source requirements and replay coverage. Those records support review of the
claims; they do not constitute external examiner approval.

## 7. Conclusion

The conditional order intervention strengthens the execution result: a small
LLM population can influence prices, but its trading-volume share is not a
measure of that influence. Capping large orders changes 49 of 105 affected
auction prices, sometimes worsening reference valuation; even near-total
LLM volume participation can coexist with an unchanged price after their
orders are suppressed. These are bounded effects inside observed auctions,
not long-run policy recommendations or evidence of human realism.

This thesis develops and examines a controlled LLM-agent stock-market
simulation with explicit execution, accounting and comparable information
representations. Its experiments show that price-only and aggregate measurements
can conceal individual responses, that background-market changes involve
diagnostic trade-offs,and that the information conditions exhibit different
gap,return and cost outcomes. Pre-reflection differences prevent interpreting
the whole-run C-B gap pattern as a demonstrated reflection benefit. Fresh
shared-history continuations subsequently produced mixed gap and individual
return effects, alongside same-mode variation and greater known reported
token use. The contribution is an auditable account of these
conditional observations and their limitations. It does not depend on claiming that
the simulator reproduces human markets or that a more elaborate agent is
universally better.

The retrospective feedback audit and fresh rule-only diversity study extend
this conclusion: execution and account differences can disappear from price
comparisons, timing ambiguities can enter generated reflections, and a robust
inventory trade-off can coexist with severe valuation failures. These results
motivate targeted representation checks and sensitivity analysis rather than
selecting a more elaborate default without evidence.

The strongest replicated background result and the matched execution
counterexamples answer different questions: one documents a repeated trade-off
within specified rule markets; the other shows why price equality is insufficient
to identify individual outcomes. The component comparison then demonstrates why
comparable prior histories are necessary before attributing a difference to
reflection. The incomplete R052 attempt does not validate the feedback correction.
Together, these results support a bounded evaluation methodology while leaving
human-market fidelity and general policy superiority unresolved.

## Appendix sources and selected actual inputs

[Appendix A](appendix/SELECTED_PROMPTS.md) contains exact saved persona records
and five deterministically selected Meera prompt examples from the first R043
scenario/draw:initial A/B/C decisions,C's first reflection and the following
decision. Its [JSON provenance](appendix/selected_prompts.json) records source
hashes,versions and exact messages. Initial B/C inputs match;later C history
is its own. Generated reflection beliefs are not labelled verified facts.

The remaining appendix assembly should include
normalized study configurations and source/model versions; all primary
contrasts; resource/accounting checks; both terminal valuation definitions;
retained partial/missing/failed outcomes from earlier cohorts; and the run,
figure and evidence-archive inventory. Select examples transparently and retain
links to the full raw evidence. Credentials and `.env` files are excluded.

Primary evidence records:

- [R039 full report](../starter_code/runs/20261104_154730_market_validation_fff53e3b/report.json).
- [R041 full report](../starter_code/runs/downside_confirmation_analysis_20261104/report.json).
- [R043 protocol and exact design](../starter_code/runs/20261105_012335_quiet_components_5066abab/protocol.json).
- [R043 all-case interpretation checks](../starter_code/runs/quiet_components_analysis_20261105/interpretation_checks.json).
- [R047 frozen design](../starter_code/runs/20261105_041035_common_prefix_ca10f93d/protocol.json).
- [R047 all-context results](../starter_code/runs/common_prefix_analysis_20261105/report.json).
- [R047 completion and evidence receipt](../starter_code/runs/20261105_041035_common_prefix_ca10f93d/postprocessing_summary.json).
- [Study and replay inventory](appendix/STUDY_INVENTORY.md).
- [Model-description map](appendix/MODEL_DESCRIPTION_MAP.md).
- [Offline reproduction instructions](REPRODUCIBILITY.md).
- [Durable research diary](../RESEARCH_DIARY.md).

These local links identify experimental evidence. The working scholarly
bibliography is [references.bib](references.bib);final metadata,publication
versions,citation style and formal document cross-references remain on the
writing checklist. [FIGURES_AND_APPENDICES.md](FIGURES_AND_APPENDICES.md) gives
draft captions and exact appendix sources.
