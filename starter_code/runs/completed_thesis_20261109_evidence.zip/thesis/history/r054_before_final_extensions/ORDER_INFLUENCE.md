# LLM order size, volume participation and immediate price influence

R054 completed, 2026-11-07. This extension addresses an existing interpretation
gap using all 216 saved auctions from the eighteen R043 markets. It adds 432
isolated auction calculations, no provider requests or new adaptive market paths.
The earlier writing is preserved in [the R053 snapshot](history/r053_before_order_influence/THESIS_DRAFT.md).

## Why this extension takes priority

Only two of fourteen accounts use an LLM, but those accounts participate in
approximately 24.9%-79.6% of executed share volume across the existing markets.
Counting agents therefore understates their trading presence. That presence
does not itself establish that they determine prices. The useful question is:
**How much do their large orders change the immediate clearing outcome, given
the rest of the actual market?** This strengthens the thesis's execution and
measurement argument without introducing a different behavioral model.

| Suggested extension | Assessment at this stage |
|---|---|
| Transaction taxes .002/.005 | Feasible future policy sensitivity, but adds a new research question. Lower turnover or mechanically lower net wealth alone would be weak findings; incidence, liquidity and adaptation would need a designed comparison. |
| BBS/herding | A board adds communication; it does not by itself establish herding. Information controls and a defensible measure of correlated behavior would be needed. |
| Circuit breakers | Useful for a stability-policy thesis, but halt thresholds, reopening rules and an explicit price-discovery/liquidity trade-off must be specified. |
| Finish R052 | The original protocol stopped the whole study on failure. Its 8/48 outcome remains closed. A future feedback study would need a new protocol, with the known error contexts retained and no selective replacement of missing cells. |
| Six to ten LLMs | Scientifically relevant, but account count, aggregate resources and order sizes need disentangling. The present intervention first measures how much the existing two accounts matter. |
| Longer paths/local model | Needed for long-run LLM claims. Switching model while extending the horizon changes two factors and cannot extend the present model's evidence. Neither a 25-round path nor a smaller local model automatically supplies realism. |

These are judgments about the current thesis's scope, not claims that the
deferred topics are unimportant. No later campaign is automatically scheduled.

## Design and controls

The source cohort has three exogenous seeds, two provider draws, three modes
A/B/C and twelve sessions per path. The eighteen paths, 216 nested auctions
and 432 hypothetical clears are different units, not independent replications.
All source auctions were included, including inactive target orders.

Before calculating the interventions, the driver reconstructed every actual
auction's price, ordered trade list and closing accounts. The 216 price/trade
checks and 3,024 account checks passed; maximum account residual was about
1.14e-13. The source revision is
`0f80f2cfaa6b1059ecbf5c2ded9ffe91640195a6`; the dirty working tree and exact
source/input hashes are recorded in the protocol. Original R043 model settings
and replies remain inherited evidence, not new model observations.

For each auction, each intervention starts independently from its actual
opening accounts, preceding actual price and exact allocation-generator state:

1. **Cap10:** reduce each LLM's accepted order to at most ten shares, retaining
   its side and limit. Ten is the existing zero-intelligence maximum order and
   maker quote size; it is not optimized or empirically calibrated.
2. **Remove:** suppress both LLM orders while retaining their accounts and
   endowments. All background orders stay fixed in both interventions.

The cap is applied after the original feasibility check. Background traders
do not reconsider their orders, and LLMs do not respond to a changed fill.
No hypothetical account, price or allocation-generator state enters the next
frame. A sequence of these outputs is consequently **not a simulated price
path under a permanent cap**. Joint removal also does not identify each
trader's separate contribution or additive contributions when orders interact.

The design was frozen before the new auction outcomes, with SHA256
`37661f94606ee36002245eaefdcec326c8e1aeaf656abab14eab7204d37f34fe`.
It was motivated by an existing sizing diagnostic in this same cohort; it is
not externally preregistered or a held-out validation study.

## Findings

| Intervention | Prices changed / all auctions | Mean absolute price effect (% preceding actual price) | Total executed volume reduction | Changed target fills with unchanged price |
|---|---:|---:|---:|---:|
| Cap10 | 49/216 (22.7%) | 0.711% | 15.22% | 27 |
| Remove both orders | 74/216 (34.3%) | 0.978% | 25.73% | 44 |

The cap changes an accepted quantity in 105 auctions. Among those, prices
change in 49/105 (46.7%), and mean absolute price effect is 1.462%. The other
111 auctions are unchanged-input controls. Both denominators matter: 22.7%
alone combines active interventions with cases where the cap does nothing.
There are 137 auctions with an active target order; joint removal changes
prices in 74 of them (54.0%), with the remaining 79 auctions serving as
inactive controls. No confidence interval is inferred from these nested frames.

| Seed | Cap changed prices / 72 | Cap mean absolute effect (%) | Cap volume reduction (%) | Removal changed prices / 72 |
|---|---:|---:|---:|---:|
| 22853 | 18/72 | 0.699430 | 17.576 | 33/72 |
| 23971 | 20/72 | 0.524646 | 14.403 | 23/72 |
| 25087 | 11/72 | 0.907597 | 13.987 | 18/72 |

Every one of the eighteen paths contains at least one price-changing cap
intervention. Cap price-change counts are 17/72 in A, 17/72 in B and 15/72 in C.
These are summaries of different inherited books, not causal mode comparisons.
The [full readout](../starter_code/runs/order_influence_analysis_20261107_v2/READOUT.md)
shows every path and both interventions; the
[figure](../starter_code/runs/order_influence_analysis_20261107_v2/order_influence.pdf)
displays their price and volume effects together.

Two examples illustrate why the measures should remain separate. They were
selected after analysis using explicit extreme-value rules; they are not
representative cases or additional independent experiments.

- **Largest volume reduction at unchanged price:** seed25087, A, draw1,
  session4. LLM orders are a market sell of50 and market buy of59. The LLMs
  participate in59of60 actual traded shares. Cap10 reduces volume to13;
  removing both orders reduces it to3. All three auctions clear at111.9.
  With removal, the remaining three-share bid crosses the maker's ask,
  normalized upward to111.9. High volume participation does not imply a
  necessary contribution to this auction's price.
- **Largest absolute cap price effect:** seed22853, B, draw1, session10.
  The LLMs submit a15-share bid at91 and a141-share market buy. Actual
  price/volume are98.6/48; capped price/volume are90.1/28. The price change
  is9.36% of the preceding90.8. The reference is100, so the cap increases
  the absolute valuation gap from1.4% to9.9%. Here the original large
  buy supports a price closer to the reference.

The opposite separation also occurs: in seed22853, C, draw1, all twelve
cap interventions preserve their factual auction volumes (203 shares summed),
yet three change the price. Quantity can change which price maximizes execution
without changing the maximum volume.

Across all auctions, the cap narrows the reference gap37times, widens it12times
and leaves it unchanged167times. Removal yields45/29/142, respectively; its
mean gap effect even worsens in seed23971. A lower average gap is not a universal
improvement, calibrated policy recommendation or welfare gain. Reduced volume
is mechanically weakly guaranteed when orders are reduced in this
maximum-volume mechanism; its occurrence is not itself a novel discovery.

The substantive result is the measured separation between large trading
presence, immediate price influence and valuation direction. It refines the
claim that two LLMs are economically negligible, while also preventing volume
share from being used as a proxy for their price contribution. This distinction
has established microstructure precedents: Cont, Kukanov and Stoikov compare
volume and order-flow-imbalance relationships with prices in actual order-book
data. Their [abstract and metadata](https://arxiv.org/abs/1011.6402v3) were
reviewed; this batch-auction intervention is not a replication of their
continuous-market estimates or a claim to discover the distinction first.

## Verification and reproduction

The [frozen protocol](../starter_code/runs/order_influence_20261107/protocol.json),
[factual gate](../starter_code/runs/order_influence_20261107/factual_verification.json),
[complete outcomes](../starter_code/runs/order_influence_20261107/results.json)
and [analysis report](../starter_code/runs/order_influence_analysis_20261107_v2/report.json)
retain every frame, trade and counterfactual account. An independent calculation
of candidate-price selection, volume and cash/share flows passes for all432
outcomes and6,048 account settlements. Three driver tests cover isolation and
no-op controls; four analysis tests include intentional price/cash/share
corruptions. These establish internal computational checks, not external validity.

From `starter_code`, check and regenerate summaries into a new output folder:

```powershell
python -B -m unittest tests.test_order_influence tests.test_order_influence_analysis -v
python -B -m research.analyze_order_influence --study runs/order_influence_20261107 --output runs/order_influence_reader_01
```

This needs the pinned R043 inputs and sources listed in the protocol. The
evidence pack includes the direct financial inputs and R054 source snapshot;
full original prompts/replies remain in the separate R043 evidence archive.
Never rerun `run` into the completed study. The initial analysis folder retains
a relative-path packaging failure; the corrected analysis in `_v2` reads the
same unchanged outcomes. No auction or provider request was repeated for that fix.

Remaining limitations are substantial: fixed background responses, endogenous
historical books, three existing scenarios, one short-horizon model/persona
cohort, no permanent-cap adaptation, no long-run market validation and no human
reference. A/B/C and all original economics/defaults remain unchanged. R052
remains closed at8/48; formatting remains deferred.
