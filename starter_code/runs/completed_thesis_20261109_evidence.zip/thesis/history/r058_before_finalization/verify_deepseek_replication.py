"""Offline verification of final R058 two-seed results and disclosed retry policy."""
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
REPO=HERE.parent
BASE=REPO/'starter_code'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def check():
    root=BASE/'runs/goedel_seed2_backoff_20261109';analysis=BASE/'runs/deepseek_replication_analysis_20261109'
    protocol=read(root/'protocol.json');summary=read(root/'summary.json');report=read(analysis/'report.json')
    assert summary['status']=='completed' and summary['completed_rounds']==25 and summary['delivered_decisions']==150
    assert protocol['authorization_sha256']==digest(root/'authorization_snapshot.json')
    assert digest(root/'protocol.json')==read(root/'preparation.json')['protocol_sha256']
    assert digest(root/'source.zip')==protocol['source_zip_sha256']
    assert digest(root/'config.yaml')==protocol['config_sha256']
    for n,h in {**protocol['source_sha256'],**protocol['inputs_sha256']}.items():assert digest(BASE/n)==h,n
    for directory in (root,analysis):
        for n,h in read(directory/'output_manifest.json').items():assert digest(directory/n)==h,n
    assert report['completed_market_scenarios']==2 and [r['seed'] for r in report['reports']]==[30841,31991]
    assert report['reports'][1]['summary']==summary
    assert sum(r['audit']['account_rounds'] for r in report['reports'])==700
    assert sum(r['complete_actual_input_pairs_checked'] for r in report['reports'])==300
    assert report['previous_aborted_attempts_retained']==2 and report['previous_unexecuted_reply_excluded']
    for name in ('market_table.md','persona_table.md'):
        table=(analysis/name).read_text(encoding='utf-8').strip()
        assert table in (HERE/'DEEPSEEK_REPLICATION.md').read_text(encoding='utf-8')
        if name=='market_table.md':assert table in (HERE/'THESIS_DRAFT.md').read_text(encoding='utf-8')
    auth=read(REPO/'DATA_COLLECTION_AUTHORIZATION.json');assert auth['status']=='closed_after_seed31991'
    assert auth['completed_protocol_sha256']==digest(root/'protocol.json')
    assert auth['completed_output_manifest_sha256']==digest(root/'output_manifest.json')
    before=HERE/'history/r057_before_backoff'
    for n,h in read(before/'snapshot_manifest.json')['files'].items():assert digest(before/n)==h,n
    usage=summary['usage'];assert usage['requests_made']<=600 and usage['reserved_tokens']<=8000000
    delivery=report['seed31991_new_delivery'];assert delivery['http_attempts']==usage['requests_made']
    return dict(r058_completed_scenarios=2,r058_completed_decisions=300,r058_audited_account_rounds=700,
        r058_seed31991_decisions=150,r058_seed31991_http_attempts=usage['requests_made'],
        r058_seed31991_rate_limit_retries=delivery['rate_limit_retries'],
        r058_known_tokens=usage['provider_reported_tokens'],r058_unknown_usage_errors=usage['unknown_usage_requests'],
        r058_collection_exception_closed=True,r058_previous_failed_attempts_retained=2)


if __name__=='__main__':print(json.dumps(check(),indent=2))
