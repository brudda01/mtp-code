# Current data-collection status

Collection is closed after completed seed31991 (2026-11-09). The explicit
[authorization](DATA_COLLECTION_AUTHORIZATION.json) is now closed. R056/R058
contains two completed25-round markets,300decisions total, at seeds30841 and31991.
Do not run further model requests, scientific simulations, restarts or missing-slot
completion. R052 remains closed. Saved-evidence analysis/writing, offline exact
reproduction and mock tests are allowed. Formatting remains last.

The older DATA_COLLECTION_FROZEN.json/.md describe the R057 closure snapshot.
Their bytes are retained for historical verification; this status and the closed
authorization supersede their obsolete one-completed-scenario count.
