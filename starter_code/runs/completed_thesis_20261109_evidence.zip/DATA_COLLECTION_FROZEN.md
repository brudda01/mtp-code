# Data collection permanently frozen

Collection closed on 2026-11-08 at the user's request. The machine-readable
[freeze record](DATA_COLLECTION_FROZEN.json) pins the final study protocols and
output manifests. No API job remains active.

Do not start another provider request, scientific market, seed, parameter sweep
or counterfactual dataset. Do not resume, restart or fill missing slots in any
closed study, including R052 and DeepSeek seed31991. Earlier proposals and
launch instructions are historical and do not authorize collection.

Saved-evidence analysis, thesis writing, credential-free and network-blocked
exact reproduction, and explicitly labelled offline mock tests remain allowed.
Department formatting remains the last stage.

R056 has **one completed market scenario**, seed30841: 25 rounds and150 valid
decisions. The final seed31991 attempt was stopped by HTTP429 before any auction
cleared. Across its original attempt and one disclosed transport amendment,
three HTTP attempts delivered one unexecuted reply;149 decisions remain missing.
This is not a completed two-seed cohort. Missing price, inventory and return
outcomes are unavailable, not zero. See the
[closure and limitations](thesis/FINAL_COLLECTION.md).

Both new final-seed launchers check the freeze marker before provider access.
Historical frozen source code is preserved unchanged. This is a project policy
and launcher guard, not an operating-system network lock.
