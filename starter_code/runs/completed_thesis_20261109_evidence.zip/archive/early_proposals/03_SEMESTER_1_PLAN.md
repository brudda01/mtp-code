# 03 · Semester 1 Plan — build & validate (≈16 weeks)
Goal: a working LLM-agent stock exchange, validated against stylized facts, with one headline behavioral result, and a solid report. Effort is deliberately front-loaded into weeks 2–8; the back half is buffer + writing.

**Weekly rhythm**: 2 coding-agent sessions (use `05_CODING_AGENT_PROMPTS.md` in order) + 1 hour reading (`01_CONCEPTS_PRIMER.md` + one paper section) + git commits + a 5-line progress log (this log becomes your report's "work done" section almost for free, and is your answer whenever the prof asks "what did you do this month?").

---

### Week 1 — Setup & understanding
Install Python 3.11+, git, VS Code + your coding agent; create repo; copy `starter_code/` in; run `python -m sim.engine --config configs/dev_mock.yaml` (mock LLM — must work day 1). Read Primer Parts A–C. Skim AgentSociety abstract/intro/discussion, MALLES, Eco3S abstracts. Get an API key (or install Ollama + `ollama pull llama3.1:8b` / `qwen2.5:7b` as free fallback). Deliverable: repo with starter running + 1-page project summary in your own words (send to prof — good first impression).

### Weeks 2–3 — Market engine hardening (Milestone M1 target: end wk 4)
Prompts P1–P4: config system, call auction with price priority + rationing + price bands, dividend/fundamental process, full rule-based roster. Tests green. Run 500-round all-rule-agent simulations; verify: fundamentalist-heavy runs track F; momentum-heavy runs trend/oscillate; ZI-only stays bounded near F (Gode–Sunder sanity). Deliverable: 3 plots + short note "market engine behaves per theory."

### Week 4 — Metrics module + M1 review
Prompt P5: `metrics.py` (stylized-facts battery per `06_...md` §1) + auto-plots. Apply to rule-based runs (expect only partial stylized facts — that's the point; LLM/mixed runs should do better later, and if they don't, that's a finding). **M1 = show prof**: engine demo, rule-agent dynamics, metrics. Ask explicitly whether they want the senior's ODE agent equations to port in as another rule-agent type (ideal for the comparison chapter — get the equations now, even a photo of his notes).

### Weeks 5–6 — LLM agent (Milestone M2 target: end wk 8)
Prompts P6–P8: LLM client (+mock parity tests), personas, LLM agent with validation/repair/memory. First live run: 5 LLM agents + 1 market maker + 5 ZI, 30 rounds, mini model (< $0.20). Read 20 `llm_calls.jsonl` reasoning strings personally — you will quote 2–3 in the report and viva ("agent Meera held because she 'didn't trust the rally after the dividend cut'"). Fix prompt bugs (units, missing context) — keep a prompt changelog.

### Week 7 — Scale & stabilize
Concurrency (P9), cost meter checks, 20 LLM agents × 100 rounds (~$0.5–1.5). Track failure metrics: JSON-parse fail rate (< 5% target after retry), repaired-order rate, HOLD-fallback rate. Tune temperature 0.7; verify agents aren't clones (pairwise action-agreement stat in metrics).

### Week 8 — M2 review + first real experiment
**M2 = show prof**: live(ish) demo of LLM agents trading with reasoning excerpts, price chart, cost report. Then run **Experiment S1 (headline of Sem 1): do stated personas produce measurable behavior?** Config: 24 LLM agents = 8 risk-averse/loss-averse, 8 aggressive/overconfident, 8 balanced; 150 rounds; 3 seeds. Measure per group: trade frequency, avg position size, disposition-effect ratio P(sell|gain)/P(sell|loss), reaction to the scripted no-fundamental-effect news. Hypotheses: aggressive trade more & bigger; loss-averse show disposition effect > 1; everyone overreacts to noise news. Any outcome is reportable.

### Weeks 9–10 — Stylized-facts validation (Milestone M3 target: end wk 12)
**Experiment S2**: mixed population (20 LLM + 10 rule + 1 MM), 300 rounds × 3 seeds; run the full stylized-facts battery; compare three populations: all-rule, all-LLM, mixed. Produce the report's centerpiece table (facts × populations, pass/fail with statistics) and figures (return hist vs normal overlay; ACF r vs ACF |r|). If volatility clustering is weak (common), note it honestly + hypothesize (short runs, no intraday, too-patient agents) — honest negative results score well.

### Week 11 — Ablations & robustness mini-study
Three cheap ablations (1 seed each): (a) personas removed (generic prompt) — does heterogeneity of behavior collapse?; (b) memory/diary removed — do agents become myopic?; (c) temperature 0 — does the market become degenerate/cloned? Mirrors MALLES's ablation structure (cite).

### Week 12 — M3 review + freeze
Show prof the validation table + persona results + ablations. **Freeze code** (tag `sem1-final`). Anything new goes to the Sem 2 branch.

### Weeks 13–15 — Report + presentation
Use `07_REPORT_TEMPLATES.md` Sem-1 skeleton. Wk 13: chapters 1–3 (intro, literature, design — mostly transcribable from this pack, rewritten in your words). Wk 14: chapters 4–5 (implementation, results — figures already exist in `runs/*/plots`). Wk 15: polish, references (BibTeX in `08_RESOURCES.md`), slides (template in 07), rehearse viva Q&A (list in 07).

### Week 16 — Buffer / submission.

---

## Milestone summary & minimum bars
- **M1 (wk 4)**: market engine + rule agents + metrics. *Minimum bar for the semester if everything else fails*: this + report = pass-level.
- **M2 (wk 8)**: LLM agents trading end-to-end with logs. *This + S1 = decent grade.*
- **M3 (wk 12)**: S1 + S2 + ablations. *This = good grade; the plan targets this comfortably.*

## Budget for the whole semester
Dev on mock/Ollama: $0. Live runs: S1 ≈ 3 seeds × ~$1 = $3; S2 ≈ 9 runs × ~$1.5 = $13; ablations ≈ $5; misc/debug ≈ $10. **Total ≈ $25–35 on a mini-class model; ≈ $0 fully on Ollama** (slower: budget overnight runs). Ask the prof/lab early whether API credits or a lab GPU exist — mention you've architected for both.

## Prof-meeting talking points bank (use one per meeting)
NSE's pre-open call auction as the real-world analogue of my mechanism · Gode–Sunder ZI baseline as my null hypothesis · contamination-safe design via fictional tickers (StockAgent) · mean-field observations (MALLES) · counterfactual seed-matched interventions planned for Sem 2 (Eco3S) · same attribute vocabulary as [senior]'s ODE agents so the two brains are comparable within one institution.
