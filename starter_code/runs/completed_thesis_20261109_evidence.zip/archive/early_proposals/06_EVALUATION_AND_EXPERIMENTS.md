# 06 · Evaluation & Experiments — how you prove anything
> Status note, 2026-11-02 (R019): This is the original prepared experiment menu,
> retained for reference. Its full metric battery and experiments are not all
> implemented. The semester split, volume-filter rule, fixed pass thresholds and
> seed counts below are not the current research protocol or proof of realism.
> Keep regular-time zero returns; separate event and stationary analyses. Follow
> RESEARCH_DIARY.md, WORK_PLAN.tmp.md and starter_code/AGENT_EXPERIMENTS.md for
> implemented work, proposed controls and the current research checkpoint.

Original prepared specification follows:

Everything here is computed by `sim/metrics.py` from run logs. Statistical conventions: log returns r_t = ln(P_t/P_{t−1}); drop rounds with volume 0 from return-based tests only if > 30% of rounds are zero-volume (then also report that fact — a dead market is a result); significance level 5%; ≥3 seeds for any claim in a report, ≥5 for thesis headlines; report mean ± std across seeds.

## 1. Stylized-facts battery (the validation core)

| # | Fact | Statistic | Pass criterion | Notes |
|---|------|-----------|----------------|-------|
| F1 | Fat tails | Excess kurtosis of r_t; Jarque–Bera test | kurtosis > 1 excess AND JB rejects normality | Real daily data: excess kurt ~2–30 |
| F2 | No linear predictability | Ljung–Box on r_t, lags 1–10 | fail to reject (p > .05) | Rejection = inefficient market ⇒ interesting, report it |
| F3 | Volatility clustering | ACF of \|r_t\| lags 1–20; GARCH(1,1) fit (`arch` pkg) | ≥ 5 of first 10 ACF lags significant AND α+β significant with α+β ∈ (0.7, 1) | Weakest in short runs; needs ≥ 200 rounds |
| F4 | Volume–volatility | Spearman corr(volume_t, \|r_t\|) | ρ > 0, p < .05 | |
| F5 (bonus) | Long memory | Hurst exponent of \|r_t\| | H > 0.5 | R/S method |
| F6 (bonus) | Leverage effect | corr(r_t, \|r_{t+1}\|) | negative | |

Present as facts × populations table (rule-only / LLM-only / mixed / [real-market reference values from Cont 2001]). A "pass" on F1+F3+F4 with F2 borderline is a genuinely good result for a simulation of this size — say so with citations (small ABMs routinely struggle with F3).

**Sanity metrics always reported alongside**: total conservation check (shares constant; cash changes only by dividends+interest−tax), zero-volume-round fraction, mean |mispricing| (P−F)/F, JSON-failure & repair rates, per-run cost.

## 2. Behavioral metrics (per agent / per persona group)
- **Activity**: trades per 100 rounds; mean order size / wealth.
- **Disposition ratio**: PGR/PLR = [realized gains / (realized+paper gains)] ÷ [realized losses / (realized+paper losses)] (Odean 1998 exact form; ratio > 1 ⇒ disposition effect). Computable from trades + avg cost tracking.
- **Herding/cloning index**: mean pairwise same-round action agreement across LLM agents, vs the agreement expected under independence given marginal action frequencies (report both).
- **Reasoning audit** (qualitative): sample 20 reasoning strings per experiment, tag them (fundamental / trend / news / social / emotional), report tag distribution. Cheap, and gives the thesis its human texture.
- **Performance**: final wealth by agent type/persona; Sharpe of per-agent wealth changes; Gini of final wealth.

## 3. Experiment book (S = Sem 1, E = Sem 2). Every experiment states config deltas from `baseline_v1.yaml`, hypotheses, metrics, and the one-figure summary to produce.

**S1 · Personas → behavior.** Δ: 24 LLM agents in 3 persona blocks (risk-averse+loss-averse / aggressive+overconfident / balanced); one noise-news event; 150 rounds; seeds {1,2,3}. H1 aggressive block trades more & larger; H2 loss-averse disposition ratio > 1 > others'; H3 noise news moves price then partially reverses. Figure: 3-panel bar chart of activity, order size, disposition ratio by block with seed error bars.

**S2 · Stylized facts across populations.** Δ: three configs (rules_only 12 agents / llm_only 20 / mixed 20+10+1MM), 300 rounds, seeds {1,2,3}. Figure: the facts table + return-histogram triptych.

**S3 · Ablations.** Δ from mixed: (a) `persona_source: generic`; (b) `reflect_every: 0` & no diary; (c) `temperature: 0`. 1 seed each. Metric focus: cloning index, behavior heterogeneity (std of activity across agents), market degeneracy (zero-volume fraction). Figure: cloning index bar chart.

**E1 · News & counterfactuals.** Matched pairs via P12: {real-effect news, noise news, no news} × seeds {1..5}, 200 rounds, shock at round 100. Metrics: cumulative price delta vs matched control (event-study plot ±30 rounds around shock), reversal fraction by round 130, volume spike, persona-wise trade response. H: noise news causes overreaction with reversal; real news causes persistent repricing toward new F.

**E2 · Herding/BBS.** Matched: bbs_sample 0 vs 5 vs 5+influencer; 200 rounds; seeds {1..5}. Metrics: cloning index, volatility, max |mispricing|, cascade case studies (posts → subsequent order flow). H: BBS ↑ correlation & volatility; influencer ↑ further.

**E3 · Policy.** (a) tax ∈ {0, 0.001, 0.005}; (b) circuit breaker {none, 7%/1-round}, tested on a config with an engineered crash (big negative real news at r=100); (c) rate step 0.01→0.02 at r=100 (F halves: 100→50 — do prices converge to new F, how fast, who loses?). Seeds {1..3} each, matched. Metrics: volatility, volume, mean spread proxy, |mispricing|, Gini, tax revenue. Figures: volatility-vs-tax curve; crash-path overlay with/without breaker; price-vs-new-F convergence plot.

**E4 · LLM vs parametric.** Populations: P-only (incl. senior's ODE agents if available — else fundamentalist+momentum mix as stand-in, stated clearly), L-only, mixed arena. 300 rounds, seeds {1..5}. Metrics: full facts table side-by-side; in arena, mean final wealth by brain-type (do LLMs get exploited or exploit?); compute-cost per simulated day for each. Figure: facts table + arena wealth boxplot.

**E5 · Smith bubble.** smith_bubble_mode, T=30 (≈ SSW), 12 LLM agents told full dividend distribution + horizon, seeds {1..5}. Metrics: amplitude max(P_t−F_t), normalized deviation Σ|P−F|/T, crash round; compare against human ranges (SSW 1988; Palan 2013 survey). Figure: overlay of 5 seed price paths against the declining F line — likely your thesis cover figure.

**E6 · Model families (optional).** baseline config × 3 models × 1 seed. Facts table + cost table + qualitative reasoning comparison.

## 4. Claims discipline (write this into the thesis methods section)
Every causal claim must come from seed-matched counterfactual pairs (Eco3S method). Every quantitative claim reports across-seed dispersion. Distinguish clearly: *validated* (matches real-market stylized facts), *replicated* (matches a known human-experiment result), *observed* (interesting but uncalibrated simulation behavior). Never claim external predictive validity for real markets.
