# 04 · Semester 2 Plan — experiments, comparison, thesis (≈16 weeks)
Sem 2 is an experiment factory: the platform is done; each experiment = write a config + run + analyze with existing metrics + one report section. Experiments are stacked in priority order — **cut from the bottom if behind**. Full configs/hypotheses/metrics for every experiment are in `06_EVALUATION_AND_EXPERIMENTS.md` §3 (E1–E6).

### Weeks 1–2 — Reboot + upgrades
Branch `sem2`. Implement: BBS/social module (P10), interventions framework (P11: transaction tax, circuit breaker, rate changes — config-driven), counterfactual runner (P12: same seed & personas, one flag flipped — the Eco3S method), optional LOB (P13, **only if ahead of schedule**; skip guilt-free). Re-run sem-1 baseline on the branch to confirm nothing broke.

### Weeks 3–4 — E1: News shocks & counterfactuals (the causal-method showpiece)
Matched pairs: shock vs no-shock, identical seeds. Real-effect news vs pure-noise news. Measure: impact response (price path delta between matched runs), overreaction/reversal, volume spike, who trades on news (personas). Economics hooks: event-study framing; over/underreaction literature.

### Weeks 5–6 — E2: Social influence & herding
BBS on vs off (matched). Agents post short takes post-round; next round others see a sample. Measure: decision correlation across agents, volatility, bubble frequency, cascade case studies (quote actual posts — great for the thesis). Add a "influencer" variant: one agent's posts shown to everyone. Hook: information cascades (Bikhchandani–Hirshleifer–Welch), Keynes beauty contest.

### Weeks 7–8 — E3: Policy interventions (the economics chapter)
Tobin tax at 0 / 0.1% / 0.5% per trade; circuit breaker ±7% halt vs none; risk-free rate 0.5%→2% step. All counterfactual-matched, 3 seeds each. Measure: volatility, volume, liquidity (spread proxy = |p*−prev|, unmatched volume), mispricing |P−F|, wealth distribution (Gini). Hook: securities transaction tax debates (India actually has an STT — mention it), magnet effect literature.

### Weeks 9–10 — E4: LLM vs parametric agents (the thesis-defining comparison)
Same market, three populations (all-parametric incl. senior's ODE agents if obtained / all-LLM / mixed) + arena runs (both types compete in one market). Compare: stylized-facts table side by side; wealth outcomes by type; qualitative richness (LLM reasoning vs equations). Frame honestly: parametric = cheap, tunable, transparent; LLM = rich, heterogeneous, interpretable-in-language, expensive, noisy. A balanced "when to use which" conclusion is more credible than "LLMs win."

### Week 11 — E5: Smith bubble replication
`smith_bubble_mode: true`, T=30, agents told the declining fundamental. 5 seeds. Do LLM markets bubble like humans? Measure: amplitude (max P−F), duration, crash timing; compare to human-experiment magnitudes from SSW 1988 / Palan 2013 survey. Either outcome is a headline: bubbles ⇒ "LLM agents reproduce human irrationality"; no bubbles ⇒ "LLM agents are *more* rational than humans in the classic bubble design" (consistent with some recent literature — searchable in Sem 2 for updates).

### Week 12 — E6 (optional, cut first): model-family comparison
Same config, 3 different LLMs (e.g., mini-class OpenAI vs DeepSeek vs local Llama). Which produces the most human-like market? Cheap version: 1 seed each.

### Weeks 12–13 — Robustness & variance
Re-run E1–E4 headline configs to ≥5 seeds; report mean ± std, simple significance (Mann-Whitney across seeds); sensitivity to temperature (0.3/0.7/1.0) and history length (10/20/40) on baseline. This section preempts the "is it just noise?" viva attack.

### Weeks 13–16 — Thesis + defense
Thesis = expanded Sem-1 report + one chapter per experiment (template in 07). Wk 13–14 experiment chapters (write each within days of running it — do not batch to the end). Wk 15 intro/conclusion/abstract/limitations/future work. Wk 16 polish, slides, mock viva (question bank in 07).

### Budget
E1–E3 ≈ $30; E4 ≈ $15; E5 ≈ $10; E6 ≈ $10; robustness ≈ $30. **Total ≈ $80–120 mini-class; near $0 on Ollama.** If money is tight: Ollama for exploration, paid API only for final headline seeds.

### Stretch goals (only if everything above is done — each is one line to mention in "future work" otherwise)
Fine-tune a small model on your own simulation logs for economic alignment (MALLES-style) · multi-asset with sector correlation · human-in-the-loop session (you trade against the agents) · MALLES-style multi-agent *discussion* before each decision (committee of analyst+trader per agent — compare to single-shot) · web dashboard (Streamlit) for live viewing (impressive demo, cheap to build with a coding agent).
