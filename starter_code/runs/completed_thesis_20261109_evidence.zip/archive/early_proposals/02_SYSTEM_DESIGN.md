# 02 · System Design — full technical specification
This is the contract your coding agents must follow. When an agent drifts, paste the relevant section and say "conform to this."

---

## 1. Repository layout

```
llm-exchange/
├── mtp_pack/                  # this documentation pack
├── sim/
│   ├── __init__.py
│   ├── config.py              # load/validate YAML config, dataclasses
│   ├── market.py              # call auction (later: LOB), trade settlement
│   ├── assets.py              # dividend process, fundamental value, news generator
│   ├── agents/
│   │   ├── base.py            # Agent ABC: decide(obs) -> Order; portfolio state
│   │   ├── rule_agents.py     # ZI, fundamentalist, momentum, market-maker, noise
│   │   ├── llm_agent.py       # LLM-driven agent (persona, memory, prompting)
│   │   └── personas.py        # persona generation & library
│   ├── llm/
│   │   ├── client.py          # OpenAI-compatible client, retries, caching, cost meter
│   │   └── mock.py            # deterministic mock LLM for tests/dev (no API needed)
│   ├── social.py              # (Sem 2) BBS/forum message board between agents
│   ├── engine.py              # main simulation loop, logging, checkpointing
│   └── metrics.py             # stylized-facts tests, wealth stats, plots
├── configs/                   # YAML experiment configs (one per run/experiment)
├── runs/                      # outputs: runs/<timestamp>_<name>/ (gitignored)
├── analysis/                  # notebooks / analysis scripts reading runs/
├── tests/                     # pytest tests (every module has one)
├── requirements.txt
└── README.md
```

## 2. Core data types (exact shapes — do not deviate)

```python
# sim/agents/base.py
@dataclass
class Order:
    agent_id: str
    side: str            # "buy" | "sell" | "hold"
    quantity: int        # shares, >= 0 (0 iff hold)
    limit_price: float | None  # None = market order (accept clearing price)
    round: int
    reasoning: str = ""  # LLM's stated reasoning (logged, not used by engine)

@dataclass
class Trade:
    round: int
    buyer_id: str
    seller_id: str
    quantity: int
    price: float

@dataclass
class Observation:      # what an agent sees each round (mean-field style: aggregates only)
    round: int
    price_history: list[float]     # last k closing prices (k from config, default 20)
    last_volume: int
    last_dividend: float
    risk_free_rate: float
    fundamental_hint: float | None # only if config.reveal_fundamental
    news: list[str]                # news headlines active this round
    bbs_posts: list[str]           # (Sem 2) sampled recent forum posts
    my_cash: float
    my_shares: int
    my_avg_cost: float             # average purchase price of current holding
    my_wealth: float               # cash + shares * last_price
    my_recent_trades: list[str]    # short human-readable summaries
```

Agent ABC: `decide(self, obs: Observation) -> Order`. Constructor takes `agent_id, cash, shares, rng, params: dict`. Base class also tracks portfolio and exposes `apply_trade(trade)`, `pay_dividend(d)`, `wealth(price)`.

## 3. Market mechanism (Sem 1: call auction)

Each round: (1) engine builds each agent's Observation; (2) collects one Order per agent (LLM calls run concurrently, ~8 workers); (3) validates orders — sell qty ≤ shares held; buy qty × limit ≤ cash (scale down qty if violated; market buys reserve cash at last_price × 1.1); (4) **clearing**: consider candidate prices = all distinct limit prices (market orders count as willing at any price). For each candidate p, demand D(p) = Σ buy qty with (limit ≥ p or market), supply S(p) = Σ sell qty with (limit ≤ p or market). Executable volume V(p) = min(D(p), S(p)). Clearing price p* = argmax V(p); tie-break: price closest to previous close (real exchanges use similar rules — cite NSE pre-open). If V = 0 at all candidates, no trade; price carries over (record volume 0). (5) **rationing**: on the long side, fill pro-rata by quantity (or price priority first: better-priced limits fill first, market orders have top priority — implement price priority, it's cleaner to defend); (6) settle trades, update cash/shares; (7) pay dividend d_t per share to holders; pay risk-free interest r on cash; (8) log everything.

**Price bounds**: clamp p* movement to ±20% per round (a "price band", like real exchange daily limits) — prevents degenerate LLM orders from teleporting the price. Config-controlled; an experiment later removes it.

**Sem 2 upgrade (optional)**: continuous LOB with price-time priority; agents polled in random order within a round; partial fills; resting orders persist with per-round expiry. Interface unchanged — only `market.py` internals grow.

## 4. Asset & environment model

Dividend process: d_t = max(0, d̄ + ρ(d_{t−1} − d̄) + σ_d ε_t), AR(1), defaults d̄ = 1.0, ρ = 0.6, σ_d = 0.3. Fundamental value F_t = d̄/r with default r = 0.01 per round ⇒ F = 100. Initial price P_0 = 100. Tick size 0.1. One stock, fictional name (e.g., "KGP Industries") — **never a real ticker** (contamination; cite StockAgent).

**News generator** (`assets.py`): scripted events from config — each has round, headline text, and a hidden fundamental effect (e.g., shifts d̄ by +20% for 30 rounds) or NO effect (pure noise news — lets you test overreaction). Optionally generate headline text with one LLM call from a template ("write a 1-sentence business news headline implying X").

**Smith-bubble mode** (config flag): finite horizon T; dividend each round is uniform draw from {0, 0.08, 0.28, 0.60} (per SSW 1988, scaled); asset worthless after T; F_t = E[d] × (T − t). Agents are told the full dividend distribution and horizon in their prompt.

## 5. Agent roster

**Rule-based (free, unlimited, your baselines & your bridge to the senior's work):**
- `ZeroIntelligenceAgent` — random side, random qty ≤ affordable, limit ~ U(0.9, 1.1) × last price (Gode–Sunder).
- `FundamentalistAgent` — buys when P < F(1−δ), sells when P > F(1+δ); order size ∝ mispricing × aggressiveness param. (This is the ODE-agent analogue: demand = k·(F − P).)
- `MomentumAgent` — buys after m-round positive return, sells after negative; strength ∝ trend.
- `MarketMakerAgent` — always posts buy at P(1−s) and sell at P(1+s), qty capped by inventory limits (provides liquidity so the market never dies).
- `NoiseTraderAgent` — momentum + noise, random activity probability.
Every params dict exposes the senior-style knobs: risk_aversion, aggressiveness, wealth (initial), horizon, activity_prob — so "parametric agents" and "LLM agents" are described by the *same attribute vocabulary*, differing only in how attributes map to behavior (equation vs prompt). Put that sentence in both reports.

**LLM agents (`llm_agent.py`):** persona system prompt + observation user prompt → JSON decision. Personas from `personas.py`: fields = name, age, occupation, risk_tolerance (low/med/high), aggressiveness, strategy_inclination (fundamentalist / momentum / contrarian / balanced / novice), behavioral_biases (subset of: loss_averse, overconfident, herding_prone, disposition_prone, recency_biased, none), horizon (short/long), backstory (2 sentences), plus initial cash/shares (heterogeneous, e.g., log-normal wealth). Provide a library of ~12 handcrafted personas + a generator that samples attribute combinations and renders them into text via template. **Biases are stated as dispositions in second person** ("You feel losses roughly twice as strongly as gains; you find it painful to sell at a loss") — never as instructions to be irrational ("be biased") — because Sem 1's headline experiment is whether stated dispositions produce measurable biased behavior.

**Memory**: rolling window of last N=10 round summaries (one line each: round, price, my action, my P&L) + a "diary" string; every `reflect_every`=10 rounds, one temperature-0 LLM call compresses window+diary → new diary (≤120 words: current view of market, what's working, plan). Diary included in every prompt.

## 6. Prompt templates (v1 — iterate from here, keep every version in git)

System prompt:
```
You are {name}, a {age}-year-old {occupation} trading stocks with your personal savings.
Profile: risk tolerance {risk_tolerance}; style {strategy_inclination}; horizon {horizon}.
{backstory} {bias_clauses}
You trade shares of {ticker} on a simulated exchange. Each round is one trading day.
The exchange batches all orders and clears at one price. There is no short selling and
no borrowing: you can only sell shares you own and spend cash you have.
Respond ONLY with a JSON object, no other text:
{"action": "buy"|"sell"|"hold", "quantity": <int>=0>, "limit_price": <number or null>,
 "reasoning": "<one or two sentences in character>"}
limit_price null means you accept the market clearing price.
```
User prompt (per round):
```
Round {round}/{total}. Recent closing prices (old→new): {price_history}
Yesterday: volume {last_volume}, dividend paid {last_dividend} per share.
Risk-free rate: {r} per round (your cash earns this).
{news_block}{bbs_block}{fundamental_block}
Your account: cash {cash}, shares {shares} (avg cost {avg_cost}), total wealth {wealth}.
Your recent trades: {recent_trades}
Your trading diary: {diary}
Decide your order for today. Remember: JSON only.
```
Validator: parse JSON (strip code fences; regex-extract first {...} if needed); check enum/types/affordability; on failure re-ask once with the error message appended; then HOLD. Log raw response + parse status always.

## 7. LLM client (`llm/client.py`)

One class, OpenAI-compatible chat-completions: `chat(messages, temperature, max_tokens, json_mode=True) -> str`. Base URL + model + key from env/config ⇒ works with OpenAI, DeepSeek, Groq, OpenRouter, Ollama (`http://localhost:11434/v1`). Retries with exponential backoff (3×) on 429/5xx/timeouts. Token+cost meter (running totals, printed each 10 rounds, saved to run summary). Optional on-disk cache keyed by hash(messages+model+temp) — mainly for re-running analysis without re-paying. `mock.py`: same interface; deterministic policy (hash of prompt + simple heuristics on the price series embedded in prompt) returning valid JSON — used by all tests and for free full-pipeline dev runs (`llm.provider: mock`).

## 8. Config (YAML) — one file fully specifies a run

```yaml
name: baseline_v1
seed: 42
rounds: 200
market: {mechanism: call_auction, tick: 0.1, price_band: 0.2, transaction_tax: 0.0, circuit_breaker: null}
asset: {ticker: KGP, initial_price: 100, dividend: {mean: 1.0, rho: 0.6, sigma: 0.3}, risk_free: 0.01, smith_bubble_mode: false, horizon: null}
reveal_fundamental: false
news: [{round: 80, headline: "KGP wins major government contract", effect: {dbar_mult: 1.2, duration: 30}}]
observation: {price_history_len: 20, bbs_sample: 0}
agents:
  - {type: market_maker, count: 1, params: {spread: 0.02, inventory_limit: 200}}
  - {type: zero_intelligence, count: 5, cash: 10000, shares: 100}
  - {type: fundamentalist, count: 3, cash: 10000, shares: 100, params: {delta: 0.05, aggressiveness: 0.5}}
  - {type: momentum, count: 3, cash: 10000, shares: 100, params: {window: 5}}
  - {type: llm, count: 20, cash_dist: lognormal(9.2, 0.5), shares: 100,
     persona_source: library, llm: {provider: openai_compatible, model: gpt-4o-mini,
     temperature: 0.7, max_tokens: 300}}
logging: {level: info, save_prompts: true}
```

## 9. Logging & run outputs (the evaluation reads only these)

`runs/<ts>_<name>/` contains: `config.yaml` (copy), `prices.csv` (round, price, volume, dividend, fundamental), `orders.csv` (all Order fields + validity/repair flags), `trades.csv`, `agents_state.csv` (per round per agent: cash, shares, wealth), `llm_calls.jsonl` (agent_id, round, prompt, raw_response, parsed, tokens, latency, cost), `events.csv` (news, interventions), `summary.json` (totals: cost, tokens, runtime, failure rates), `plots/` (auto: price+fundamental+volume, wealth trajectories, return histogram vs normal, ACF of r and |r|). Engine writes incrementally (crash-safe) and supports `--resume`.

## 10. Design rationale (defenses for viva/prof)

*Why build own vs fork TwinMarket/StockSim?* Those need external DBs/message brokers, encode fixed research questions, and are hard to certify line-by-line in a viva; my engine is ~1.5k lines, fully understood, and imports their *ideas* (cited). *Why call auction?* Simultaneous LLM decisions map naturally to batch clearing; real exchanges use it (NSE pre-open); removes order-arrival-timing artifacts that would be artifacts of my thread scheduler, not of behavior. *Why one asset?* Every research question here (stylized facts, biases, herding, policy) is answerable with one asset; multi-asset multiplies cost, not insight. *Why mean-field observations (aggregates, not others' individual actions)?* Realism (traders see prices/volume, not each other's books) + MALLES shows aggregate context stabilizes LLM decisions. *Why JSON-only outputs?* Reliability; reasoning is still captured in-band for qualitative analysis. *Why fictional ticker?* Training-data contamination (StockAgent). *Why price bands?* Real exchanges have them; and they bound the damage of degenerate outputs — with an ablation run showing results hold without them.

## 11. Non-goals (write in report as scope)
No real-money trading, no real market data dependency (optional news flavoring only), no order-book-level HFT realism in Sem 1, no short selling/margin (extension), no >100 LLM agents (cost), no claims about predicting real markets — this is a *scientific instrument for hypotheses about behavior*, not a forecasting tool.
