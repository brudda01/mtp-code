# Historical proposals, not the current thesis specification

The original root documents `00_START_HERE.md` through
`09_FAQ_SIMPLE_ANSWERS.md` were moved here on 2026-11-08 at the author's request.
Their contents are unchanged. [The move manifest](move_manifest.json) records
each original location, destination and SHA256, verified after the move.

These documents contain early semester plans, feature proposals and anticipated
claims that may conflict with the implemented work. They are retained as
history, not instructions to run the proposed experiments or claims that those
experiments succeeded. References to code paths inside them were written
relative to the original repository root.

Use the [current repository guide](../../README.md),
[thesis argument](../../thesis/THESIS_ARGUMENT.md),
[draft](../../thesis/THESIS_DRAFT.md) and
[research diary](../../RESEARCH_DIARY.md) for current work and evidence.
