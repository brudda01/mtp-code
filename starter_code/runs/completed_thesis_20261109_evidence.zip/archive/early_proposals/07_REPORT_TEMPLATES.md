# 07 · Report Templates, Slides & Viva Prep

**Current writing scope,2026-11-05:** Use
[thesis/THESIS_DRAFT.md](thesis/THESIS_DRAFT.md) and
[thesis/README.md](thesis/README.md). The templates below are the original
planning material;their social/policy/bubble chapters and validation claims
are not implemented results or current obligations. Follow the verified
execution/background/component findings and actual department requirements.

## A. Semester-1 report skeleton (~30–40 pages; adjust to your dept format & page rules — check the MTP guidelines/previous seniors' reports for the official title page, certificate, and declaration pages)

**Title suggestion**: "An LLM-Agent-Based Simulation of a Stock Exchange: Design, Implementation and Validation Against Stylized Facts."

1. **Introduction** (3–4 pp): motivation (limits of equation-based ABM; generative social science; why markets are the ideal testbed) — largely a rewrite of Primer Parts A + F lineage sentence; problem statement; objectives (build, validate, first behavioral experiment); contributions list; report organization.
2. **Background & Literature** (6–8 pp): ABM history (Santa Fe ASM, Gode–Sunder, Brock–Hommes); market microstructure (call auctions, why chosen, NSE pre-open); stylized facts (Cont 2001); behavioral finance (prospect theory, disposition, herding); LLM agents (generative agents/Smallville → AgentSociety; economic: EconAgent, MALLES, Eco3S; financial: StockAgent, TwinMarket, Lopez-Lira). End with a gap statement: "prior LLM-market works fix one research question; this MTP builds a controlled, pluggable-brain instrument enabling direct LLM-vs-parametric comparison within one institution."
3. **System Design** (6–8 pp): architecture diagram; market mechanism with the clearing algorithm (pseudo-code + the demand/supply crossing figure); asset/dividend/fundamental model (equations); agent abstraction; persona schema with 2 full example personas; prompt templates verbatim (appendix for the rest); design-rationale table (from `02` §10). This chapter is mostly transcribing `02_SYSTEM_DESIGN.md` in your own words — do rewrite, don't paste.
4. **Implementation** (3–4 pp): stack, repo stats, testing strategy (unit + property + conservation tests), reproducibility (configs/seeds/logs), concurrency & cost engineering, failure handling (JSON repair pipeline with its measured failure rates — a table).
5. **Results** (8–10 pp): rule-agent sanity dynamics; S1 personas→behavior (the 3-panel figure + interpretation + 2–3 quoted reasoning strings); S2 stylized-facts table & figures; S3 ablations. Be honest about misses.
6. **Discussion & Limitations** (2 pp): cloning risk, numerical sensitivity (cite MALLES), prompt sensitivity, contamination handling, single asset, call-auction abstraction.
7. **Semester-2 Plan** (1–2 pp): E1–E6 one paragraph each. Committees love a concrete plan.
8. References + Appendices (all prompts; persona library; config listings; extra plots).

## B. Thesis (Sem 2) skeleton (~60–80 pp)
Ch. 1–4 = expanded Sem-1 ch. 1–4 (update literature with anything new — do a fresh search in month 1 of Sem 2). Ch. 5 Validation (Sem-1 results, re-run on final code). Ch. 6 News & Counterfactuals (E1). Ch. 7 Social Influence (E2). Ch. 8 Policy Experiments (E3). Ch. 9 LLM vs Parametric Agents (E4 — position as the synthesis chapter answering the prof's original framing). Ch. 10 Bubble Replication (E5, + E6 if done). Ch. 11 Conclusion, Limitations, Future Work. Each experiment chapter uses the same internal structure: Motivation & hypothesis → Setup (config delta table) → Results (figures) → Interpretation (economics!) → Threats to validity. Writing one chapter should take ≤ 3 days because the figures/metrics are auto-generated.

## C. Presentation outline (12–15 slides, both semesters)
1 Title · 2 Motivation (one picture: equation-agent vs LLM-agent) · 3 The idea in one diagram (agents → orders → auction → price → back) · 4 Related work (one lineage slide: AgentSociety→MALLES/Eco3S→this) · 5 Market mechanism (supply/demand cross figure) · 6 Agent anatomy (prompt → JSON) · 7 A persona + a real quoted reasoning ("show the demo moment") · 8–10 Results figures (facts table; persona bar chart; best price path) · 11 Ablations/robustness · 12 Limitations (own them proactively) · 13 Plan/conclusions · 14 Thanks/questions. If a live demo is feasible: 30-round mock-LLM run with the price chart updating — rehearse it twice, have a screen-recording fallback.

## D. Viva question bank (rehearse out loud)

*Conceptual*: Why LLM agents over differential equations — what specifically can they capture? (language-mediated reasoning, context/news interpretation, heterogeneity via persona, measurable irrationality; but costlier, noisier — give the balanced answer.) · What are stylized facts; list four; why validate against them? · Explain your clearing algorithm on the whiteboard. (Practice this. Actually practice it.) · Why call auction and not continuous trading? · What is the fundamental value in your model and why can you measure mispricing when real-world researchers can't? · Gode–Sunder: what do zero-intelligence traders show, and what did they show in *your* market? · What's the disposition effect and exactly how do you compute it from your logs? · How do you know agents aren't just remembering real market history? (fictional ticker, simulation-internal news, no real dates — StockAgent's contamination argument.) · How do you make causal claims from simulation? (seed-matched counterfactuals, Eco3S.)

*Technical*: What happens when the LLM returns garbage? (repair pipeline + measured rates.) · How is a run reproducible if LLMs are stochastic? (config+seed reproduce the market exactly under mock; under live LLMs, temperature>0 ⇒ we treat each run as one draw and do multi-seed statistics — and we log every raw response so any run is auditable post-hoc.) · Why temperature 0.7? (ablation S3c: 0 collapses heterogeneity.) · Cost per run and how you kept it low? · What breaks if 200 agents? (API throughput → batching; context growth is O(1) per agent by design.)

*Economics*: Is your market efficient? (report the F2 result; discuss which population mixes break efficiency.) · What does theory predict a Tobin tax does, and what did yours do? · Explain the Smith bubble design and why bubbles there are 'irrational'. · Relate your fundamentalist/momentum mix to Brock–Hommes. · India has an STT — what would your E3 say about it? (careful: *observed in simulation*, not policy advice — say exactly that.)

*Hostile-but-fair*: Isn't this just prompting GPT to role-play — where's the science? (validation against quantitative stylized facts + replication of a classic human experiment + controlled counterfactuals = it's an instrument, and instruments are judged by their measurements.) · Aren't all your agents the same model — so it's one mind talking to itself? (cloning index measured; personas/temperature/mixed-populations mitigation; acknowledged as a core limitation and an E6 research question.) · Would any of this transfer to real markets? (no claim made; internal-validity instrument — and that restraint is deliberate.)

## E. Progress-log habit
Keep `LOG.md` in the repo: every session, 3–5 lines (date, what ran, cost, one observation, next step). Both reports' "work summary," your prof updates, and half your viva confidence come from this file.
