# 01 · Concepts Primer — everything you need to understand
Read this to sound competent in prof meetings and the viva. It's written to be read start-to-finish in ~2 hours, then used as a reference.

---

## Part A — Agent-Based Modeling (ABM)

**Agent-based modeling** simulates a system bottom-up: you define individual agents with simple local behaviors, let them interact, and observe what **emerges** at the macro level. Nobody programs "the market crashes"; crashes emerge from many agents individually deciding to sell. The core promise (Epstein's "generative social science" — quoted in AgentSociety via Feynman's "What I cannot create, I do not understand") is: if you can *grow* a phenomenon from micro rules, you have a candidate explanation of it.

Classic ABM agents are driven by **rules** ("if price rose 3 days, buy"), **equations** (your senior's approach — attributes like risk appetite are parameters in differential/difference equations governing demand), or **learned models**. The limitation, stressed in all three papers your prof shared: real humans reason in natural language, hold context, and are inconsistently rational. Equations can't easily capture "I read a scary news headline and panic-sold even though fundamentals were fine."

**LLM agents** replace the equation with a language model: the agent's state and the market situation are rendered as text, the LLM produces a decision (plus its reasoning), and the decision is parsed back into a machine action. Attributes stop being coefficients and become *persona text*: "You are Rakesh, 45, risk-averse, lost money in 2008, you check the market twice a day..." This is the "generative agent" paradigm (Park et al.'s Smallville paper started it; AgentSociety scales it to 10k+ agents).

**Why finance is the ideal testbed** (TwinMarket's argument): markets produce high-resolution quantitative data, have well-documented collective phenomena (bubbles, herding, crashes), and there's a 30-year literature of *artificial stock markets* to compare against — starting with the **Santa Fe Institute Artificial Stock Market** (Palmer/Arthur, 1994), the grandfather of your project.

Two classical results you should be able to cite (both are cheap to replicate and both are in your experiment plan):
- **Gode & Sunder (1993), "zero-intelligence traders"**: agents submitting *random* orders (subject only to budget constraints) in a double auction still produce near-efficient prices. Lesson: some market properties come from the *institution* (the auction mechanism), not trader intelligence. This is your null baseline — LLM agents must be compared against ZI agents to show intelligence matters.
- **Smith, Suchanek & Williams (1988)**: human subjects trading an asset with *known, declining fundamental value* reliably produce bubbles and crashes. A famous experimental-economics result. Semester 2 replicates it with LLM subjects.

## Part B — Market microstructure (how exchanges actually work)

**Order types.** A **market order** says "buy/sell N shares now at whatever price." A **limit order** says "buy N at ≤ ₹X" (bid) or "sell N at ≥ ₹Y" (ask). Limit orders that don't execute immediately rest in the **limit order book (LOB)**.

**The book.** Bids sorted descending, asks ascending. Best bid = highest buy price; best ask = lowest sell price. **Spread** = ask − bid (a liquidity measure). **Depth** = volume resting near the top of the book.

**Continuous double auction (CDA)**: orders arrive one by one; any time a new bid ≥ best ask (or new ask ≤ best bid) a trade executes at the resting order's price. Price-time priority: better price first, earlier order first at the same price. This is how NSE/NYSE trade intraday.

**Call auction (what you build first)**: collect all orders over a period, then compute one **clearing price** — the price p* that maximizes executable volume (demand at p* meets supply at p*). All matched trades execute at p*. Real exchanges use this at open and close (NSE's 9:00–9:08 pre-open session is a call auction — cite this in your report as justification). It's simpler than a CDA, order-arrival-sequence-independent, and perfect for round-based LLM simulation where all agents decide "simultaneously."

**Price formation intuition**: plot cumulative demand (sum of buy quantities with limit ≥ p, decreasing in p) and cumulative supply (increasing in p); the clearing price is where they cross. Excess demand ⇒ price rises next round. Your senior's ODE model probably encodes literally this: dP/dt ∝ excess demand. Your market discovers it through actual order matching — a talking point for the comparison chapter.

**Other terms to know**: *liquidity* (ability to trade size without moving price), *slippage* (execution price worse than expected), *market maker* (agent quoting both bid and ask, earning the spread), *short selling* (you will disallow it initially — agents can only sell what they hold — one sentence of justification: keeps wealth dynamics simple and bounded), *circuit breaker* (exchange halts/limits trading after an X% move; an experiment in Sem 2), *tick size* (minimum price increment, e.g., ₹0.05).

## Part C — Stylized facts of financial markets (your validation targets)

Real asset returns, across markets and eras, robustly show these statistical signatures (Cont, 2001, "Empirical properties of asset returns" — your key citation). Your simulation is judged "realistic" to the degree it reproduces them. Definitions use log-returns r_t = ln(P_t / P_{t−1}).

1. **Fat tails / excess kurtosis**: return distribution has kurtosis > 3 (real daily returns often 5–30). Extreme moves happen far more often than a normal distribution predicts.
2. **No linear autocorrelation of returns**: corr(r_t, r_{t−k}) ≈ 0 for k ≥ 1. Markets are hard to predict linearly (weak-form efficiency).
3. **Volatility clustering**: |r_t| and r_t² ARE strongly autocorrelated — calm periods cluster, turbulent periods cluster. Formally: significant, slowly decaying ACF of |r_t|; a GARCH(1,1) fit has significant ARCH/GARCH terms.
4. **Volume–volatility correlation**: trading volume correlates positively with |returns|.
5. (Bonus) **Aggregational Gaussianity**: returns look more normal at longer horizons. (Bonus) **Leverage effect**: negative returns predict higher future volatility.

`06_EVALUATION_AND_EXPERIMENTS.md` turns each into an automated statistical test. Memorize the list of four core facts — it is a guaranteed viva question ("how do you know your simulation is realistic?").

## Part D — Economics & behavioral finance you'll actually use

**Fundamental value.** Give the stock a dividend: each round it pays d_t per share (e.g., stochastic around a mean). With risk-free rate r, the fundamental value is the discounted expected dividend stream: F = E[d]/r (Gordon growth with g=0). Your simulation *defines* the truth, so you can measure **mispricing** = (P_t − F_t)/F_t — impossible with real data, and the cleanest thing about simulation-based research. In the Smith-bubble experiment, the asset pays dividends for T rounds then dies worthless, so F_t declines linearly — agents *know* this, and bubbles still form (for humans; you'll test LLMs).

**Efficient Market Hypothesis (EMH)** — weak form: past prices can't predict future returns. Test: return autocorrelation ≈ 0; a simple momentum strategy shouldn't profit. Your simulation lets you ask *when* efficiency breaks (e.g., when the population is dominated by momentum-chasers).

**Rational expectations vs bounded rationality.** Neoclassical agents optimize with full information; real people (and LLMs) satisfice with limited attention. Keynes's **beauty contest**: prices depend on what people think other people think — recursion that produces self-fulfilling bubbles. LLM agents can literally be asked "what do you think others will do?" — pure Keynes.

**Behavioral biases** (encode as persona traits, then *measure* whether the LLM enacts them — this measurement gap is a genuinely good research question and is Sem 1's headline experiment):
- **Loss aversion** (Kahneman–Tversky prospect theory): losses hurt ~2× more than equal gains please.
- **Disposition effect** (Shefrin–Statman): selling winners too early, holding losers too long. Measurable directly from your trade logs: P(sell | position in gain) vs P(sell | position in loss). TwinMarket explicitly models this.
- **Overconfidence** → overtrading (Barber–Odean: frequent traders underperform).
- **Herding**: imitating others rather than own information; amplified by the social/BBS layer.
- **Anchoring, recency bias**: overweighting recent prices/news.

**Heterogeneous agent models** (Brock–Hommes 1998): markets with **fundamentalists** (trade toward F) vs **chartists/momentum traders** (extrapolate trends) generate rich dynamics — bubbles when chartists dominate, mean reversion when fundamentalists dominate. Your rule-based agent roster is exactly this taxonomy, and "population mix" is one of your experiment dials.

**Policy instruments for Sem 2 experiments**: **Tobin tax** (small % tax per trade — does it reduce volatility or drain liquidity? the literature is genuinely divided, so any result you get is defensible), **circuit breakers** (halt after ±X% — dampen panic or delay it? "magnet effect"), **interest rate changes** (raise r ⇒ fundamental value falls ⇒ do agents reprice?).

## Part E — LLM-agent engineering essentials

**Anatomy of one agent decision (one "step")**:
1. **Observation** assembled by the engine: price history (last k rounds), last dividend, agent's cash/shares/P&L, any news, recent BBS posts.
2. **Prompt** = system prompt (persona: name, age, occupation, risk attitude, strategy inclination, biases) + market observation + memory summary + instruction to reply in JSON.
3. **LLM call** → raw text.
4. **Parse & validate** JSON: `{"action": "buy|sell|hold", "quantity": int, "limit_price": float, "reasoning": "..."}`. Reject/repair impossible orders (can't sell more than held, can't spend more than cash — or scale down). Invalid twice ⇒ HOLD.
5. **Memory update**: append round summary; every ~10 rounds, an LLM call compresses memory into a short "trading diary" (reflection — from the generative-agents literature; MALLES calls this profile summarization).

**Known pathologies (write these in your report's limitations section; each is documented in the literature)**:
- **JSON breakage** — mitigated by validators + retries + few-shot examples in the prompt.
- **Herd-of-clones**: same model + similar prompts ⇒ correlated decisions ⇒ artificial herding. Mitigations: temperature > 0, strongly differentiated personas, mixing model families, mixing in rule-based agents. Also *measure* it: decision-correlation across agents.
- **Positional/recency bias in prompts**; number handling can be weak (MALLES's core complaint: poor "numerical sensitivity", e.g., price elasticity — cite it).
- **Prompt sensitivity**: small wording changes shift behavior; do seed/repeat runs (variance analysis is required in Sem 2).
- **Data contamination**: if you simulate "AAPL in 2020", the model may *remember* actual 2020. Solution (StockAgent's headline design point — cite it): fictional tickers, fictional company fundamentals, simulation-internal news only.
- **Cost/latency**: calls are the bottleneck ⇒ batch with async/threading, cache, use mini models, cap history length.

**Temperature**: 0 = deterministic-ish, higher = more varied. Use ~0.7 for trader agents (humans are noisy), 0 for utility calls (memory summarization, parsing repair).

## Part F — The three papers your prof shared, in plain language

**1. AgentSociety (Piao et al., Tsinghua — arXiv 2502.08691) — the reference paper (PDF he gave you).**
A large-scale social simulator: 10k+ LLM-driven generative agents living in a realistic urban environment (mobility, employment, consumption, social networks), 5M interactions, built on a distributed simulation engine (Ray, MQTT). Agents have profiles, memory, needs (Maslow-inspired), and plan via LLM reasoning. They validate by comparing simulation outcomes to real-world experimental/survey results on five case studies: opinion **polarization**, spread of **inflammatory messages**, **universal basic income** effects, **hurricane** external shock, and urban sustainability. *Why he gave it to you*: it's the paradigm statement — LLM agents as scientifically useful simulacra of society, validated against real data. Your project is this philosophy applied to one specific institution (a stock exchange). Borrow from it: the profile→memory→reasoning agent architecture, and the validation ethos (always compare to known real-world regularities — for you, stylized facts).

**2. MALLES (Wu, Liu, Deng — arXiv 2603.17694) — Multi-Agent LLM Economic Sandbox.**
Simulates *consumer* decisions (retail purchase choice & quantity; wholesale procurement) with LLMs. Key ideas: (a) **post-training/fine-tuning on real transaction records** so the LLM internalizes price sensitivity ("economic alignment") — they show base LLMs have poor numerical/price sensitivity; (b) **multi-agent discussion** (dealer/service/manufacturer roles debating over rounds) to distribute cognitive load and improve decisions; (c) **mean-field mechanism** — feed agents *aggregate population statistics* (moving-window averages of market response) as context, which stabilizes noisy individual decisions; (d) consistency regularization (same input under small perturbation ⇒ similar output). *Borrow*: the mean-field idea maps directly to your design (agents see aggregate market stats, not every other agent's action — that's exactly how real traders see markets); the numerical-sensitivity critique goes in your limitations; fine-tuning is your Sem 2 stretch goal; their ablation-study structure (with/without each mechanism) is a template for your experiments chapter.

**3. Eco3S (Wei et al. — arXiv 2607.26588) — socio-economic system simulation via ABM.**
Framework contributions: (a) **co-evolving environment** — agents change the environment and the environment changes agents in a feedback loop (in your market: agents' orders set prices; prices drive agents' next decisions — you get this for free, say so); (b) **structural-causal-model-style counterfactuals** — run the simulation, then re-run with one intervention changed, holding everything else (seeds, personas) fixed, to make causal claims ("the crash was *caused by* the news shock, because the counterfactual run without it shows no crash"); (c) **simulation–analysis–refinement loop** — iteratively refine experiment designs based on prior results. *Borrow*: the counterfactual methodology is your Sem 2 experimental method — always run matched intervention/control pairs with identical seeds. This single methodological habit will make your thesis look rigorous.

**How to present the lineage in one sentence to your prof**: "AgentSociety establishes LLM-generative-agent social simulation as a paradigm; MALLES and Eco3S adapt it to economic decision-making and causal experimentation; my MTP instantiates it for a financial exchange, where a mature stylized-facts literature gives unusually sharp validation criteria, and where I compare LLM agents against the parametric/ODE agent tradition [senior's project] within the same market institution."

## Part G — Vocabulary cheat sheet (30-second viva insurance)

*Log return*: ln(P_t/P_{t−1}). *Volatility*: std-dev of returns. *Kurtosis*: tail-heaviness (normal = 3). *ACF*: autocorrelation function. *GARCH(1,1)*: volatility model where today's variance depends on yesterday's shock² and yesterday's variance — the standard volatility-clustering model. *Hurst exponent*: long-memory measure (0.5 = random walk). *Sharpe ratio*: mean excess return / volatility. *P&L*: profit and loss. *Mark-to-market wealth*: cash + shares × current price. *Ablation*: removing one component to measure its contribution. *Seed*: RNG initializer for reproducibility. *Token*: LLM text unit (~0.75 words). *Persona*: the character description in an agent's system prompt. *BDI*: Belief-Desire-Intention agent architecture (TwinMarket uses it — beliefs about the market, desires/goals, intentions/plans).
