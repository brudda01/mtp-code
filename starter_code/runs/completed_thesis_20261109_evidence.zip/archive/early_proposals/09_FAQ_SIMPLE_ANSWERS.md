# 09 · FAQ — Simple Answers (from our chats)

Plain-language answers to questions you asked. Read alongside 01_CONCEPTS_PRIMER.md
(which has the rigorous versions). Useful before prof meetings and the viva.

---

## The whole plan in one paragraph

Your senior built a fake stock market where traders are math equations
(risk = 0.7, boldness = 0.4 → formula decides buy/sell). You build the same
kind of market, but traders are LLM agents: each gets a personality in words
("You are Meera, 45, school teacher, cautious, hates losing money"), and each
round you ask it "here's the price and news — what do you do?" It answers
"buy 5 at 102", the market matches everyone's orders, a new price forms.
Semester 1: build it, then prove (a) different personalities behave
differently, and (b) the price chart has the same statistical fingerprints
as real markets ("stylized facts"). Semester 2: run experiments — news
shocks with same-seed reruns for causality, a chat forum for herding,
policies (trade tax, circuit breaker, rate hike), the Smith bubble
replication, and the centerpiece: LLM agents vs the senior's parametric
agents in the identical market. That comparison is the thesis.

---

## Q1. NSE pre-open auction vs full live order book — what and why

**Call auction (what we build):** Like NSE 9:00–9:07 every morning. Everyone
submits orders, nothing trades yet. Then the exchange finds the ONE price at
which the maximum shares change hands; all matched orders trade at that one
price simultaneously. Our market does this every round: collect orders →
one clearing price → trade → next round. Like a mandi auctioneer collecting
all bids, then announcing one price.

**Continuous order book (real intraday trading, NSE 9:15–3:30):** Orders
arrive one by one; a trade fires the instant a buy crosses a sell; prices
change trade by trade; a live "book" lists all waiting bids and asks.

**Why call auction for us:** In continuous trading, millisecond timing
matters — pointless for LLM agents that take seconds to think, and much
harder to build and test. The call auction removes timing: all agents decide
simultaneously, one price per round. It's the standard choice in academic
market simulations, and citing NSE's pre-open makes it defensible. The
continuous book is an optional Semester 2 add-on (prompt P13).

---

## Q2. Why one stock? Why a dividend every round?

**One stock:** every extra stock multiplies complexity (which stock? how to
split money? cross-price effects?) but adds nothing to what we can prove.
Every question we care about — do personalities matter, is the market
realistic, does news cause crashes, does a tax calm things — is answerable
with one stock. Smith's classic experiments and most ABM papers use one
asset. It's the standard, not a weakness.

**Dividend:** without it, the stock has NO correct price — 10, 100, 1000 are
all equally "right", so we could never call anything a bubble or say the
market is sensible. With a small dividend each round, finance's basic
formula gives a true value: value = average dividend ÷ interest rate
(₹1 ÷ 0.01 = 100). Now everything is measured against 100.

**"But real dividends take months":** our rounds aren't real clock time; one
round is one time step — interpret it as a day, quarter, whatever. Paying a
small dividend per round is the standard simplification (Smith 1988 did
exactly this). Line for the prof: "one round represents one dividend period;
its real-world length doesn't affect any result."

---

## Q3. What are the rule-based agents?

Dumb fixed-formula programs, each a caricature of a real trader type:

- **Random / zero-intelligence (ZI):** coin-flip buy or sell at a random
  price near the current one. Famous result (Gode & Sunder 1993): markets of
  ONLY random traders still produce sensible prices — the auction mechanism
  itself does much of the work. They also keep the market liquid.
- **Value trader (fundamentalist):** compares price to true value 100.
  Price 90 → buy; 115 → sell; bigger gap → bigger trade. The rubber band
  pulling price back to 100.
- **Trend follower (momentum):** ignores value, looks only at the recent
  chart. "Up 3 rounds → buy." These inflate bubbles and deepen crashes.
- **Market maker:** always quotes a buy slightly below and a sell slightly
  above market, earning the gap — like a currency-exchange counter. Ensures
  someone is always on the other side.

**Why have them at all:** (1) build and test the whole market for ₹0 before
any LLM call; (2) liquidity — LLM agents always have a counterparty;
(3) the thesis reason — they ARE the senior's style of parametric agents,
which makes the LLM-vs-parametric comparison possible in one market.

---

## Q4. Fundamental questions even the basic version answers

1. **Do words change behavior?** Tell one LLM "you are cautious", another
   "you are aggressive" — nothing else different. Do they measurably trade
   differently? (Can language-defined personality replace equation-defined
   personality?)
2. **Does an AI market look like a real market?** Fat-tailed crashes,
   volatility clustering, volume–volatility link — nobody programs these in.
   If they emerge on their own, that's a real result.
3. **Do prices find the right level?** Stock worth 100 — does the market
   settle near 100? Price discovery with zero humans.
4. **Do AI agents inherit human biases?** Holding losers too long
   (disposition effect), panic-selling, herding — LLMs learned from human
   text; do they trade like flawed humans? If yes, that's exactly why
   they're better human-simulators than clean equations.
5. **What does news cause?** Announce "profits fell 30%", rerun the identical
   world (same seed) without the news, and measure the crash the news
   caused. Impossible in reality; trivial here.
6. **Does the trader mix change the market's character?** More trend
   followers → more bubbles? More value traders → more stability? One config
   line, rerun.

If the prof asks "what's the point of the basic version": answers 1 and 2.

---

## Q5. Inflation and other macro factors — include them?

**No for Semester 1, a little in Semester 2, never the full economy.** This
is a single-market ("partial equilibrium") study — the standard framing in
market microstructure. Whole-economy modeling (jobs, wages, GDP) is what
AgentSociety/Eco3S do and would be a second thesis.

**Economics already inside the model:** the interest rate r (in value = d̄/r
— it's the return on holding cash), a time-varying dividend (the "real
economy" moving the company's fortunes), news shocks, taxes (Tobin tax in
Sem 2), and wealth inequality dynamics across agents.

**The cheap high-value addition — monetary policy:** because r is already in
the value formula, a mid-run announcement "rate raised 1% → 1.5%" instantly
moves true value 100 → 67. Watch who understands it, how fast price adjusts,
who gets crushed. That's an RBI-style rate-shock experiment for ~10 lines of
code — already planned as the E3 "rate step".

**Inflation specifically:** addable (erode cash value ~0.5%/round, mention in
the prompt) but adds little beyond the rate experiment and muddies the
true-value bookkeeping. Skip it; if asked, say: "The interest rate plays that
role — the return on cash. I can add explicit inflation as a Semester 2
extension if you'd like."

**The principle (say this line):** "I keep the economy outside the market
simple on purpose — one rate, one dividend stream, occasional news. The
richness goes into the agents. Economic factors enter as one-at-a-time
Semester 2 experiments, so each has clean cause and effect. A simulation
with everything in it explains nothing."

---

## Prof-meeting one-liner (backup copy)

"Read the three papers, locked the design — NSE-style call auction, one
dividend-paying stock, a mix of LLM and rule-based agents — built a working
prototype that already trades sensibly near fundamental value. Proposed
thesis core: comparing LLM agents against [senior]'s parametric agents in
the same market. Two questions for you."

(Full talking points: PROF_MEETING_NOTES.md.)
