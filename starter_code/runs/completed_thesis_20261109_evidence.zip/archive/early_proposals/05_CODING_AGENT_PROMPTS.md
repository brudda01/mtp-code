# 05 · Coding-Agent Prompts — paste in order, verify each test
Rules: (1) One prompt per session where possible. (2) Always start the session by pasting `02_SYSTEM_DESIGN.md` (or attach the file) with: "This is the project spec. Conform to it exactly. Ask nothing; make reasonable choices consistent with the spec." (3) After the agent finishes, run the **Verify** command yourself. Green ⇒ `git commit -m "P<n>"`. Red ⇒ paste the error back verbatim. (4) If the agent rewrites working code unasked, say: "Revert unrelated changes; modify only the files named in the task."

The starter code already provides a minimal working skeleton (engine, call auction, base agent, ZI + fundamentalist + market maker, mock LLM, basic logging). P1–P5 harden and complete it; P6+ add the LLM layer.

---

**P1 — Config system.**
"Implement `sim/config.py` per spec §8: load a YAML file into typed dataclasses (`RunConfig`, `MarketConfig`, `AssetConfig`, `AgentGroupConfig`, `LLMConfig`), with validation (positive rounds, valid mechanism enum, agent counts ≥ 0, temperature ∈ [0,2]) raising `ConfigError` with a helpful message. Support `cash_dist: lognormal(mu, sigma)` strings parsed into sampler callables using the run's seeded RNG. Update `sim/engine.py` to consume it. Create `configs/dev_mock.yaml` (spec §8 example but `provider: mock`, 10 LLM-mock agents, 50 rounds) and `configs/baseline_v1.yaml`. Write `tests/test_config.py` covering happy path + 3 invalid configs."
**Verify:** `pytest tests/test_config.py -q && python -m sim.engine --config configs/dev_mock.yaml`

**P2 — Call auction, complete.**
"Rewrite `sim/market.py` clearing to full spec §3: candidate prices from all limit prices; market orders willing at any price; p* maximizes executable volume with tie-break nearest previous close; price priority allocation (market orders first, then best-priced limits; pro-rata by remaining quantity at the marginal price level); price band clamp ±band around previous close applied to p* (orders outside band still counted at clamped price boundary); tick rounding; return `(clearing_price, trades, unmatched_volume)`. Handle zero-cross gracefully (no trades, price unchanged, volume 0). `tests/test_market.py`: (a) textbook example — bids (10@102, 5@101, 5@99mkt-buy treated as market), asks (8@100, 7@103) — assert computed p* and fills by hand-derived values you state in comments; (b) conservation: total shares and total cash across agents unchanged by settlement except tax; (c) band binds; (d) no-overlap ⇒ no trades; (e) property test with random orders: buyer pays == seller receives, fills ≤ order qty."
**Verify:** `pytest tests/test_market.py -q`

**P3 — Asset process & news.**
"Implement `sim/assets.py` per spec §4: AR(1) dividend with floor at 0; fundamental F_t = d̄_t/r where d̄_t reflects active news effects; scripted news from config with `dbar_mult` + duration; Smith-bubble mode (finite horizon, discrete dividend distribution {0,0.08,0.28,0.60} scaled by config, F_t = E[d](T−t), asset expires worthless). Deterministic under seed. `tests/test_assets.py`: dividend stationarity (long-run mean ≈ d̄ within tolerance), news shifts F during window and reverts, bubble-mode F declines linearly to 0."
**Verify:** `pytest tests/test_assets.py -q`

**P4 — Rule agent roster.**
"Complete `sim/agents/rule_agents.py` per spec §5: ZeroIntelligence, Fundamentalist, Momentum, MarketMaker, NoiseTrader — all seeded-RNG deterministic, all respecting budget constraints internally, all exposing params risk_aversion/aggressiveness/horizon/activity_prob where meaningful (document each param in the docstring, mapping to '[senior]-style parametric attributes'). `tests/test_rule_agents.py`: fundamentalist buys iff underpriced beyond δ; momentum direction follows trend sign; ZI never violates budget across 1000 random obs; MM posts both sides within inventory limits."
**Verify:** `pytest tests/test_rule_agents.py -q` then run `configs/rules_only.yaml` (create: 1 MM + 5 ZI + 3 fund + 3 mom, 500 rounds) and eyeball `runs/.../plots/price.png`.

**P5 — Metrics & plots.**
"Implement `sim/metrics.py` reading a run directory, computing the battery in `06_EVALUATION_AND_EXPERIMENTS.md` §1 (excess kurtosis with test, Ljung-Box on returns lags 1–10, ACF of |r| lags 1–20 with significance, GARCH(1,1) via `arch` package with coefficient significance, volume–|r| Spearman, Hurst via R/S, plus wealth stats: per-agent-type mean final wealth, Gini) → `metrics.json` + `metrics.md` human table + plots (price+F+volume panel; return histogram with normal overlay; ACF pair; wealth trajectories colored by agent type; QQ plot). CLI: `python -m sim.metrics runs/<dir>`. Also `python -m sim.metrics --compare runs/a runs/b ...` producing a facts×runs pass/fail table. `tests/test_metrics.py`: feed synthetic GARCH series (simulate one) ⇒ clustering detected; feed iid normal ⇒ kurtosis/clustering not flagged."
**Verify:** `pytest tests/test_metrics.py -q && python -m sim.metrics runs/<latest>`

**P6 — LLM client.**
"Implement `sim/llm/client.py` per spec §7 (OpenAI-compatible via `httpx` or `openai` sdk; env `LLM_BASE_URL`, `LLM_API_KEY`, config model; retries w/ backoff on 429/5xx/timeout; token+cost accounting with per-model price table in a dict, unknown models cost 0 with warning; optional sqlite/file cache keyed by content hash; `json_mode` request when provider supports it, silently ignore if not). Keep `sim/llm/mock.py` interface-identical; add tests that both satisfy the same contract via a shared test suite (mock actually called; real client tested with `respx`/mocked HTTP, not live API)."
**Verify:** `pytest tests/test_llm_client.py -q`

**P7 — Personas.**
"Implement `sim/agents/personas.py` per spec §5: dataclass Persona; a curated library of 12 diverse handcrafted personas (Indian names/occupations welcome; vary age 22–68, risk, style, biases, backstories — write them well, they'll be quoted in a thesis); `generate(rng, n, attribute_weights)` sampling attribute combos and rendering backstories from templates; `render_system_prompt(persona, market_rules_text)` producing spec §6 text with bias clauses in second-person dispositional language (loss_averse → 'You feel losses about twice as strongly as equivalent gains and find it painful to sell below your purchase price.' overconfident → 'You trust your own reading of the market more than consensus and rarely doubt your calls.' herding_prone → 'You feel safer doing what most other people seem to be doing.' disposition_prone → include with loss_averse clause. recency_biased → 'The last few days weigh far more in your mind than older history.'). Persist assigned personas to the run dir as `personas.json`. Test: prompts contain all fields; generation deterministic under seed; no two library personas share name."
**Verify:** `pytest tests/test_personas.py -q`

**P8 — LLM agent.**
"Implement `sim/agents/llm_agent.py` per spec §§5–6: build user prompt from Observation (exact template spec §6, blocks omitted cleanly when empty); call client; robust JSON extraction (direct parse → strip fences → first-brace-to-last-brace slice → regex); validation & repair per spec §3.3 with one corrective re-ask (append: 'Your reply was invalid because <reason>. Reply with ONLY the JSON object.'); fallback HOLD with `parse_failed` flag; memory window + diary + reflection call every `reflect_every` rounds at temperature 0 ('Summarize your trading situation, view of the market and plan in under 120 words, first person'); everything logged to `llm_calls.jsonl` per spec §9. Wire agent-group `type: llm` in engine with concurrent decisions (ThreadPoolExecutor, `max_workers` config default 8) — concurrency must not break determinism of the *market* given identical LLM replies (collect all orders, then sort by agent_id before clearing). Tests use mock client: full 20-round run with 10 llm-mock agents; force malformed replies via a poisoned mock and assert repair path + HOLD fallback + logs."
**Verify:** `pytest tests/test_llm_agent.py -q && python -m sim.engine --config configs/dev_mock.yaml` then check `runs/<latest>/llm_calls.jsonl` exists and is well-formed (`head -2 | python -m json.tool` on each line).

**P9 — Run ergonomics.**
"Add to `sim/engine.py`: progress bar (tqdm) with live price/cost; `--resume runs/<dir>` (checkpoint full RNG state + agent states every 10 rounds via pickle); `--seeds 1,2,3` sequential multi-seed into sibling run dirs; graceful Ctrl-C (flush logs, write partial summary); `summary.json` per spec §9. Test: kill-and-resume produces identical `prices.csv` to uninterrupted run under mock LLM (this is the acceptance test — make determinism work)."
**Verify:** `pytest tests/test_resume.py -q`

**P10 — (Sem 2) BBS social layer.**
"Implement `sim/social.py`: after each round, each LLM agent with `posts_to_bbs: true` produces (same decision call — extend the JSON schema with optional `bbs_post: string|null`, ≤ 200 chars, in character) a post stored with round+agent_id; next round each agent's Observation includes `bbs_posts`: sample of k=5 recent posts (config: uniform sample | most-recent | influencer mode where designated agent ids always included). Persist `bbs.csv`. Off by default; enabled via `observation.bbs_sample > 0`. Update prompt template with bbs block ('Forum posts from other traders yesterday: ...'). Tests with mock."
**Verify:** `pytest tests/test_social.py -q`

**P11 — (Sem 2) Interventions.**
"Config-driven interventions per spec §8/`06` §3: `transaction_tax` (deducted from both sides, accumulated to a `tax_collected` ledger, conservation test updated), `circuit_breaker: {threshold: 0.07, halt_rounds: 1}` (if |p*−prev|/prev ≥ threshold: execute at clamped bound, then halt trading next N rounds — agents still observe and are told 'trading halted'), `rate_schedule: [{round: 100, r: 0.02}]`. Log all activations to `events.csv`. Tests for each."
**Verify:** `pytest tests/test_interventions.py -q`

**P12 — (Sem 2) Counterfactual runner.**
"`python -m sim.counterfactual --base configs/x.yaml --override 'news=[]' --seeds 1,2,3`: runs matched pairs (base vs override) with identical seeds AND identical persona assignment (personas sampled before override applied), then calls a comparison report (per-round price delta plot, summary stats of both arms, matched-pair differences). Overrides are dotted-path config patches. This implements Eco3S-style structural counterfactuals — say so in the module docstring with citation."
**Verify:** run it under mock; check the delta plot is exactly 0 when override is empty.

**P13 — (Sem 2, optional) Continuous LOB.**
"Add `mechanism: lob` in `sim/market.py`: price-time priority book, agents polled in seeded-random order each round, immediate matching of crossing orders, partial fills, resting orders expire after `order_ttl` rounds, mid-price recorded as round close. Keep the call auction untouched and default. Reuse conservation/property tests for the LOB path."
**Verify:** `pytest tests/test_lob.py -q`

**Utility prompts (use as needed):**
- *Debug*: "Here is a failing test output and the relevant file(s). Fix the bug with the minimal change; do not refactor; explain the root cause in one paragraph first."
- *Explain (use often — this is how YOU learn the code)*: "Explain `sim/market.py` function by function to a student who knows Python but not finance. Then give me 5 viva-style questions about it with answers."
- *Plot request*: "Add a plot to metrics: <description>, saved to plots/<name>.png, matplotlib only, readable at thesis print size (font ≥ 11, labeled axes, title, legend)."
- *Experiment config*: "Create configs/<name>.yaml implementing experiment <En> as specified in the attached `06_EVALUATION_AND_EXPERIMENTS.md` section, based on configs/baseline_v1.yaml."
